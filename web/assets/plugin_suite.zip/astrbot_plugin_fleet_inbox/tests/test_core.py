import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from core import normalize_umos, payload_for, resolve_manager_url


class ResolveManagerUrlTest(unittest.TestCase):
    def test_runtime_file_overrides_default_port(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "AstrBot舰队管理器" / "data"
            data.mkdir(parents=True)
            (data / "manager_runtime.json").write_text(
                '{"url": "http://127.0.0.1:7312"}', encoding="utf-8")
            with patch.dict(os.environ, {"LOCALAPPDATA": tmp}):
                self.assertEqual(
                    resolve_manager_url("http://127.0.0.1:7311"),
                    "http://127.0.0.1:7312",
                )

    def test_missing_runtime_file_falls_back(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch.dict(os.environ, {"LOCALAPPDATA": tmp}):
                self.assertEqual(
                    resolve_manager_url("http://127.0.0.1:7311"),
                    "http://127.0.0.1:7311",
                )



class CoreTest(unittest.TestCase):
    def test_normalize_umos(self):
        self.assertEqual(normalize_umos(["a", " a ", ""]), ["a"])
        self.assertEqual(normalize_umos("a,b"), ["a", "b"])

    def test_normalize_umos_handles_chinese_comma_and_empty_input(self):
        self.assertEqual(normalize_umos("a，b , a"), ["a", "b"])
        self.assertEqual(normalize_umos(None), [])
        self.assertEqual(normalize_umos(""), [])

    def test_payload_for(self):
        payload = payload_for("大肥鱼:FriendMessage:1", "1", "小明", "你好", 10, "m1")
        self.assertEqual(payload["platform"], "qq")
        self.assertEqual(payload["platform_id"], "大肥鱼")
        self.assertEqual(payload["kind"], "private")
        self.assertEqual(payload["external_id"], "m1")

    def test_payload_for_group_keeps_account_id(self):
        payload = payload_for(
            "大肥鱼:GroupMessage:884218771", "2", "小红", "群里好", 30.5, "m2", "i1"
        )
        self.assertEqual(payload["platform"], "qq")
        self.assertEqual(payload["platform_id"], "大肥鱼")
        self.assertEqual(payload["thread_key"], "大肥鱼:GroupMessage:884218771")
        self.assertEqual(payload["kind"], "group")
        self.assertEqual(payload["account_id"], "i1")
        self.assertEqual(payload["sender_id"], "2")
        self.assertEqual(payload["sender_name"], "小红")
        self.assertEqual(payload["text"], "群里好")
        self.assertEqual(payload["ts"], 30.5)
        self.assertEqual(payload["external_id"], "m2")

    def test_payload_for_normalizes_missing_fields(self):
        payload = payload_for("大肥鱼:FriendMessage:1", None, None, None, 0, 7)
        self.assertEqual(payload["sender_id"], "")
        self.assertEqual(payload["sender_name"], "")
        self.assertEqual(payload["text"], "")
        self.assertEqual(payload["external_id"], "7")
        self.assertEqual(payload["account_id"], "")


if __name__ == "__main__":
    unittest.main()
