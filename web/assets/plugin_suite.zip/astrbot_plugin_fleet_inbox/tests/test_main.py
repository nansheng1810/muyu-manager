"""main.py 的队列/补发行为测试。

用最小的 `astrbot.*` 桩模块替代真实 AstrBot 运行时，测试不启动实例、不联网。
"""

import asyncio
import importlib
import json
import sys
import tempfile
import types
import unittest
import urllib.error
from pathlib import Path
from unittest import mock

PLUGIN_DIR = Path(__file__).resolve().parents[1]
if str(PLUGIN_DIR.parent) not in sys.path:
    sys.path.insert(0, str(PLUGIN_DIR.parent))


class FakeLogger:
    """记录日志调用的假 logger，供测试断言告警内容。"""

    def __init__(self):
        self.records = []

    def _record(self, level, message, args):
        self.records.append((level, message % args if args else message))

    def debug(self, message, *args):
        self._record("DEBUG", message, args)

    def info(self, message, *args):
        self._record("INFO", message, args)

    def warning(self, message, *args):
        self._record("WARNING", message, args)

    def error(self, message, *args):
        self._record("ERROR", message, args)

    def messages(self, level):
        return [
            message for record_level, message in self.records if record_level == level
        ]


def _install_astrbot_stubs():
    """构造 main.py 导入所需的最小 astrbot 模块树。"""
    astrbot = types.ModuleType("astrbot")
    astrbot.logger = FakeLogger()

    api = types.ModuleType("astrbot.api")
    event_mod = types.ModuleType("astrbot.api.event")
    star_mod = types.ModuleType("astrbot.api.star")
    web_mod = types.ModuleType("astrbot.api.web")

    class AstrMessageEvent:
        pass

    class EventMessageType:
        ALL = "ALL"

    class Filter:
        def event_message_type(self, *args, **kwargs):
            def decorator(func):
                return func

            return decorator

    Filter.EventMessageType = EventMessageType

    class Context:
        def __init__(self):
            self.web_apis = []

        def register_web_api(self, *args, **kwargs):
            self.web_apis.append((args, kwargs))

    class Star:
        def __init__(self, context):
            self.context = context

    class StarTools:
        data_dir = None

        @staticmethod
        def get_data_dir(name):
            return StarTools.data_dir

    class Request:
        async def json(self, default=None):
            return default

    event_mod.AstrMessageEvent = AstrMessageEvent
    event_mod.filter = Filter()
    star_mod.Context = Context
    star_mod.Star = Star
    star_mod.StarTools = StarTools
    web_mod.request = Request()

    api.event = event_mod
    api.star = star_mod
    api.web = web_mod
    astrbot.api = api
    sys.modules["astrbot"] = astrbot
    sys.modules["astrbot.api"] = api
    sys.modules["astrbot.api.event"] = event_mod
    sys.modules["astrbot.api.star"] = star_mod
    sys.modules["astrbot.api.web"] = web_mod
    return astrbot, star_mod


FAKE_ASTRBOT, STAR_MOD = _install_astrbot_stubs()
main = importlib.import_module("astrbot_plugin_fleet_inbox.main")
LOGGER = FAKE_ASTRBOT.logger


class FakeResponse:
    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def read(self):
        return b"{}"


class FakeSegment:
    def __init__(self, segment_type):
        self.type = segment_type


class FakeMessageObj:
    def __init__(self, message_id, segments, self_id):
        self.message_id = message_id
        self.message = segments
        self.self_id = self_id


class FakeEvent:
    def __init__(
        self,
        umo,
        sender_id="u1",
        text="",
        message_id="m1",
        segments=None,
        self_id="bot-1",
    ):
        self.unified_msg_origin = umo
        self.sender_id = sender_id
        self.text = text
        self.stopped = False
        self.message_obj = FakeMessageObj(message_id, segments or [], self_id)

    def stop_event(self):
        self.stopped = True

    def get_sender_id(self):
        return self.sender_id

    def get_sender_name(self):
        return "测试用户"

    def get_self_id(self):
        return self.message_obj.self_id

    def get_message_str(self):
        return self.text

    def get_messages(self):
        return self.message_obj.message


def _payload(index):
    return {
        "thread_key": f"umo:FriendMessage:{index}",
        "external_id": f"m{index}",
        "text": f"t{index}",
    }


def _http_error(code):
    return urllib.error.HTTPError(
        "http://manager/api/inbox/ingest", code, "error", {}, None
    )


class FleetInboxTest(unittest.TestCase):
    def setUp(self):
        LOGGER.records.clear()
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        STAR_MOD.StarTools.data_dir = self.tmp.name
        self.context = STAR_MOD.Context()
        self.plugin = main.FleetInbox(self.context, {"manager_url": "http://manager"})

    def test_flush_pops_successful_payloads(self):
        self.plugin.pending = [_payload(1), _payload(2)]
        with mock.patch.object(
            main.urllib.request, "urlopen", return_value=FakeResponse()
        ):
            sent, dropped = asyncio.run(self.plugin._flush_once())

        self.assertEqual((sent, dropped), (2, 0))
        self.assertEqual(self.plugin.pending, [])
        persisted = json.loads(self.plugin.pending_path.read_text(encoding="utf-8"))
        self.assertEqual(persisted, [])

    def test_flush_drops_4xx_and_keeps_going(self):
        self.plugin.pending = [_payload(1), _payload(2)]
        with mock.patch.object(
            main.urllib.request,
            "urlopen",
            side_effect=[_http_error(400), FakeResponse()],
        ):
            sent, dropped = asyncio.run(self.plugin._flush_once())

        # 4xx 的队首被丢弃，后面的消息不被永久卡住。
        self.assertEqual((sent, dropped), (1, 1))
        self.assertEqual(self.plugin.pending, [])
        self.assertTrue(any("HTTP 400" in item for item in LOGGER.messages("WARNING")))

    def test_flush_retains_pending_on_network_error_and_5xx(self):
        for error in (urllib.error.URLError("boom"), _http_error(503)):
            with self.subTest(error=error):
                self.plugin.pending = [_payload(1), _payload(2)]
                self.plugin._persist_pending()
                with mock.patch.object(
                    main.urllib.request, "urlopen", side_effect=error
                ):
                    sent, dropped = asyncio.run(self.plugin._flush_once())

                self.assertEqual((sent, dropped), (0, 0))
                self.assertEqual(
                    [item["external_id"] for item in self.plugin.pending],
                    ["m1", "m2"],
                )
                persisted = json.loads(
                    self.plugin.pending_path.read_text(encoding="utf-8")
                )
                self.assertEqual(
                    [item["external_id"] for item in persisted], ["m1", "m2"]
                )

    def test_flush_does_not_wedge_on_rejected_head(self):
        self.plugin.pending = [_payload(1), _payload(2), _payload(3)]
        with mock.patch.object(
            main.urllib.request,
            "urlopen",
            side_effect=[_http_error(422), FakeResponse(), FakeResponse()],
        ):
            asyncio.run(self.plugin._flush_once())

        self.assertEqual(self.plugin.pending, [])

    def test_queue_cap_trims_oldest_with_warning(self):
        self.plugin.pending = [_payload(i) for i in range(main.PENDING_LIMIT)]
        self.plugin._persist_pending()
        self.plugin._queue(_payload(main.PENDING_LIMIT))

        self.assertEqual(len(self.plugin.pending), main.PENDING_LIMIT)
        self.assertEqual(self.plugin.pending[0]["external_id"], "m1")
        self.assertEqual(
            self.plugin.pending[-1]["external_id"], f"m{main.PENDING_LIMIT}"
        )
        self.assertTrue(
            any(
                "待发队列" in item and "丢弃" in item
                for item in LOGGER.messages("WARNING")
            )
        )
        persisted = json.loads(self.plugin.pending_path.read_text(encoding="utf-8"))
        self.assertEqual(len(persisted), main.PENDING_LIMIT)

    def test_load_trims_oversized_pending_with_warning(self):
        path = Path(self.tmp.name) / "pending.json"
        path.write_text(
            json.dumps([_payload(i) for i in range(main.PENDING_LIMIT + 3)]),
            encoding="utf-8",
        )
        plugin = main.FleetInbox(self.context, {})

        self.assertEqual(len(plugin.pending), main.PENDING_LIMIT)
        self.assertEqual(plugin.pending[0]["external_id"], "m3")
        self.assertTrue(any("待发队列" in item for item in LOGGER.messages("WARNING")))

    def test_report_classifies_http_4xx_5xx_and_network(self):
        payload = _payload(1)
        with mock.patch.object(
            main.urllib.request, "urlopen", side_effect=_http_error(422)
        ):
            self.assertEqual(
                asyncio.run(self.plugin._report(payload)), main.REPORT_DROPPED
            )
        with mock.patch.object(
            main.urllib.request, "urlopen", side_effect=_http_error(500)
        ):
            self.assertEqual(
                asyncio.run(self.plugin._report(payload)), main.REPORT_RETRY
            )
        with mock.patch.object(
            main.urllib.request, "urlopen", side_effect=urllib.error.URLError("boom")
        ):
            self.assertEqual(
                asyncio.run(self.plugin._report(payload)), main.REPORT_RETRY
            )
        with mock.patch.object(
            main.urllib.request, "urlopen", return_value=FakeResponse()
        ):
            self.assertEqual(
                asyncio.run(self.plugin._report(payload)), main.REPORT_SENT
            )

    def test_report_drops_only_400_and_422(self):
        # 404（路由暂不可用）/408/429（限流）都是临时故障，必须保留重试
        payload = _payload(1)
        for code in (400, 422):
            with self.subTest(code=code):
                with mock.patch.object(
                    main.urllib.request, "urlopen", side_effect=_http_error(code)
                ):
                    self.assertEqual(
                        asyncio.run(self.plugin._report(payload)), main.REPORT_DROPPED
                    )
        for code in (404, 408, 429):
            with self.subTest(code=code):
                with mock.patch.object(
                    main.urllib.request, "urlopen", side_effect=_http_error(code)
                ):
                    self.assertEqual(
                        asyncio.run(self.plugin._report(payload)), main.REPORT_RETRY
                    )

    def test_flush_keeps_pending_on_404(self):
        self.plugin.pending = [_payload(1), _payload(2)]
        self.plugin._persist_pending()
        with mock.patch.object(
            main.urllib.request, "urlopen", side_effect=_http_error(404)
        ):
            sent, dropped = asyncio.run(self.plugin._flush_once())

        self.assertEqual((sent, dropped), (0, 0))
        self.assertEqual(
            [item["external_id"] for item in self.plugin.pending], ["m1", "m2"]
        )
        self.assertTrue(any("管理器不可达" in item for item in LOGGER.messages("WARNING")))

    def test_failure_warning_only_on_healthy_to_failing_transition(self):
        self.plugin.pending = [_payload(1)]
        with mock.patch.object(
            main.urllib.request, "urlopen", side_effect=urllib.error.URLError("boom")
        ):
            asyncio.run(self.plugin._flush_once())
            asyncio.run(self.plugin._flush_once())

        warnings = [
            item for item in LOGGER.messages("WARNING") if "管理器不可达" in item
        ]
        self.assertEqual(len(warnings), 1)

        with mock.patch.object(
            main.urllib.request, "urlopen", return_value=FakeResponse()
        ):
            asyncio.run(self.plugin._flush_once())
        self.assertFalse(self.plugin.failing)
        self.assertTrue(any("已恢复" in item for item in LOGGER.messages("INFO")))

    def test_guard_reports_media_placeholder(self):
        cases = [("Image", "[图片]"), ("Record", "[语音]"), ("Unknown", "[非文本消息]")]
        for segment_type, expected in cases:
            with self.subTest(segment_type=segment_type):
                event = FakeEvent(
                    "bot:GroupMessage:1",
                    sender_id="u1",
                    text="",
                    segments=[FakeSegment(segment_type)],
                )
                self.plugin.umos = {event.unified_msg_origin}
                captured = {}

                def fake_urlopen(req, timeout=None):
                    captured["payload"] = json.loads(req.data.decode("utf-8"))
                    return FakeResponse()

                with mock.patch.object(main.urllib.request, "urlopen", fake_urlopen):
                    asyncio.run(self.plugin.guard(event))

                self.assertTrue(event.stopped)
                self.assertEqual(captured["payload"]["text"], expected)
                self.assertEqual(
                    captured["payload"]["external_id"],
                    "qq-plugin:bot:GroupMessage:1:m1",
                )

    def test_guard_skips_self_message(self):
        event = FakeEvent(
            "bot:FriendMessage:1", sender_id="bot-1", text="你好", self_id="bot-1"
        )
        self.plugin.umos = {event.unified_msg_origin}
        with mock.patch.object(
            main.urllib.request,
            "urlopen",
            side_effect=AssertionError("should not report"),
        ):
            asyncio.run(self.plugin.guard(event))

        self.assertTrue(event.stopped)

    def test_save_is_atomic_and_leaves_no_tmp(self):
        self.plugin._save(self.plugin.path, {"umos": ["a"], "account_id": "i"})

        saved = json.loads(self.plugin.path.read_text(encoding="utf-8"))
        self.assertEqual(saved, {"umos": ["a"], "account_id": "i"})
        tmp = self.plugin.path.with_name(self.plugin.path.name + ".tmp")
        self.assertFalse(tmp.exists())


if __name__ == "__main__":
    unittest.main()
