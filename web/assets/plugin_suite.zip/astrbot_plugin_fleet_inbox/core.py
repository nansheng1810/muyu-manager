"""牧鱼收件箱插件的纯函数：接管 UMO 归一化与上报 payload 组装。"""

from __future__ import annotations

import json
import os
from pathlib import Path

DEFAULT_MANAGER_URL = "http://127.0.0.1:7311"


def resolve_manager_url(configured="", default=DEFAULT_MANAGER_URL) -> str:
    """解析管理器地址：显式非默认配置优先，否则读管理器写出的运行时端口。"""
    value = str(configured or "").strip().rstrip("/")
    default_text = str(default or DEFAULT_MANAGER_URL).rstrip("/")
    if value and value != default_text:
        return value
    try:
        base = Path(os.environ.get("LOCALAPPDATA") or str(Path.home()))
        path = base / "AstrBot舰队管理器" / "data" / "manager_runtime.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        url = str(data.get("url") or "").strip().rstrip("/")
        if url.startswith(("http://127.0.0.1:", "http://localhost:")):
            return url
    except (OSError, ValueError, TypeError):
        pass
    return value or default_text


def normalize_umos(value):
    """把管理器下发的接管名单归一化为去重后的 UMO 列表。

    Args:
        value: 字符串（逗号分隔，兼容中文逗号）或字符串列表。

    Returns:
        去掉首尾空白、去空、去重且保持原顺序的 UMO 列表。
    """
    if isinstance(value, str):
        value = value.replace("，", ",").split(",")
    out = []
    for item in value or []:
        text = str(item or "").strip()
        if text and text not in out:
            out.append(text)
    return out


def payload_for(umo, sender_id, sender_name, text, ts, external_id, account_id=""):
    """组装一条上报给 `POST /api/inbox/ingest` 的消息 payload。

    Args:
        umo: AstrBot 统一消息来源，如 `大肥鱼:FriendMessage:123`。
        sender_id: 发送者 ID。
        sender_name: 发送者昵称。
        text: 消息纯文本。
        ts: 消息时间戳（秒）。
        external_id: 去重用的外部消息 ID。
        account_id: 管理器实例 ID，来自 takeover 请求，原样回传。

    Returns:
        字段名与管理器 ingest 约定一致的字典。
    """
    return {
        "platform": "qq",
        "platform_id": str(umo).split(":", 1)[0],
        "account_id": str(account_id or ""),
        "thread_key": str(umo),
        "kind": "group" if ":GroupMessage:" in str(umo) else "private",
        "sender_id": str(sender_id or ""),
        "sender_name": str(sender_name or ""),
        "text": str(text or ""),
        "ts": float(ts),
        "external_id": str(external_id),
    }
