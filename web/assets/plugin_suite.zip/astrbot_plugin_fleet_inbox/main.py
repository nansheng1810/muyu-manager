"""牧鱼收件箱：接管 QQ 会话时暂停自动回复，并把消息上报给牧鱼管理器。

管理器通过 `POST /astrbot_plugin_fleet_inbox/takeover` 下发接管名单（UMO 列表
和实例 ID），本插件在最高优先级事件层拦下这些会话的消息，逐条 POST 到管理器
`/api/inbox/ingest`；网络错误或 5xx 先落盘、30 秒后自动补发；400/422 表示管理器
明确拒收该条消息，丢弃并告警，避免待发队列被一条坏数据永久卡住。404/408/429
同样保留重试：管理器升级或限流时路由可能暂时不可用，不能当成永久拒绝。
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

from astrbot import logger
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Context, Star, StarTools
from astrbot.api.web import request

from .core import normalize_umos, payload_for, resolve_manager_url

NAME = "astrbot_plugin_fleet_inbox"
DEFAULT_MANAGER_URL = "http://127.0.0.1:7311"
INGEST_PATH = "/api/inbox/ingest"
PENDING_LIMIT = 200
REPORT_TIMEOUT = 3
FLUSH_INTERVAL = 30
REPORT_SENT = "sent"
REPORT_DROPPED = "dropped"
REPORT_RETRY = "retry"
MEDIA_LABELS = {
    "Image": "[图片]",
    "Record": "[语音]",
    "Video": "[视频]",
    "File": "[文件]",
}
NON_TEXT_PLACEHOLDER = "[非文本消息]"


class FleetInbox(Star):
    def __init__(self, context: Context, config=None):
        super().__init__(context)
        self.config = config or {}
        self.data_dir = Path(StarTools.get_data_dir(NAME))
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.data_dir / "takeovers.json"
        self.pending_path = self.data_dir / "pending.json"
        saved = self._load(self.path, {})
        self.umos = set(
            normalize_umos(saved.get("umos") if isinstance(saved, dict) else saved)
        )
        self.account_id = (
            str(saved.get("account_id") or "") if isinstance(saved, dict) else ""
        )
        pending = self._load(self.pending_path, [])
        if isinstance(pending, list):
            items = [item for item in pending if isinstance(item, dict)]
            if len(items) > PENDING_LIMIT:
                # 加载时超限同样要留痕，不能悄悄丢掉旧消息。
                logger.warning(
                    "[收件箱] 待发队列超过上限 %s，丢弃最旧的 %s 条",
                    PENDING_LIMIT,
                    len(items) - PENDING_LIMIT,
                )
            self.pending = items[-PENDING_LIMIT:]
        else:
            self.pending = []
        self.task = None
        self.failing = False

    def _load(self, path, default):
        """读取 JSON 状态文件，文件缺失或内容损坏时返回默认值。"""
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return default

    def _save(self, path, value):
        """原子写入 JSON 状态文件（临时文件 + os.replace）。"""
        tmp = path.with_name(path.name + ".tmp")
        try:
            tmp.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, path)
        except OSError:
            tmp.unlink(missing_ok=True)
            raise

    def _persist_pending(self):
        """尽力把待发队列写盘，失败只记日志，避免打断消息处理。"""
        try:
            self._save(self.pending_path, self.pending[-PENDING_LIMIT:])
        except OSError as exc:
            logger.warning("[收件箱] 待发队列写盘失败：%s", exc)

    def _queue(self, payload):
        """缓存上报失败的 payload，等管理器恢复后由补发循环重试。"""
        self.pending.append(payload)
        overflow = len(self.pending) - PENDING_LIMIT
        if overflow > 0:
            del self.pending[:overflow]
            logger.warning(
                "[收件箱] 待发队列超过上限 %s，丢弃最旧的 %s 条",
                PENDING_LIMIT,
                overflow,
            )
        self._persist_pending()

    def _mark_failing(self, exc):
        """记录管理器不可达；只在健康→故障的瞬间告警一次。"""
        if not self.failing:
            self.failing = True
            logger.warning("[收件箱] 管理器不可达或异常，消息转入待发队列：%s", exc)

    def _mark_healthy(self):
        """记录管理器恢复；只在故障→健康的瞬间提示一次。"""
        if self.failing:
            self.failing = False
            logger.info("[收件箱] 管理器已恢复，待发队列将继续补发")

    async def initialize(self):
        self.context.register_web_api(
            f"/{NAME}/takeover", self.api_takeover, ["POST"], "收件箱接管名单"
        )
        self.context.register_web_api(
            f"/{NAME}/status", self.api_status, ["GET"], "收件箱接管状态"
        )
        self.task = asyncio.create_task(self._flush_loop())
        logger.info("[收件箱] QQ 接管插件已加载，接管会话 %s 个", len(self.umos))

    async def terminate(self):
        if self.task is not None:
            self.task.cancel()
            await asyncio.gather(self.task, return_exceptions=True)
            self.task = None
        logger.info("[收件箱] QQ 接管插件已卸载，当前接管会话 %s 个", len(self.umos))

    async def api_status(self):
        return {
            "status": "ok",
            "data": {
                "takeovers": sorted(self.umos),
                "pending": len(self.pending),
                "account_id": self.account_id,
            },
        }

    async def api_takeover(self):
        payload = await request.json(default={})
        data = payload if isinstance(payload, dict) else {}
        self.umos = set(normalize_umos(data.get("umos") or []))
        self.account_id = str(data.get("account_id") or self.account_id)
        try:
            self._save(
                self.path,
                {"umos": sorted(self.umos), "account_id": self.account_id},
            )
        except OSError as exc:
            # 管理器每轮同步都会重新下发名单，写盘失败不影响当前进程内接管。
            logger.warning("[收件箱] 接管名单写盘失败：%s", exc)
        logger.info("[收件箱] 接管名单已更新：%s 个会话", len(self.umos))
        return {
            "status": "ok",
            "data": {"takeovers": sorted(self.umos), "account_id": self.account_id},
        }

    @filter.event_message_type(filter.EventMessageType.ALL, priority=sys.maxsize)
    async def guard(self, event: AstrMessageEvent):
        """拦下已接管会话的消息：停止自动回复，并上报给管理器。"""
        umo = str(event.unified_msg_origin)
        if umo not in self.umos:
            return
        event.stop_event()
        sender_id = str(event.get_sender_id() or "")
        try:
            self_id = str(event.get_self_id() or "")
        except Exception:
            self_id = ""
        if self_id and sender_id == self_id:
            logger.debug("[收件箱] 跳过机器人自身消息：%s", umo)
            return
        text = event.get_message_str() or ""
        if not text.strip():
            # 纯图片/语音等消息没有文本，用占位符保证在收件箱里可见，不再静默丢弃。
            try:
                segments = event.get_messages() or []
            except Exception:
                segments = []
            for segment in segments:
                segment_type = getattr(segment, "type", "")
                segment_type = str(getattr(segment_type, "value", segment_type))
                if segment_type in MEDIA_LABELS:
                    text = MEDIA_LABELS[segment_type]
                    break
            else:
                text = NON_TEXT_PLACEHOLDER
        try:
            sender_name = event.get_sender_name()
        except Exception:
            sender_name = ""
        payload = payload_for(
            umo,
            sender_id,
            sender_name,
            text,
            time.time(),
            f"qq-plugin:{umo}:{getattr(event.message_obj, 'message_id', '') or time.time_ns()}",
            self.account_id,
        )
        logger.debug("[收件箱] 接管会话 %s 收到消息 %s", umo, payload["external_id"])
        if await self._report(payload) == REPORT_RETRY:
            self._queue(payload)

    async def _report(self, payload):
        """把一条消息 POST 给管理器并给出后续处理建议。

        只有 400/422 说明管理器明确拒收这条消息；404（路由暂不可用）、408、
        429（限流）以及 5xx、网络错误都按临时故障重试，避免升级/重启期间丢消息。

        Args:
            payload: 由 `payload_for` 组装的上报字典。

        Returns:
            `REPORT_SENT` 表示已入库或已去重；`REPORT_DROPPED` 表示管理器返回
            400/422 永久拒绝，调用方应丢弃该条；`REPORT_RETRY` 表示网络错误、
            404/408/429 或 5xx，调用方应保留并稍后重试。
        """
        base = resolve_manager_url(
            self.config.get("manager_url") or DEFAULT_MANAGER_URL).rstrip("/")
        url = base + INGEST_PATH
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")

        def call():
            req = urllib.request.Request(
                url,
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=REPORT_TIMEOUT) as response:
                response.read()

        try:
            await asyncio.to_thread(call)
        except urllib.error.HTTPError as exc:
            if exc.code in (400, 422):
                # 管理器正常应答但拒绝这条消息（字段非法等），重试不会成功。
                self._mark_healthy()
                logger.warning(
                    "[收件箱] 管理器拒收消息（HTTP %s），已丢弃 %s：%s",
                    exc.code,
                    payload.get("external_id"),
                    exc,
                )
                return REPORT_DROPPED
            self._mark_failing(exc)
            return REPORT_RETRY
        except Exception as exc:
            self._mark_failing(exc)
            return REPORT_RETRY
        self._mark_healthy()
        return REPORT_SENT

    async def _flush_once(self):
        """按原顺序补发一轮待发队列，永久拒绝的条目直接丢弃。

        Returns:
            `(sent, dropped)` 元组，分别表示本轮成功送达和丢弃的条数。
        """
        sent = 0
        dropped = 0
        while self.pending:
            payload = self.pending[0]
            status = await self._report(payload)
            if status == REPORT_RETRY:
                # 保留队首及其后的消息，等下一轮按原顺序重试。
                break
            self.pending.pop(0)
            if status == REPORT_DROPPED:
                dropped += 1
            else:
                sent += 1
        if sent or dropped:
            self._persist_pending()
        return sent, dropped

    async def _flush_loop(self):
        """每 30 秒补发一次待发队列；异常只记日志，循环不退出。"""
        while True:
            await asyncio.sleep(FLUSH_INTERVAL)
            try:
                await self._flush_once()
            except Exception as exc:
                # 补发是后台兜底，任何异常都不能让循环退出。
                logger.warning("[收件箱] 补发队列异常：%s", exc)
