import unittest

from core import (
    activity_since,
    build_prompt,
    clean_reply,
    group_activity_view,
    is_bot_sender,
    parse_peer_ids,
    sanitize,
    strip_speaker_prefix,
)


class SanitizeTest(unittest.TestCase):
    def test_removes_cq_link_and_mention(self):
        text = "[CQ:at,qq=123] 看 https://example.com/x @某人 这个  视频"
        self.assertEqual(sanitize(text), "看 这个 视频")

    def test_truncates_to_limit(self):
        self.assertEqual(sanitize("一二三四五", max_chars=3), "一二三")


class CleanReplyTest(unittest.TestCase):
    def test_takes_first_line_and_strips_prefix_and_quotes(self):
        text = "大肥鱼：「刚看到个挺逗的事」\n下一行"
        self.assertEqual(clean_reply(text, names=["大肥鱼"]), "刚看到个挺逗的事")

    def test_unknown_prefix_is_kept(self):
        self.assertEqual(clean_reply("标题：正文"), "标题：正文")

    def test_removes_cq_and_truncates(self):
        self.assertEqual(clean_reply("[CQ:face,id=1]你好呀", max_chars=3), "你好呀"[:3])

    def test_empty_reply_rejected(self):
        self.assertEqual(clean_reply("「」"), "")
        self.assertEqual(clean_reply("   "), "")

    def test_strip_speaker_prefix_only_known_names(self):
        self.assertEqual(strip_speaker_prefix("千问：你好", ["千问"]), "你好")
        self.assertEqual(strip_speaker_prefix("别人：你好", ["千问"]), "别人：你好")


class PromptTest(unittest.TestCase):
    def test_prompt_includes_topic_history_and_rules(self):
        prompt = build_prompt(
            "周末去哪",
            [{"speaker_name": "大肥鱼", "text": "去河边"}, {"speaker_name": "千问", "text": "带伞"}],
            "大肥鱼",
            "千问",
            turn=3,
            max_chars=60,
        )
        self.assertIn("群聊话题：周末去哪", prompt)
        self.assertIn("大肥鱼：去河边", prompt)
        self.assertIn("千问：带伞", prompt)
        self.assertIn("第 3 句", prompt)
        self.assertIn("60 字以内", prompt)

    def test_prompt_without_history_asks_to_open(self):
        prompt = build_prompt("", [], "甲", "乙")
        self.assertIn("由你先开口", prompt)
        self.assertIn("随便聊聊", prompt)

    def test_prompt_drops_invalid_transcript_items(self):
        prompt = build_prompt("话题", [{"speaker_name": "", "text": "x"}, "bad"], "甲", "乙")
        self.assertNotIn("x\n", prompt)


class PeerTest(unittest.TestCase):
    def test_parse_peer_ids_filters_and_dedupes(self):
        self.assertEqual(parse_peer_ids("123456，654321 123456 abc"), ["123456", "654321"])
        self.assertEqual(parse_peer_ids(["123456", "7654321"]), ["123456", "7654321"])

    def test_is_bot_sender(self):
        self.assertTrue(is_bot_sender("111", "111", []))
        self.assertTrue(is_bot_sender("222", "111", ["222"]))
        self.assertFalse(is_bot_sender("333", "111", ["222"]))
        self.assertFalse(is_bot_sender("", "111", ["222"]))


class ActivityTest(unittest.TestCase):
    def test_activity_since_and_view(self):
        state = {
            "seq": 2,
            "events": [
                {"ts": 10, "sender": "1", "text": "早"},
                {"ts": 20, "sender": "2", "text": "晚"},
            ],
        }
        self.assertEqual([item["text"] for item in activity_since(state["events"], 15)], ["晚"])
        view = group_activity_view(state, since=15)
        self.assertEqual(view["last_ts"], 20)
        self.assertEqual(view["last_sender"], "2")
        self.assertEqual(view["seq"], 2)
        self.assertEqual(len(view["events"]), 1)

    def test_empty_view(self):
        view = group_activity_view({}, since=0)
        self.assertEqual(view["events"], [])
        self.assertEqual(view["last_ts"], 0)


if __name__ == "__main__":
    unittest.main()
