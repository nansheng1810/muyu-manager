"""群聊剧场：两个 AstrBot 实例在同一 QQ 群按话题轮流真实发言。

管理器负责场景状态与页面；本插件只做四件事：
- 高优先级拦下来自两个机器人 QQ 的群消息，避免群聊插件把它们当成用户输入而循环回复；
- 记录群内人类消息游标，供管理器判断“有人说话就暂停”和“安静自动”；
- 用当前人格与模型生成一句剧场发言，通过 aiocqhttp 发到群里；
- 把机器人自己的 QQ 号、平台状态和最近活动暴露给管理器。
"""

from __future__ import annotations

import asyncio
import json
import sys
import time
from collections import deque
from pathlib import Path

from astrbot import logger
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Context, Star, StarTools
from astrbot.api.web import request
from astrbot.core.config.astrbot_config import AstrBotConfig

from .core import (
    build_prompt,
    clean_reply,
    group_activity_view,
    is_bot_sender,
    parse_peer_ids,
    sanitize,
)

NAME = "astrbot_plugin_fleet_duet"
DEFAULT_SETTINGS = {
    "peer_qq": "",
    "filter_enabled": True,
    "max_chars": 80,
    "temperature": 0.9,
}
MAX_GROUPS = 50
MAX_EVENTS = 200


class FleetDuet(Star):
    def __init__(self, context: Context, config: AstrBotConfig | None = None):
        super().__init__(context)
        self.context = context
        self.config = config or {}
        self.data_dir = Path(StarTools.get_data_dir(NAME))
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.settings_path = self.data_dir / "settings.json"
        self.settings = self._load_settings()
        self.activity: dict[str, dict] = {}
        self.self_qq = ""
        self.nickname = ""
        self.login_at = 0.0
        self.login_error = ""
        self.last_self_id = ""
        self.speak_lock = asyncio.Lock()
        self.cancelled_scenes: set[str] = set()
        self.started_at = time.time()

    # ------------------------------------------------------------ settings

    def _load_settings(self) -> dict:
        data = dict(DEFAULT_SETTINGS)
        try:
            saved = json.loads(self.settings_path.read_text(encoding="utf-8"))
            if isinstance(saved, dict):
                data.update(saved)
        except (OSError, ValueError):
            pass
        configured = str(self.config.get("peer_qq") or "").strip()
        if configured and not data.get("peer_qq"):
            data["peer_qq"] = configured
        data["peer_qqs"] = parse_peer_ids(data.get("peer_qq") or configured)
        data["filter_enabled"] = bool(data.get("filter_enabled", True))
        data["max_chars"] = max(20, min(int(data.get("max_chars") or 80), 200))
        data["temperature"] = max(0.0, min(float(data.get("temperature") or 0.9), 1.5))
        return data

    def _save_settings(self) -> None:
        payload = {
            "peer_qq": str(self.settings.get("peer_qq") or ""),
            "filter_enabled": bool(self.settings.get("filter_enabled", True)),
            "max_chars": int(self.settings.get("max_chars") or 80),
            "temperature": float(self.settings.get("temperature") or 0.9),
        }
        self.settings_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    @property
    def peer_ids(self) -> list[str]:
        return parse_peer_ids(self.settings.get("peer_qq") or "")

    # -------------------------------------------------------------- startup

    async def initialize(self):
        routes = [
            ("status", self.api_status, ["GET"]),
            ("config", self.api_config, ["POST"]),
            ("activity", self.api_activity, ["GET"]),
            ("send", self.api_send, ["POST"]),
            ("speak", self.api_speak, ["POST"]),
            ("cancel", self.api_cancel, ["POST"]),
        ]
        for suffix, handler, methods in routes:
            self.context.register_web_api(
                f"/{NAME}/{suffix}", handler, methods, "双机群聊剧场"
            )
        logger.info(
            "[群聊剧场] 已加载；防循环过滤=%s，对端机器人=%s。",
            bool(self.settings.get("filter_enabled", True)),
            ",".join(self.peer_ids) or "未配置",
        )

    # ------------------------------------------------------------- platform

    def _platforms(self) -> list:
        out = []
        for platform in self.context.platform_manager.platform_insts:
            try:
                if getattr(platform.meta(), "name", "") == "aiocqhttp":
                    out.append(platform)
            except Exception:
                continue
        return out

    def _platform(self):
        candidates = self._platforms()
        for platform in candidates:
            client = platform.get_client()
            if getattr(client, "_wsr_api_clients", None):
                return platform
        return candidates[0] if candidates else None

    def _platforms_view(self) -> list[dict]:
        out = []
        for platform in self._platforms():
            client = platform.get_client()
            clients = getattr(client, "_wsr_api_clients", None)
            out.append({
                "id": str(getattr(platform.meta(), "id", "") or ""),
                "name": str(getattr(platform.meta(), "name", "") or ""),
                "client": type(client).__name__ if client else "",
                "clients": [str(key) for key in clients] if isinstance(clients, dict) else [],
            })
        return out

    def _client_keys(self) -> list[str]:
        platform = self._platform()
        client = platform.get_client() if platform else None
        keys = getattr(client, "_wsr_api_clients", None)
        return [str(key) for key in keys] if isinstance(keys, dict) else []

    async def _login(self) -> tuple[str, str]:
        if self.self_qq and time.time() - self.login_at < 60:
            return self.self_qq, self.nickname
        platform = self._platform()
        client = platform.get_client() if platform else None
        if client is not None:
            try:
                info = await asyncio.wait_for(client.get_login_info(), timeout=5)
                if isinstance(info, dict):
                    self.self_qq = str(info.get("user_id") or self.self_qq or self.last_self_id)
                    self.nickname = str(info.get("nickname") or self.nickname)
                    self.login_at = time.time()
                    self.login_error = ""
                else:
                    self.login_error = f"get_login_info 返回 {type(info).__name__}"
            except Exception as exc:
                self.login_error = f"{type(exc).__name__}: {exc}"[:200]
                logger.debug("[群聊剧场] 读取登录信息失败：%s", self.login_error)
            if not self.self_qq:
                clients = getattr(client, "_wsr_api_clients", None)
                if isinstance(clients, dict):
                    for key in clients:
                        value = str(key).split(":")[-1]
                        if value.isdigit():
                            self.self_qq = value
                            break
        if not self.self_qq:
            self.self_qq = self.last_self_id
        return self.self_qq, self.nickname

    async def _send(self, group_id: str, text: str) -> str:
        platform = self._platform()
        if platform is None:
            raise RuntimeError("没有已连接的 aiocqhttp 平台")
        client = platform.get_client()
        if client is None:
            raise RuntimeError("QQ 客户端未连接")
        if not getattr(client, "_wsr_api_clients", None):
            raise RuntimeError("NapCat 未连接到 AstrBot（6199 没有反向 WebSocket），请先确认 QQ 登录")
        result = await asyncio.wait_for(
            client.send_group_msg(
                group_id=int(group_id),
                message=[{"type": "text", "data": {"text": text}}],
            ),
            timeout=30,
        )
        if isinstance(result, dict):
            return str(result.get("message_id") or "")
        return ""

    # -------------------------------------------------------------- activity

    def _group_state(self, group_id: str) -> dict:
        state = self.activity.get(group_id)
        if state is None:
            if len(self.activity) >= MAX_GROUPS:
                oldest = min(self.activity, key=lambda key: self.activity[key]["seen"])
                self.activity.pop(oldest, None)
            state = {"events": deque(maxlen=MAX_EVENTS), "seq": 0, "seen": time.time()}
            self.activity[group_id] = state
        state["seen"] = time.time()
        return state

    def _remember(self, group_id: str, sender: str, name: str, text: str) -> None:
        state = self._group_state(group_id)
        state["seq"] += 1
        state["events"].append(
            {
                "ts": time.time(),
                "sender": str(sender or ""),
                "name": str(name or ""),
                "text": sanitize(text, max_chars=120),
                "seq": state["seq"],
            }
        )

    # ------------------------------------------------------------- guard

    @filter.event_message_type(filter.EventMessageType.ALL, priority=sys.maxsize)
    async def guard_group_messages(self, event: AstrMessageEvent):
        if event.is_private_chat():
            return
        group_id = str(event.get_group_id() or "")
        if not group_id:
            return
        sender = str(event.get_sender_id() or "")
        self_id = str(event.get_self_id() or "")
        if self_id:
            self.last_self_id = self_id
        if self.settings.get("filter_enabled", True) and is_bot_sender(
            sender, self_id, self.peer_ids
        ):
            event.clear_result()
            event.stop_event()
            logger.info(
                "[群聊剧场] 已拦截机器人消息：群 %s，发送者 %s", group_id, sender
            )
            return
        text = event.get_message_str() or ""
        if not text.strip():
            return
        try:
            name = event.get_sender_name()
        except Exception:
            name = ""
        self._remember(group_id, sender, name, text)

    # ---------------------------------------------------------------- APIs

    async def api_status(self):
        group_id = str(request.query.get("group_id", "") or "")
        self_qq, nickname = await self._login()
        platform = self._platform()
        groups = self.activity
        if group_id:
            state = groups.get(group_id) or {"events": [], "seq": 0}
            view = group_activity_view(state, since=0)
            groups = {group_id: view}
        else:
            groups = {
                key: group_activity_view(state, since=0)
                for key, state in groups.items()
            }
            for key, view in groups.items():
                view.pop("events", None)
        return {
            "status": "ok",
            "data": {
                "plugin": NAME,
                "platform_ready": platform is not None,
                "qq_connected": bool(self._client_keys()),
                "self_qq": self_qq,
                "nickname": nickname,
                "login_error": self.login_error,
                "client_keys": self._client_keys(),
                "platforms": self._platforms_view(),
                "peer_qqs": self.peer_ids,
                "filter_enabled": bool(self.settings.get("filter_enabled", True)),
                "max_chars": int(self.settings.get("max_chars") or 80),
                "uptime": int(time.time() - self.started_at),
                "groups": groups,
            },
        }

    async def api_config(self):
        payload = await request.json(default={})
        if not isinstance(payload, dict):
            return {"status": "error", "message": "请求体应为 JSON 对象"}
        if "peer_qq" in payload:
            raw = payload.get("peer_qq")
            if isinstance(raw, (list, tuple, set)):
                raw = ",".join(str(item) for item in raw)
            parts = [item.strip() for item in str(raw or "").replace("，", ",").split(",")]
            parts = [item for item in parts if item]
            if any(not item.isdigit() for item in parts):
                return {"status": "error", "message": "机器人 QQ 号只能是数字，多个用逗号分隔"}
            self.settings["peer_qq"] = ",".join(parse_peer_ids(parts))
        if "self_qq" in payload:
            value = str(payload.get("self_qq") or "").strip()
            if value and not value.isdigit():
                return {"status": "error", "message": "本机机器人 QQ 号只能是数字"}
            if value:
                self.self_qq = value
                self.login_at = time.time()
                self.login_error = ""
        if "filter_enabled" in payload:
            self.settings["filter_enabled"] = bool(payload.get("filter_enabled"))
        if "max_chars" in payload:
            self.settings["max_chars"] = max(20, min(int(payload.get("max_chars") or 80), 200))
        if "temperature" in payload:
            self.settings["temperature"] = max(
                0.0, min(float(payload.get("temperature") or 0.9), 1.5)
            )
        self._save_settings()
        self_qq, nickname = await self._login()
        return {
            "status": "ok",
            "data": {
                "self_qq": self_qq,
                "nickname": nickname,
                "peer_qqs": self.peer_ids,
                "filter_enabled": bool(self.settings.get("filter_enabled", True)),
                "max_chars": int(self.settings.get("max_chars") or 80),
            },
        }

    async def api_activity(self):
        group_id = str(request.query.get("group_id", "") or "")
        since = float(request.query.get("since", 0) or 0)
        if not group_id:
            return {"status": "error", "message": "缺少 group_id"}
        state = self.activity.get(group_id) or {"events": [], "seq": 0}
        return {"status": "ok", "data": group_activity_view(state, since=since)}

    async def api_send(self):
        payload = await request.json(default={})
        if not isinstance(payload, dict):
            return {"status": "error", "message": "请求体应为 JSON 对象"}
        group_id = str(payload.get("group_id") or "").strip()
        if not group_id.isdigit() or not 4 <= len(group_id) <= 13:
            return {"status": "error", "message": "群号必须是 4-13 位数字"}
        text = clean_reply(
            payload.get("text"),
            max_chars=int(self.settings.get("max_chars") or 80),
        )
        if not text:
            return {"status": "error", "message": "发送内容为空"}
        try:
            message_id = await self._send(group_id, text)
        except Exception as exc:
            return {"status": "error", "message": f"发送失败：{exc}"}
        self_qq, _ = await self._login()
        return {
            "status": "ok",
            "data": {"message_id": message_id, "self_qq": self_qq, "text": text},
        }

    async def _generate(self, payload: dict) -> tuple[str, str, str]:
        group_id = str(payload.get("group_id") or "").strip()
        topic = sanitize(payload.get("topic"), max_chars=120)
        transcript = payload.get("transcript") or []
        if not group_id.isdigit():
            raise ValueError("群号无效")
        if not isinstance(transcript, list):
            raise ValueError("transcript 应为数组")
        self_name = sanitize(payload.get("self_name"), max_chars=32) or self.nickname or "我"
        peer_name = sanitize(payload.get("peer_name"), max_chars=32) or "另一个机器人"
        turn = int(payload.get("turn") or 1)
        max_chars = max(20, min(int(payload.get("max_chars") or self.settings.get("max_chars") or 80), 200))

        provider = await self.context.get_using_provider_async()
        if provider is None:
            raise RuntimeError("当前没有可用的对话模型")
        provider_id = str(provider.meta().id)
        persona_prompt = ""
        persona_name = ""
        try:
            persona = await self.context.persona_manager.get_default_persona_v3()
            persona_name = str(persona.get("name") or "") if isinstance(persona, dict) else ""
            persona_prompt = str(persona.get("prompt") or "") if isinstance(persona, dict) else ""
        except Exception:
            persona_prompt = ""

        prompt = build_prompt(topic, transcript, self_name, peer_name, turn, max_chars)
        names = [self_name, peer_name, self.nickname]
        last_error = ""
        for attempt in range(2):
            request_prompt = prompt
            if attempt:
                request_prompt += "\n\n上一句没有通过检查：必须只输出一句完整中文口语，不能为空。"
            try:
                response = await asyncio.wait_for(
                    self.context.llm_generate(
                        chat_provider_id=provider_id,
                        prompt=request_prompt,
                        system_prompt=persona_prompt or None,
                        max_tokens=320,
                        temperature=float(self.settings.get("temperature") or 0.9),
                    ),
                    timeout=90,
                )
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                logger.warning("[群聊剧场] 第 %s 次生成失败：%s", attempt + 1, last_error)
                continue
            text = clean_reply(
                getattr(response, "completion_text", ""),
                max_chars=max_chars,
                names=names,
            )
            if text:
                return text, provider_id, persona_name
            last_error = "模型没有输出可用正文"
        raise RuntimeError(last_error or "生成失败")

    async def api_cancel(self):
        payload = await request.json(default={})
        scene_id = str(payload.get("scene_id") or "").strip()
        if not scene_id:
            return {"status": "error", "message": "缺少 scene_id"}
        self.cancelled_scenes.add(scene_id)
        if len(self.cancelled_scenes) > 100:
            self.cancelled_scenes = set(list(self.cancelled_scenes)[-100:])
        return {"status": "ok", "data": {"cancelled": scene_id}}

    async def api_speak(self):
        payload = await request.json(default={})
        if not isinstance(payload, dict):
            return {"status": "error", "message": "请求体应为 JSON 对象"}
        scene_id = str(payload.get("scene_id") or "").strip()
        if scene_id and scene_id in self.cancelled_scenes:
            return {"status": "error", "message": "场景已结束"}
        if self.speak_lock.locked():
            return {"status": "error", "message": "上一句还在生成"}
        async with self.speak_lock:
            try:
                text, provider_id, persona_name = await self._generate(payload)
                if scene_id and scene_id in self.cancelled_scenes:
                    return {"status": "error", "message": "场景已结束，未发送"}
                message_id = await self._send(str(payload.get("group_id")), text)
            except Exception as exc:
                return {"status": "error", "message": str(exc)}
        self_qq, nickname = await self._login()
        return {
            "status": "ok",
            "data": {
                "text": text,
                "message_id": message_id,
                "self_qq": self_qq,
                "nickname": nickname,
                "provider": provider_id,
                "persona": persona_name,
            },
        }
