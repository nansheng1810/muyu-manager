"""群聊剧场插件的纯函数：文本清理、发言输入组装、活动游标。"""

from __future__ import annotations

import re

CQ_RE = re.compile(r"\[CQ:[^\]]*\]")
URL_RE = re.compile(r"https?://\S+", re.IGNORECASE)
MENTION_RE = re.compile(r"@[^\s，。！？、,:：]{1,32}")
SPEAKER_RE = re.compile(r"^\s*[^\s：:]{1,16}\s*[：:]\s*")
QUOTES = "「」『』“”\"'‘’"
MIN_REPLY_CHARS = 2


def sanitize(text, max_chars=200):
    value = str(text or "")
    value = CQ_RE.sub("", value)
    value = URL_RE.sub("", value)
    value = MENTION_RE.sub("", value)
    value = re.sub(r"\s+", " ", value).strip()
    limit = max(1, int(max_chars))
    return value[:limit].strip()


def parse_peer_ids(value):
    if isinstance(value, (list, tuple, set)):
        parts = [str(item) for item in value]
    else:
        parts = re.split(r"[,，;；\s]+", str(value or ""))
    out = []
    for part in parts:
        digits = part.strip()
        if digits.isdigit() and 4 <= len(digits) <= 13 and digits not in out:
            out.append(digits)
    return out


def is_bot_sender(sender_id, self_id, peer_ids):
    sender = str(sender_id or "")
    if not sender:
        return False
    return sender in {str(self_id or ""), *{str(item) for item in peer_ids or []}}


def strip_speaker_prefix(text, names=()):
    known = {str(name).strip() for name in names if str(name).strip()}
    if not known:
        return str(text or "").strip()
    value = str(text or "").strip()
    for _ in range(2):
        match = SPEAKER_RE.match(value)
        if not match:
            break
        prefix = match.group(0).strip().rstrip("：:")
        if prefix not in known:
            break
        value = value[match.end():].lstrip()
    return value


def clean_reply(text, max_chars=80, names=()):
    value = str(text or "").replace("```", "").strip()
    lines = [line.strip() for line in value.splitlines() if line.strip()]
    value = lines[0] if lines else ""
    value = sanitize(value, max_chars=max_chars * 2)
    value = strip_speaker_prefix(value, names)
    value = value.strip().strip(QUOTES).strip()
    value = re.sub(r"^[-*·]\s*", "", value)
    if len(value) < MIN_REPLY_CHARS:
        return ""
    if len(value) > max_chars:
        value = value[:max_chars].rstrip()
    if value.endswith(("，", ",", "、", "：", ":")):
        value = value[:-1].rstrip()
    return value


def transcript_lines(transcript, limit=12):
    lines = []
    for item in list(transcript or [])[-max(1, int(limit)):]:
        if not isinstance(item, dict):
            continue
        speaker = str(item.get("speaker_name") or item.get("speaker") or "").strip()
        text = sanitize(item.get("text"), max_chars=200)
        if not speaker or not text:
            continue
        lines.append(f"{speaker}：{text}")
    return lines


def build_prompt(topic, transcript, self_name, peer_name, turn=1, max_chars=80):
    history = transcript_lines(transcript)
    header = (
        f"群聊话题：{sanitize(topic, max_chars=120) or '随便聊聊'}\n"
        f"你是「{self_name}」，正在 QQ 群里和「{peer_name}」聊天。"
    )
    context = (
        "最近对话（按时间顺序）：\n" + "\n".join(history)
        if history
        else "群里现在还没人说话，由你先开口。"
    )
    rules = (
        f"现在轮到你（{self_name}）说第 {int(turn)} 句。只写这一句中文口语，"
        f"目标 {max(4, min(int(max_chars), 120))} 字以内：\n"
        "- 接着上文说，别复读对方刚说过的话；可以接梗、追问或补一个具体细节。\n"
        "- 不加名字前缀、引号、括号动作、表情包说明、链接、@、话题标签。\n"
        "- 不提 AI、模型、插件、管理器、剧场，也不解释这段要求。\n"
        "- 保持你平时说话的习惯和人格。"
    )
    return f"{header}\n{context}\n\n{rules}"


def activity_since(events, since):
    value = float(since or 0)
    return [item for item in events if float(item.get("ts") or 0) > value]


def group_activity_view(state, since=0.0):
    events = activity_since(state.get("events") or [], since)
    last = state.get("events")[-1] if state.get("events") else None
    return {
        "events": events,
        "last_ts": float(last.get("ts") or 0) if last else 0.0,
        "last_sender": str(last.get("sender") or "") if last else "",
        "seq": int(state.get("seq") or 0),
    }
