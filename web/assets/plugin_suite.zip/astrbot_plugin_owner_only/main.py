"""主人专属指令：非主人发指令一律静默丢弃，不回复。

判定主人以 AstrBot 配置里的 admins_id 为准（waking_check 阶段会把主人的
event.role 设为 admin）。插件只拦「指令」，群里 @ 机器人闲聊、私聊普通
对话都照常交给模型回复。
"""

import re
import sys

from astrbot import logger
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Context, Star
from astrbot.core.star.filter.command import CommandFilter
from astrbot.core.star.filter.command_group import CommandGroupFilter
from astrbot.core.star.star_handler import EventType, star_handlers_registry


class OwnerOnly(Star):
    def __init__(self, context: Context) -> None:
        super().__init__(context)

    def _command_names(self) -> set[str]:
        """收集当前已注册的全部指令名（含别名、子指令、指令组）。"""
        names: set[str] = set()
        for handler in star_handlers_registry.get_handlers_by_event_type(
            EventType.AdapterMessageEvent,
        ):
            for f in handler.event_filters:
                if isinstance(f, (CommandFilter, CommandGroupFilter)):
                    names.update(f.get_complete_command_names())
        return names

    def _is_command(self, event: AstrMessageEvent) -> bool:
        """判断这条消息是不是在发指令。

        两种情况算指令：
        1. 原始文本以唤醒前缀（默认 "/"）开头；
        2. 去掉唤醒前缀后的文本命中已注册的指令名（兼容私聊里不带 "/" 的写法）。
        """
        raw = (getattr(event.message_obj, "message_str", "") or "").strip()
        prefixes = [p for p in self.context.get_config().get("wake_prefix", []) if p]
        if any(raw.startswith(p) for p in prefixes):
            return True

        text = re.sub(r"\s+", " ", (event.get_message_str() or "").strip())
        for name in self._command_names():
            if text == name or text.startswith(name + " "):
                return True
        return False

    @filter.event_message_type(filter.EventMessageType.ALL, priority=sys.maxsize - 1)
    async def block_foreign_command(self, event: AstrMessageEvent):
        if event.is_admin():
            return
        if not self._is_command(event):
            return

        event.clear_result()
        event.stop_event()
        logger.info(
            f"[owner_only] 已静默忽略非主人指令：{event.get_sender_id()} "
            f"({event.get_sender_name()}) 在 {event.unified_msg_origin} 发送 "
            f"{event.get_message_str()[:50]!r}",
        )
