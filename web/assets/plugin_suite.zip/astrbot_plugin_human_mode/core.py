"""拟人插件的纯函数：计划解析、沉默判定、提示词拼接、文本分段与消息链判断。"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path

DEFAULT_MANAGER_URL = "http://127.0.0.1:7311"


def resolve_manager_url(configured="", default=DEFAULT_MANAGER_URL) -> str:
    """解析管理器地址：显式非默认配置优先，否则读管理器写出的运行时端口。"""
    value = str(configured or "").strip().rstrip("/")
    default_text = str(default or DEFAULT_MANAGER_URL).rstrip("/")
    if value and value != default_text:
        return value
    try:
        base = Path(os.environ.get("LOCALAPPDATA") or str(Path.home()))
        path = base / "AstrBot舰队管理器" / "data" / "manager_runtime.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        url = str(data.get("url") or "").strip().rstrip("/")
        if url.startswith(("http://127.0.0.1:", "http://localhost:")):
            return url
    except (OSError, ValueError, TypeError):
        pass
    return value or default_text


def platform_of(name) -> str:
    """把 AstrBot 平台名映射为管理器使用的平台标识。

    Args:
        name: AstrBot 平台名，例如 ``aiocqhttp``、``bilibili``。

    Returns:
        空串/``aiocqhttp``/``qq``/``qq_official`` 返回 ``qq``；
        名称含 ``bili`` 返回 ``bilibili``，含 ``douyin`` 返回 ``douyin``；
        其它平台返回空串，由调用方跳过，避免误报成 QQ。
    """
    text = str(name or "").strip().lower()
    if text in ("", "aiocqhttp", "qq", "qq_official"):
        return "qq"
    if "bili" in text:
        return "bilibili"
    if "douyin" in text:
        return "douyin"
    return ""


def parse_plan(body) -> dict | None:
    """解析管理器返回的计划响应。

    Args:
        body: 管理器返回的 JSON 数据。

    Returns:
        合法计划；``action`` 不在允许集合或 ``shadow`` 不是 bool 时返回 None。
        缺 ``shadow`` 字段按无效处理，避免把未知计划当成真实执行。
    """
    if not isinstance(body, dict):
        return None
    data = body.get("data")
    if not isinstance(data, dict):
        return None
    if str(data.get("action") or "") not in {"reply", "short", "split", "delay", "silence"}:
        return None
    if not isinstance(data.get("shadow"), bool):
        return None
    return data


def should_stop(plan, is_owner: bool, command: bool, trigger: str) -> bool:
    """判断本轮是否应真实沉默。

    Args:
        plan: parse_plan 返回的计划。
        is_owner: 发送者是否为主人或管理员。
        command: 消息是否以唤醒/指令前缀开头。
        trigger: 触发类型，取 private/at/group。

    Returns:
        仅当计划为真实 silence、非主人、非指令且 trigger 为 private/at 时返回 True。
    """
    if not isinstance(plan, dict):
        return False
    if plan.get("action") != "silence":
        return False
    if plan.get("shadow") is not False:
        return False
    if is_owner or command:
        return False
    return trigger in ("private", "at")


def prompt_extra(plan) -> str:
    """拼接计划要追加到系统提示词的内容。

    Args:
        plan: parse_plan 返回的计划。

    Returns:
        style_block；只有 ``shadow is False`` 才追加 behavior_hint，二者以两个换行连接。
    """
    if not isinstance(plan, dict):
        return ""
    style = str(plan.get("style_block") or "")
    hint = ""
    if plan.get("shadow") is False:
        hint = str(plan.get("behavior_hint") or "")
    return "\n\n".join(x for x in (style, hint) if x)


def is_plain_text_chain(chain) -> bool:
    if not chain:
        return False
    return all(type(component).__name__ == "Plain" for component in chain)


def split_text(text: str, max_chunks: int = 3, max_chars: int = 120) -> list[str]:
    """按句切分文本并合并为不超过上限的若干段。

    Args:
        text: 待分段文本。
        max_chunks: 最大块数，夹取到 1–3。
        max_chars: 单块最大字符数，夹取到 20–120。

    Returns:
        每块都不超过 ``max_chars`` 且块数不超过 ``max_chunks`` 的列表；
        当总长超过 ``max_chunks * max_chars`` 或无法合并时返回 ``[raw]``，
        作为“整条发送”的信号，绝不返回超长末段。
    """
    raw = str(text or "").strip()
    if not raw:
        return []
    max_chunks = max(1, min(3, int(max_chunks or 3)))
    max_chars = max(20, min(120, int(max_chars or 120)))
    # 总长超过可容量时不做分段，交给调用方整条发送。
    if len(raw) > max_chunks * max_chars:
        return [raw]
    pieces: list[str] = []
    for sentence in re.split(r"(?<=[。！？!?…\n])", raw):
        sentence = sentence.strip()
        while len(sentence) > max_chars:
            pieces.append(sentence[:max_chars])
            sentence = sentence[max_chars:]
        if sentence:
            pieces.append(sentence)
    # 顺序贪心合并相邻块：能塞进当前块就合并，塞不下则开新块。
    # 这样每个块都取到不超过 max_chars 的最大前缀，块数最少。
    chunks: list[str] = []
    current = ""
    for piece in pieces:
        if not current:
            current = piece
        elif len(current) + len(piece) <= max_chars:
            current += piece
        else:
            chunks.append(current)
            current = piece
    if current:
        chunks.append(current)
    if len(chunks) > max_chunks:
        return [raw]
    return chunks


def plan_key(event) -> str:
    message_id = getattr(getattr(event, "message_obj", None), "message_id", "") or ""
    return f"{getattr(event, 'unified_msg_origin', '')}:{message_id or id(event)}"
