"""拟人模式：风格注入、影子计划、真实沉默/分段/延迟。"""

from __future__ import annotations

import asyncio
import json
import sys
import time
import urllib.request

from astrbot import logger
from astrbot.api.event import AstrMessageEvent, MessageChain, filter
from astrbot.api.star import Context, Star

from .core import (
    is_plain_text_chain,
    parse_plan,
    plan_key,
    platform_of,
    prompt_extra,
    resolve_manager_url,
    should_stop,
    split_text,
)

NAME = "astrbot_plugin_human_mode"
DEFAULT_MANAGER_URL = "http://127.0.0.1:7311"
PLAN_PATH = "/api/human/plan"
PLAN_TTL = 120
PLAN_WAIT = 4
MAX_SLEEP_MS = 4000


class HumanMode(Star):
    def __init__(self, context: Context, config=None):
        super().__init__(context)
        self.config = config or {}
        self.plans = {}
        self.failing = False

    def _cfg(self, key, default):
        return self.config.get(key, default)

    def _owner(self, event) -> bool:
        try:
            if event.is_admin():
                return True
        except Exception:
            pass
        owners = {
            x.strip()
            for x in str(self._cfg("owner_ids", "") or "")
            .replace("，", ",")
            .split(",")
            if x.strip()
        }
        try:
            return str(event.get_sender_id()) in owners
        except Exception:
            return False

    def _raw_text(self, event) -> str:
        """读取唤醒前缀剥离前的纯文本，用于识别 `/`、`／` 指令。

        AstrBot 的 waking 阶段会改掉 event.message_str，但 message_obj.message_str
        仍是原始文本；因此这里优先读消息对象，读不到再拼接 Plain 组件。

        Args:
            event: 当前消息事件。

        Returns:
            原始纯文本；任何异常或读不到时返回空串。
        """
        try:
            obj = getattr(event, "message_obj", None)
            raw = str(getattr(obj, "message_str", "") or "").strip()
            if raw:
                return raw
            components = getattr(obj, "message", None) or []
            return "".join(
                str(getattr(x, "text", "") or "")
                for x in components
                if type(x).__name__ == "Plain"
            ).strip()
        except Exception:
            return ""

    def _trigger(self, event) -> tuple[str, bool]:
        text = str(event.message_str or "").strip()
        raw = self._raw_text(event)
        prefixes = [
            x.strip()
            for x in str(self._cfg("wake_prefixes", "/,／") or "")
            .replace("，", ",")
            .split(",")
            if x.strip()
        ]
        command = any(
            candidate.startswith(prefix)
            for candidate in (raw, text)
            for prefix in prefixes
        )
        try:
            private = event.is_private_chat()
        except Exception:
            private = False
        if private:
            return "private", command
        if bool(event.is_at_or_wake_command):
            return "at", command
        return "group", command

    async def _plan(self, payload: dict):
        """请求管理器生成计划，返回原始 JSON 响应。

        解析放到调用方，这样请求成功但计划字段不合法时也能清除失败标记。

        Args:
            payload: 计划请求体。

        Returns:
            管理器返回的 JSON 数据。

        Raises:
            Exception: 请求失败、超时或响应不是合法 JSON。
        """
        base = resolve_manager_url(
            self._cfg("manager_url", DEFAULT_MANAGER_URL)).rstrip("/")
        timeout = float(self._cfg("timeout_sec", 3) or 3)
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")

        def call():
            req = urllib.request.Request(
                base + PLAN_PATH,
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=timeout) as response:
                return json.loads(response.read().decode("utf-8", "replace"))

        return await asyncio.to_thread(call)

    # 心情插件先跑（sys.maxsize），这里后跑，行为计划才能读到本条消息评估后的心情。
    @filter.on_llm_request(priority=sys.maxsize - 1)
    async def inject_and_gate(self, event: AstrMessageEvent, req):
        try:
            platform_name = str(event.get_platform_name() or "")
        except Exception:
            platform_name = ""
        platform = platform_of(platform_name)
        if not platform:
            return
        if not self._cfg("enabled", True):
            return
        umo = str(event.unified_msg_origin)
        sender_id = str(event.get_sender_id() or "")
        try:
            sender_name = str(event.get_sender_name() or "")
        except Exception:
            sender_name = ""
        is_owner = self._owner(event)
        trigger, command = self._trigger(event)
        payload = {
            "instance_id": str(self._cfg("instance_id", "") or ""),
            "platform_id": umo.split(":", 1)[0] if ":" in umo else "",
            "platform": platform,
            "thread_key": umo,
            "person_key": sender_id,
            "sender_name": sender_name,
            "text": str(event.message_str or ""),
            "is_owner": is_owner,
            "trigger": trigger,
            "command": command,
            "tool_call": False,
        }
        result = None
        try:
            body = await asyncio.wait_for(self._plan(payload), timeout=PLAN_WAIT)
            # 请求成功即视为管理器可用；计划字段不合法也不应再报“不可达”。
            self.failing = False
            result = parse_plan(body)
        except Exception as exc:
            if not self.failing:
                self.failing = True
                logger.warning("[拟人模式] 管理器不可达，本轮正常回复：%s", exc)
        if not result:
            return
        self.plans[plan_key(event)] = (result, time.time())
        # 只有真实 silence、非主人、非指令且私聊/@ 触发才终止本轮。
        if should_stop(result, is_owner, command, trigger):
            event.stop_event()
            return
        extra = prompt_extra(result)
        if extra:
            req.system_prompt = (req.system_prompt or "") + "\n\n" + extra

    def _take_plan(self, event):
        key = plan_key(event)
        item = self.plans.pop(key, None)
        now = time.time()
        for old_key, (_, created) in list(self.plans.items()):
            if now - created > PLAN_TTL:
                self.plans.pop(old_key, None)
        if not item or now - item[1] > PLAN_TTL:
            return None
        return item[0]

    @filter.on_decorating_result(priority=10000)
    async def shape_reply(self, event: AstrMessageEvent):
        if not self._cfg("enabled", True):
            return
        plan = self._take_plan(event)
        if not plan or plan.get("shadow"):
            return
        action = plan.get("action")
        if action not in ("split", "delay"):
            return
        result = event.get_result()
        if not result or not is_plain_text_chain(result.chain):
            return
        text = "".join(str(getattr(x, "text", "")) for x in result.chain)
        if not text.strip():
            return
        try:
            delays = [max(0, int(x or 0)) for x in (plan.get("delays_ms") or [])]
        except (TypeError, ValueError):
            delays = []
        if action == "delay":
            wait = min(delays[0] if delays else 0, MAX_SLEEP_MS)
            if wait:
                await asyncio.sleep(wait / 1000)
            return
        try:
            chunks = split_text(
                text,
                plan.get("max_chunks", 3),
                plan.get("chunk_max_chars", 120),
            )
        except (TypeError, ValueError):
            return
        # [raw] 是“整条发送”信号；只有一段时分段也没有意义。
        if len(chunks) <= 1:
            return
        original = list(result.chain)
        result.chain = []
        sent = 0
        # 延迟合计不超过计划给出的 delays_ms，避免超时被放大。
        remaining = sum(delays)
        try:
            for index, chunk in enumerate(chunks):
                if index:
                    wait = delays[index - 1] if index - 1 < len(delays) else 700
                    wait = max(0, min(MAX_SLEEP_MS, wait, remaining))
                    if wait:
                        await asyncio.sleep(wait / 1000)
                        remaining -= wait
                await event.send(MessageChain().message(chunk))
                sent += 1
        except Exception as exc:
            logger.warning("[拟人模式] 分段发送失败：%s", exc)
            if sent == 0:
                result.chain = original
