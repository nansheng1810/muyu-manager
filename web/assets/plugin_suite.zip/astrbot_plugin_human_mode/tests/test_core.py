import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from core import (
    is_plain_text_chain,
    parse_plan,
    plan_key,
    platform_of,
    prompt_extra,
    resolve_manager_url,
    should_stop,
    split_text,
)


class PlatformOfTest(unittest.TestCase):
    def test_qq_platforms_map_to_qq(self):
        self.assertEqual(platform_of(""), "qq")
        self.assertEqual(platform_of("aiocqhttp"), "qq")
        self.assertEqual(platform_of("qq"), "qq")
        self.assertEqual(platform_of("qq_official"), "qq")

    def test_bilibili_platform(self):
        self.assertEqual(platform_of("bilibili"), "bilibili")

    def test_douyin_platform(self):
        self.assertEqual(platform_of("douyin"), "douyin")

    def test_unknown_platform_is_unsupported(self):
        self.assertEqual(platform_of("telegram"), "")


class CoreTest(unittest.TestCase):
    def test_parse_plan(self):
        plan = {"action": "silence", "shadow": False}
        self.assertEqual(parse_plan({"data": plan}), plan)
        # 缺 shadow 不能默认成真实执行。
        self.assertIsNone(parse_plan({"data": {"action": "silence"}}))
        self.assertIsNone(
            parse_plan({"data": {"action": "silence", "shadow": "false"}})
        )
        self.assertIsNone(parse_plan({"data": {}}))
        self.assertIsNone(parse_plan(None))

    def test_should_stop(self):
        plan = {"action": "silence", "shadow": False}
        self.assertTrue(should_stop(plan, False, False, "private"))
        self.assertFalse(should_stop({**plan, "shadow": True}, False, False, "private"))
        self.assertFalse(should_stop(plan, True, False, "private"))
        self.assertFalse(should_stop(plan, False, True, "private"))
        self.assertFalse(should_stop(plan, False, False, "group"))

    def test_prompt_extra(self):
        plan = {"shadow": True, "style_block": "STYLE", "behavior_hint": "HINT"}
        self.assertEqual(prompt_extra(plan), "STYLE")
        self.assertEqual(prompt_extra({**plan, "shadow": False}), "STYLE\n\nHINT")
        self.assertEqual(prompt_extra({}), "")

    def test_split_text_respects_limits(self):
        text = "第一句。第二句！第三句？第四句。" * 10
        chunks = split_text(text, max_chunks=3, max_chars=120)
        self.assertLessEqual(len(chunks), 3)
        self.assertTrue(all(len(x) <= 120 for x in chunks))
        self.assertEqual("".join(chunks).replace("\n", ""), text.replace("\n", ""))

    def test_split_text_too_long_returns_raw(self):
        text = "长" * 500
        self.assertEqual(split_text(text, max_chunks=3, max_chars=120), [text])

    def test_split_text_three_hundred_chars(self):
        text = "第一句。" * 75
        chunks = split_text(text, max_chunks=3, max_chars=120)
        self.assertLessEqual(len(chunks), 3)
        self.assertTrue(all(len(x) <= 120 for x in chunks))
        self.assertEqual("".join(chunks), text)

    def test_split_text_single_short(self):
        self.assertEqual(split_text("在的"), ["在的"])

    def test_is_plain_text_chain(self):
        class Plain:
            pass

        class Image:
            pass

        self.assertTrue(is_plain_text_chain([Plain(), Plain()]))
        self.assertFalse(is_plain_text_chain([Plain(), Image()]))
        self.assertFalse(is_plain_text_chain([]))


class PlanKeyTest(unittest.TestCase):
    def test_plan_key_uses_origin_and_message_id(self):
        class Message:
            message_id = 42

        class Event:
            unified_msg_origin = "aiocqhttp:FriendMessage:10001"
            message_obj = Message()

        self.assertEqual(plan_key(Event()), "aiocqhttp:FriendMessage:10001:42")

    def test_plan_key_falls_back_to_event_id(self):
        class Event:
            unified_msg_origin = "aiocqhttp:GroupMessage:20002"
            message_obj = None

        event = Event()
        self.assertEqual(
            plan_key(event), f"aiocqhttp:GroupMessage:20002:{id(event)}"
        )


class HookPriorityTest(unittest.TestCase):
    def test_human_hook_runs_after_mood(self):
        source = (Path(__file__).resolve().parents[1] / "main.py").read_text(encoding="utf-8")
        self.assertIn("priority=sys.maxsize - 1", source)


class ResolveManagerUrlTest(unittest.TestCase):
    def test_runtime_file_overrides_default_port(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "AstrBot舰队管理器" / "data"
            data.mkdir(parents=True)
            (data / "manager_runtime.json").write_text(
                '{"url": "http://127.0.0.1:7312"}', encoding="utf-8")
            with patch.dict(os.environ, {"LOCALAPPDATA": tmp}):
                self.assertEqual(
                    resolve_manager_url("http://127.0.0.1:7311"),
                    "http://127.0.0.1:7312",
                )


if __name__ == "__main__":
    unittest.main()
