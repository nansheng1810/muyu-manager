"""思考过程桥接：把模型逐字流式输出推送到 AstrBot 舰队管理器。

原理：包装 ProviderOpenAIOfficial._query_stream，原样转发每个 chunk 给
AstrBot，同时把 chunk 里的 reasoning_content / 正文增量异步 POST 到管理器
的 /api/live-think/ingest，由管理器广播给「实时思考」页面。
"""

import asyncio
import time
import uuid
from pathlib import Path

import httpx

from astrbot import logger
from astrbot.api.star import Context, Star
from astrbot.core.provider.sources.openai_source import ProviderOpenAIOfficial

MANAGER_PORTS = range(7311, 7341)
PROBE_TIMEOUT = 0.45
PUSH_TIMEOUT = 3.0
RETRY_INTERVAL = 20.0

BRIDGE = None


def _trace(root: str, text: str) -> None:
    """写诊断日志到 data/think_bridge.log（AstrBot 控制台不可见时用它排查）。"""
    try:
        path = Path(root) / "data" / "think_bridge.log"
        if path.exists() and path.stat().st_size > 512 * 1024:
            path.write_text("", encoding="utf-8")
        with path.open("a", encoding="utf-8") as fh:
            fh.write(f"{time.strftime('%H:%M:%S')} {text}\n")
    except Exception:  # noqa: BLE001
        pass


class ThinkBridge(Star):
    def __init__(self, context: Context, config=None):
        super().__init__(context, config)
        self.root = str(Path(__file__).resolve().parents[3])
        self._base = ""
        self._probed_at = 0.0
        self._queue: asyncio.Queue | None = None
        self._worker: asyncio.Task | None = None
        _trace(self.root, "插件已加载")
        self._patch()

    # ---------------------------------------------------------- 拦截模型流
    def _patch(self) -> None:
        global BRIDGE
        BRIDGE = self
        cls = ProviderOpenAIOfficial
        if getattr(cls, "_think_bridge_patched", False):
            # 热重载时复用已有包装，避免层层嵌套
            logger.info("[think_bridge] 拦截器已存在，跳过重复挂载")
            _trace(self.root, "拦截器已存在，跳过重复挂载")
            return
        original = cls._query_stream
        cls._think_bridge_original = original

        async def _query_stream(provider, *args, **kwargs):
            run_id = uuid.uuid4().hex[:10]
            logger.debug(f"[think_bridge] 捕获模型调用 {run_id}")
            _trace(BRIDGE.root if BRIDGE else "", f"捕获模型调用 {run_id}")
            conversation_id = str(kwargs.get("conversation_id") or "")
            try:
                model = str(provider.get_model() or "")
            except Exception:  # noqa: BLE001
                model = ""
            if not model:
                cfg = getattr(provider, "provider_config", {}) or {}
                model = str(cfg.get("model") or "")

            bridge = BRIDGE
            if bridge is not None:
                bridge._emit(
                    {
                        "run_id": run_id,
                        "source": bridge.root,
                        "model": model,
                        "conversation_id": conversation_id,
                    }
                )

            error = ""
            try:
                async for response in original(provider, *args, **kwargs):
                    if getattr(response, "is_chunk", False):
                        reasoning = getattr(response, "reasoning_content", None) or ""
                        try:
                            content = response.completion_text or ""
                        except Exception:  # noqa: BLE001
                            content = ""
                        bridge = BRIDGE
                        if bridge is not None and (reasoning or content):
                            bridge._emit(
                                {
                                    "run_id": run_id,
                                    "source": bridge.root,
                                    "reasoning_delta": reasoning,
                                    "content_delta": content,
                                }
                            )
                    yield response
            except GeneratorExit:
                # 调用方读完后主动关闭生成器，属正常收尾
                raise
            except asyncio.CancelledError:
                error = "已取消"
                raise
            except Exception as exc:  # noqa: BLE001
                error = f"{type(exc).__name__}: {exc}"
                raise
            finally:
                bridge = BRIDGE
                if bridge is not None:
                    bridge._emit(
                        {
                            "run_id": run_id,
                            "source": bridge.root,
                            "done": True,
                            "error": error,
                        }
                    )

        cls._query_stream = _query_stream
        cls._think_bridge_patched = True
        logger.info("[think_bridge] 已挂载模型流式拦截")
        _trace(self.root, "已挂载模型流式拦截")

    def _unpatch(self) -> None:
        global BRIDGE
        BRIDGE = None
        cls = ProviderOpenAIOfficial
        original = getattr(cls, "_think_bridge_original", None)

        # 仅当补丁仍是我们装的才还原
        if getattr(cls, "_think_bridge_patched", False):
            if original is not None:
                cls._query_stream = original
                del cls._think_bridge_original
            cls._think_bridge_patched = False

    # ------------------------------------------------------------ 推送队列
    def _emit(self, payload: dict) -> None:
        """把一条事件放进队列，由后台任务串行发送（不阻塞模型流）。"""
        try:
            loop = asyncio.get_running_loop()
            if self._queue is None:
                self._queue = asyncio.Queue(maxsize=3000)
            if self._worker is None or self._worker.done():
                self._worker = loop.create_task(self._run())
            packet = dict(payload)
            packet.setdefault("ts", time.time())
            try:
                self._queue.put_nowait(packet)
            except asyncio.QueueFull:
                try:
                    self._queue.get_nowait()
                    self._queue.put_nowait(packet)
                except Exception:  # noqa: BLE001
                    pass
        except Exception as exc:  # noqa: BLE001
            logger.debug(f"[think_bridge] 事件入队失败：{exc}")

    async def _run(self) -> None:
        timeout = httpx.Timeout(PUSH_TIMEOUT, connect=1.0)
        try:
            async with httpx.AsyncClient(timeout=timeout, trust_env=False) as client:
                _trace(self.root, "推送任务已启动")
                while True:
                    packet = await self._queue.get()
                    base = await self._base_url(client)
                    if not base:
                        continue
                    try:
                        resp = await client.post(
                            f"{base}/api/live-think/ingest", json=packet
                        )
                        if resp.status_code >= 400:
                            logger.debug(f"[think_bridge] 管理器返回 {resp.status_code}")
                            _trace(self.root, f"管理器返回 {resp.status_code}")
                        elif packet.get("done"):
                            _trace(self.root, f"推送完成 run={packet.get('run_id')}")
                    except Exception as exc:  # noqa: BLE001
                        self._base = ""
                        logger.debug(f"[think_bridge] 推送失败：{exc}")
                        _trace(self.root, f"推送失败：{exc!r}")
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            _trace(self.root, f"推送任务异常退出：{exc!r}")

    async def _base_url(self, client: httpx.AsyncClient) -> str:
        """探测管理器端口（默认 7311-7340），结果缓存；离线时每 20 秒重试。"""
        if self._base:
            return self._base
        now = time.time()
        if now - self._probed_at < RETRY_INTERVAL:
            return ""
        self._probed_at = now
        for port in MANAGER_PORTS:
            try:
                resp = await client.get(
                    f"http://127.0.0.1:{port}/api/live-think/ping",
                    timeout=httpx.Timeout(PROBE_TIMEOUT, connect=PROBE_TIMEOUT),
                )
                if resp.status_code != 200:
                    continue
                data = resp.json().get("data") or {}
                if data.get("app") == "astrbot-manager":
                    self._base = f"http://127.0.0.1:{port}"
                    logger.info(f"[think_bridge] 已连接管理器：{self._base}")
                    _trace(self.root, f"已连接管理器 {self._base}")
                    return self._base
            except Exception:  # noqa: BLE001
                continue
        _trace(self.root, "未找到管理器（7311-7340 无响应）")
        return ""

    async def terminate(self):
        self._unpatch()
        if self._worker is not None:
            self._worker.cancel()
            self._worker = None
        self._queue = None
