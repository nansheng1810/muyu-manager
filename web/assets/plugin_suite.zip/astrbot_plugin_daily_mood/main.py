"""每日心情：每次回复前请牧鱼评估情绪，并注入不超过 240 字的语气块。"""

from __future__ import annotations

import asyncio
import json
import sys
import urllib.request

from astrbot import logger
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Context, Star

from .core import PromptCache, build_payload, parse_observe, platform_of, recent_from_contexts, resolve_manager_url

NAME = "astrbot_plugin_daily_mood"
DEFAULT_MANAGER_URL = "http://127.0.0.1:7311"
OBSERVE_PATH = "/api/mood/observe"
DEFAULT_TIMEOUT = 6
MAX_WAIT = 10


class DailyMood(Star):
    def __init__(self, context: Context, config=None):
        super().__init__(context)
        self.config = config or {}
        self.cache = PromptCache()

    def _cfg(self, key, default):
        return self.config.get(key, default)

    async def _observe(self, payload: dict, timeout_sec: float):
        base = resolve_manager_url(
            self._cfg("manager_url", DEFAULT_MANAGER_URL)).rstrip("/")
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")

        def call():
            req = urllib.request.Request(
                base + OBSERVE_PATH, data=body,
                headers={"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(req, timeout=timeout_sec) as response:
                return json.loads(response.read().decode("utf-8", "replace"))

        return await asyncio.to_thread(call)

    async def _provider_id(self, event) -> str:
        configured = str(self._cfg("provider_id", "") or "").strip()
        if configured:
            return configured
        try:
            return await self.context.get_current_chat_provider_id(event.unified_msg_origin)
        except Exception:
            return ""

    def _owner(self, event) -> bool:
        try:
            if event.is_admin():
                return True
        except Exception:
            pass
        raw = str(self._cfg("owner_ids", "") or "")
        owners = {x.strip() for x in raw.replace("，", ",").split(",") if x.strip()}
        try:
            return str(event.get_sender_id()) in owners
        except Exception:
            return False

    # 必须先于拟人插件评估心情：否则拟人一旦沉默，用户这句道歉/安慰永远进不了心情模型。
    @filter.on_llm_request(priority=sys.maxsize)
    async def inject_mood(self, event: AstrMessageEvent, req):
        try:
            platform_name = str(event.get_platform_name() or "")
        except Exception:
            platform_name = ""
        platform = platform_of(platform_name)
        if not platform:
            return
        if not self._cfg("enabled", True):
            self.cache.clear()
            return
        umo = str(event.unified_msg_origin)
        sender_id = str(event.get_sender_id() or "")
        key = sender_id or umo
        # 冷却期内不再请求管理器，直接用同一会话的缓存
        if not self.cache.cooling():
            try:
                sender_name = str(event.get_sender_name() or "")
            except Exception:
                sender_name = ""
            payload = build_payload({
                "instance_id": str(self._cfg("instance_id", "") or ""),
                "platform_id": umo.split(":", 1)[0] if ":" in umo else "",
                "platform": platform,
                "thread_key": umo,
                "person_key": sender_id,
                "sender_name": sender_name,
                "text": str(event.message_str or ""),
                "is_owner": self._owner(event),
                "provider_id": await self._provider_id(event),
                "recent": recent_from_contexts(getattr(req, "contexts", None)),
            })
            failed = False
            try:
                timeout_sec = float(self._cfg("timeout_sec", DEFAULT_TIMEOUT) or DEFAULT_TIMEOUT)
                data = await asyncio.wait_for(
                    self._observe(payload, timeout_sec),
                    timeout=min(MAX_WAIT, timeout_sec + 1))
            except Exception as exc:
                failed = True
                self.cache.fail()
                logger.warning("[每日心情] 管理器评估失败，使用会话缓存/正常回复：%s", exc)
                data = None
            parsed = parse_observe(data)
            if parsed and parsed.get("enabled") is False:
                self.cache.clear()
                return
            if parsed:
                self.cache.set(key, parsed["prompt_block"])
            elif not failed:
                # 正常返回但没有 prompt_block：只清本会话，不注入旧块
                self.cache.clear(key)
        block = self.cache.get(key)
        if block:
            req.system_prompt = (req.system_prompt or "") + "\n\n" + block
