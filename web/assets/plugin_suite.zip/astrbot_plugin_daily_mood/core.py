"""每日心情插件的纯函数：会话语气块缓存、上下文整理、上报 payload 与响应解析。"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

DEFAULT_MANAGER_URL = "http://127.0.0.1:7311"


def resolve_manager_url(configured="", default=DEFAULT_MANAGER_URL) -> str:
    """解析管理器地址：显式非默认配置优先，否则读管理器写出的运行时端口。

    Args:
        configured: 插件配置里的 manager_url。
        default: 兜底地址。

    Returns:
        去掉末尾斜杠的管理器根地址。
    """
    value = str(configured or "").strip().rstrip("/")
    default_text = str(default or DEFAULT_MANAGER_URL).rstrip("/")
    if value and value != default_text:
        return value
    try:
        base = Path(os.environ.get("LOCALAPPDATA") or str(Path.home()))
        path = base / "AstrBot舰队管理器" / "data" / "manager_runtime.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        url = str(data.get("url") or "").strip().rstrip("/")
        if url.startswith(("http://127.0.0.1:", "http://localhost:")):
            return url
    except (OSError, ValueError, TypeError):
        pass
    return value or default_text


def platform_of(name) -> str:
    """把 AstrBot 平台名映射为管理器使用的平台标识。

    Args:
        name: AstrBot 平台名，例如 ``aiocqhttp``、``bilibili``。

    Returns:
        空串/``aiocqhttp``/``qq``/``qq_official`` 返回 ``qq``；
        名称含 ``bili`` 返回 ``bilibili``，含 ``douyin`` 返回 ``douyin``；
        其它平台返回空串，由调用方跳过，避免误报成 QQ。
    """
    text = str(name or "").strip().lower()
    if text in ("", "aiocqhttp", "qq", "qq_official"):
        return "qq"
    if "bili" in text:
        return "bilibili"
    if "douyin" in text:
        return "douyin"
    return ""


class PromptCache:
    """按会话隔离的语气块缓存，带 TTL 与管理器失败冷却。

    缓存键为 ``person_key or thread_key``，每个键独立保存语气块与更新时间。
    """

    def __init__(self, ttl: float = 1800, fail_ttl: float = 30):
        """初始化缓存。

        Args:
            ttl: 语气块有效期（秒），默认 1800。
            fail_ttl: 管理器失败后跳过请求的冷却时长（秒），默认 30。
        """
        self.ttl = float(ttl)
        self.fail_ttl = float(fail_ttl)
        self._blocks: dict[str, tuple[str, float]] = {}
        self._failed_at = None

    def get(self, key, now=None) -> str:
        """读取指定会话未过期的语气块。

        Args:
            key: 会话键（person_key 或 thread_key）。
            now: 当前时间戳；省略时取 ``time.time()``。

        Returns:
            未过期时返回语气块，无缓存或已过期返回空串。
        """
        item = self._blocks.get(key)
        if not item:
            return ""
        block, updated_at = item
        now = time.time() if now is None else float(now)
        if now - updated_at >= self.ttl:
            return ""
        return block

    def set(self, key, block, now=None) -> None:
        """写入指定会话的语气块。

        Args:
            key: 会话键（person_key 或 thread_key）。
            block: 语气块；空串等于清除该会话缓存。
            now: 写入时间戳；省略时取 ``time.time()``。
        """
        text = str(block or "").strip()
        if not text:
            self.clear(key)
            return
        now = time.time() if now is None else float(now)
        self._blocks[key] = (text, now)

    def clear(self, key=None) -> None:
        """清除缓存。

        Args:
            key: 只清除该会话；省略（或传 None）时清除全部会话与失败冷却。
        """
        if key is None:
            self._blocks.clear()
            self._failed_at = None
            return
        self._blocks.pop(key, None)

    def fail(self, now=None) -> None:
        """记录一次管理器失败，开始负缓存冷却。

        Args:
            now: 失败时间戳；省略时取 ``time.time()``。
        """
        self._failed_at = time.time() if now is None else float(now)

    def cooling(self, now=None) -> bool:
        """判断是否仍在失败冷却期内。

        Args:
            now: 当前时间戳；省略时取 ``time.time()``。

        Returns:
            冷却期内返回 True，否则 False。
        """
        if self._failed_at is None:
            return False
        now = time.time() if now is None else float(now)
        return now - self._failed_at < self.fail_ttl


def _content_text(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(
            str(x.get("text") or "") for x in content
            if isinstance(x, dict) and x.get("type") == "text"
        )
    return ""


def recent_from_contexts(contexts, limit: int = 6) -> list[dict]:
    out = []
    for item in (contexts or [])[-max(1, int(limit or 6)):]:
        if not isinstance(item, dict):
            continue
        text = _content_text(item.get("content")).strip()
        if not text:
            continue
        role = str(item.get("role") or "user")
        out.append({"speaker": "机器人" if role == "assistant" else "用户",
                    "text": text[:200]})
    return out


def build_payload(bundle: dict) -> dict:
    return {
        "instance_id": str(bundle.get("instance_id") or ""),
        "platform_id": str(bundle.get("platform_id") or ""),
        "platform": str(bundle.get("platform") or "qq"),
        "thread_key": str(bundle.get("thread_key") or ""),
        "person_key": str(bundle.get("person_key") or ""),
        "sender_name": str(bundle.get("sender_name") or ""),
        "text": str(bundle.get("text") or ""),
        "is_owner": bool(bundle.get("is_owner")),
        "provider_id": str(bundle.get("provider_id") or ""),
        "recent": list(bundle.get("recent") or [])[:6],
    }


def parse_observe(body) -> dict | None:
    if not isinstance(body, dict):
        return None
    data = body.get("data")
    if not isinstance(data, dict):
        return None
    if data.get("enabled") is False:
        return {"enabled": False}
    block = data.get("prompt_block")
    if not isinstance(block, str) or not block.strip():
        return None
    return data
