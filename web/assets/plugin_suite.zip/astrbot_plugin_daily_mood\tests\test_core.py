import unittest
from pathlib import Path

from core import PromptCache, build_payload, parse_observe, platform_of, recent_from_contexts


class PlatformOfTest(unittest.TestCase):
    def test_qq_platforms_map_to_qq(self):
        self.assertEqual(platform_of(""), "qq")
        self.assertEqual(platform_of("aiocqhttp"), "qq")
        self.assertEqual(platform_of("qq"), "qq")
        self.assertEqual(platform_of("qq_official"), "qq")

    def test_bilibili_platform(self):
        self.assertEqual(platform_of("bilibili"), "bilibili")

    def test_douyin_platform(self):
        self.assertEqual(platform_of("douyin"), "douyin")

    def test_unknown_platform_is_unsupported(self):
        self.assertEqual(platform_of("telegram"), "")


class PromptCacheTest(unittest.TestCase):
    def test_set_then_get_returns_block(self):
        cache = PromptCache()
        self.assertEqual(cache.get("u1", now=1000), "")
        cache.set("u1", "块A", now=1000)
        self.assertEqual(cache.get("u1", now=1001), "块A")

    def test_get_expires_after_ttl(self):
        cache = PromptCache(ttl=1800)
        cache.set("u1", "块A", now=1000)
        self.assertEqual(cache.get("u1", now=2799), "块A")
        self.assertEqual(cache.get("u1", now=2800), "")

    def test_keys_are_isolated(self):
        cache = PromptCache()
        cache.set("u1", "块A", now=1000)
        cache.set("g1", "块B", now=1000)
        self.assertEqual(cache.get("u1", now=1001), "块A")
        self.assertEqual(cache.get("g1", now=1001), "块B")
        self.assertEqual(cache.get("u2", now=1001), "")

    def test_clear_single_key_keeps_others(self):
        cache = PromptCache()
        cache.set("u1", "块A", now=1000)
        cache.set("u2", "块B", now=1000)
        cache.clear("u1")
        self.assertEqual(cache.get("u1", now=1001), "")
        self.assertEqual(cache.get("u2", now=1001), "块B")

    def test_clear_all(self):
        cache = PromptCache()
        cache.set("u1", "块A", now=1000)
        cache.set("u2", "块B", now=1000)
        cache.clear()
        self.assertEqual(cache.get("u1", now=1001), "")
        self.assertEqual(cache.get("u2", now=1001), "")

    def test_empty_block_drops_cached_value(self):
        cache = PromptCache()
        cache.set("u1", "块A", now=1000)
        cache.set("u1", "", now=1001)
        self.assertEqual(cache.get("u1", now=1002), "")

    def test_fail_cools_down_then_recovers(self):
        cache = PromptCache(fail_ttl=30)
        self.assertFalse(cache.cooling(now=1000))
        cache.set("u1", "块A", now=1000)
        cache.fail(now=1000)
        self.assertTrue(cache.cooling(now=1029))
        self.assertEqual(cache.get("u1", now=1029), "块A")
        self.assertFalse(cache.cooling(now=1030))

    def test_clear_all_resets_cooldown(self):
        cache = PromptCache(fail_ttl=30)
        cache.fail(now=1000)
        self.assertTrue(cache.cooling(now=1001))
        cache.clear()
        self.assertFalse(cache.cooling(now=1001))


class RecentTest(unittest.TestCase):
    def test_recent_from_contexts_keeps_last_six_and_maps_roles(self):
        contexts = [{"role": "user", "content": f"u{i}"} for i in range(8)]
        recent = recent_from_contexts(contexts)
        self.assertEqual(len(recent), 6)
        self.assertEqual(recent[0], {"speaker": "用户", "text": "u2"})
        self.assertEqual(recent_from_contexts([{"role": "assistant", "content": "a"}])[0]["speaker"], "机器人")

    def test_recent_skips_blank_and_non_text(self):
        contexts = [
            {"role": "user", "content": "old"},
            {"role": "user", "content": "   "},
            {"role": "user", "content": None},
            {"role": "user", "content": [{"type": "image"}]},
            "not-a-dict",
            {"role": "user", "content": [
                {"type": "text", "text": "hi"},
                {"type": "text", "text": " there"},
            ]},
            {"role": "assistant", "content": "ok"},
        ]
        recent = recent_from_contexts(contexts)
        self.assertEqual([x["text"] for x in recent], ["hi there", "ok"])
        self.assertEqual([x["speaker"] for x in recent], ["用户", "机器人"])

    def test_recent_skips_non_text_and_truncates(self):
        recent = recent_from_contexts([
            {"role": "user", "content": [{"type": "text", "text": "hi"}]},
            {"role": "user", "content": "x" * 500},
        ])
        self.assertEqual(recent[0]["text"], "hi")
        self.assertEqual(len(recent[1]["text"]), 200)


class PayloadTest(unittest.TestCase):
    def test_build_payload_defaults(self):
        self.assertEqual(build_payload({}), {
            "instance_id": "",
            "platform_id": "",
            "platform": "qq",
            "thread_key": "",
            "person_key": "",
            "sender_name": "",
            "text": "",
            "is_owner": False,
            "provider_id": "",
            "recent": [],
        })

    def test_build_payload_fields(self):
        bundle = {
            "instance_id": "", "platform_id": "大肥鱼", "platform": "qq",
            "thread_key": "大肥鱼:FriendMessage:1", "person_key": "1",
            "sender_name": "小明", "text": "在吗", "is_owner": False,
            "provider_id": "p1", "recent": [],
        }
        payload = build_payload(bundle)
        self.assertEqual(payload["platform_id"], "大肥鱼")
        self.assertEqual(payload["thread_key"], "大肥鱼:FriendMessage:1")
        self.assertEqual(payload["person_key"], "1")
        self.assertFalse(payload["is_owner"])

    def test_build_payload_caps_recent(self):
        payload = build_payload({"recent": [{"text": str(i)} for i in range(8)]})
        self.assertEqual(len(payload["recent"]), 6)


class ParseObserveTest(unittest.TestCase):
    def test_parse_observe_requires_prompt_block_or_disabled(self):
        self.assertEqual(parse_observe({"status": "ok", "data": {"prompt_block": "块"}}), {"prompt_block": "块"})
        self.assertEqual(parse_observe({"status": "ok", "data": {"enabled": False}}), {"enabled": False})
        self.assertIsNone(parse_observe({"status": "error"}))
        self.assertIsNone(parse_observe(None))


class HookPriorityTest(unittest.TestCase):
    def test_mood_hook_runs_before_human_mode(self):
        source = (Path(__file__).resolve().parents[1] / "main.py").read_text(encoding="utf-8")
        self.assertIn("priority=sys.maxsize", source)
        self.assertNotIn("priority=100000", source)


if __name__ == "__main__":
    unittest.main()
