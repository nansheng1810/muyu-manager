"""大肥鱼插件本地数据：回复复盘轨迹、记忆纠错队列、主人授权。

文件都放在 AstrBot/data/plugin_data/astrbot_plugin_dafeiyu_clean/ 下，
管理器直接读取同一份文件，因此两边不需要额外接口。
"""

from __future__ import annotations

import json
import re
import time
from pathlib import Path

MEM_HEADER = "<RAG-Faiss-Memory>"
MEM_FOOTER = "</RAG-Faiss-Memory>"
_MEM_BLOCK_RE = re.compile(
    re.escape(MEM_HEADER) + r"(.*?)" + re.escape(MEM_FOOTER),
    re.S,
)
_MEM_ITEM_SPLIT = re.compile(r"\n\n(?=记忆 #\d+)")
_QUOTE_RE = re.compile(r"\[引用消息(?: \| (?P<nick>[^\]]+))?\]\s*(?P<text>[\s\S]{0,300})")


def data_dir() -> Path:
    path = Path(__file__).resolve().parents[2] / "plugin_data" / "astrbot_plugin_dafeiyu_clean"
    path.mkdir(parents=True, exist_ok=True)
    return path


class Store:
    def __init__(self, base: Path | None = None) -> None:
        self.base = Path(base) if base else data_dir()
        self.base.mkdir(parents=True, exist_ok=True)

    def _path(self, name: str) -> Path:
        return self.base / name

    def read(self, name: str, default):
        try:
            raw = self._path(name).read_text(encoding="utf-8")
            return json.loads(raw)
        except Exception:  # noqa: BLE001
            return default

    def write(self, name: str, data) -> None:
        path = self._path(name)
        tmp = path.with_name(path.name + ".tmp")
        tmp.write_text(
            json.dumps(data, ensure_ascii=False, indent=1),
            encoding="utf-8",
        )
        tmp.replace(path)

    # ---------------------------------------------------------------- traces
    def list_traces(self) -> list[dict]:
        data = self.read("traces.json", {"version": 1, "items": []})
        if isinstance(data, dict):
            items = data.get("items")
        else:
            items = data
        return items if isinstance(items, list) else []

    def upsert_trace(self, trace: dict, limit: int = 200) -> None:
        items = self.list_traces()
        items = [item for item in items if item.get("id") != trace.get("id")]
        items.insert(0, trace)
        self.write("traces.json", {"version": 1, "items": items[:limit]})

    # ------------------------------------------------------------ corrections
    def list_corrections(self) -> list[dict]:
        data = self.read("corrections.json", {"version": 1, "items": []})
        items = data.get("items") if isinstance(data, dict) else data
        return items if isinstance(items, list) else []

    def add_correction(self, item: dict, limit: int = 100) -> None:
        items = self.list_corrections()
        items.insert(0, item)
        self.write("corrections.json", {"version": 1, "items": items[:limit]})

    # ---------------------------------------------------------------- grants
    def list_grants(self) -> list[dict]:
        data = self.read("owner_grants.json", {"version": 1, "grants": []})
        grants = data.get("grants") if isinstance(data, dict) else data
        now = time.time()
        return [
            grant
            for grant in (grants if isinstance(grants, list) else [])
            if isinstance(grant, dict) and float(grant.get("expires_at") or 0) >= now
        ]


def part_text(part) -> str:
    if isinstance(part, dict):
        return str(part.get("text") or "")
    return str(getattr(part, "text", "") or "")


def collect_text(parts) -> str:
    return "\n\n".join(text for text in (part_text(p) for p in (parts or [])) if text)


def memory_snapshot(text: str) -> dict:
    """从最终 prompt 里抽出 livingmemory 注入的记忆块。"""
    blocks = _MEM_BLOCK_RE.findall(text or "")
    items: list[dict] = []
    for block in blocks:
        for entry in _MEM_ITEM_SPLIT.split(block.strip()):
            entry = entry.strip()
            if not entry:
                continue
            lines = entry.splitlines()
            head = lines[0].strip() if lines else ""
            body = "\n".join(lines[1:]).strip()
            items.append({"head": head[:160], "text": body[:600]})
    return {"blocks": blocks, "items": items}


def extract_quote(event) -> dict | None:
    """从事件里取被引用的消息原文。"""
    try:
        from astrbot.api.message_components import Reply

        reply = next((c for c in event.get_messages() if isinstance(c, Reply)), None)
    except Exception:  # noqa: BLE001
        reply = None
    if reply is not None:
        text = (getattr(reply, "message_str", "") or "").strip()
        if text:
            return {
                "nickname": getattr(reply, "sender_nickname", "") or "",
                "text": text[:400],
            }
    prompt = ""
    try:
        prompt = str(event.message_str or "")
    except Exception:  # noqa: BLE001
        pass
    match = _QUOTE_RE.search(prompt)
    if match:
        return {
            "nickname": match.group("nick") or "",
            "text": (match.group("text") or "").strip(),
        }
    return None


def trace_key(event) -> str:
    message_id = ""
    try:
        message_id = str(getattr(event.message_obj, "message_id", "") or "")
    except Exception:  # noqa: BLE001
        pass
    if message_id:
        return f"{event.unified_msg_origin}|{message_id}"
    return f"{event.unified_msg_origin}|{int(getattr(event, 'created_at', 0) or time.time() * 1000)}"
