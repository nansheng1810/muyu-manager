"""看图接话：记录群里的图片、缓存视觉描述、注入本轮上下文并按概率主动接话。

插件写 ``vision.json``（图片记录）；管理器的设置写在 ``vision_admin.json``，
删除记录写在 ``vision_deleted.json``。插件与管理器各写各的文件，避免覆盖。
"""

from __future__ import annotations

import json
import os
import random
import re
import time
import uuid
from pathlib import Path

DEFAULT_SETTINGS = {
    "enabled": True,
    "inject": True,
    "auto_reply": False,
    "probability": 0.15,
    "hourly_limit": 3,
    "groups": [],
    "max_chars": 90,
}

IMAGE_RE = re.compile(r"^https?://", re.IGNORECASE)
DESCRIBE_PROMPT = (
    "你在帮一个聊天机器人看图。请用一句中文客观描述这张图：主体是什么、"
    "在做什么、有没有文字或梗。不要评价，不要以“图片中”开头，40 字以内。"
)
REPLY_PROMPT = (
    "群里有人发了一张图，图片内容是：{desc}。"
    "请像群友一样用一句自然的话接这个图，25 字以内；"
    "不要描述图片，不要说“图片中”，可以带一个表情。"
)


def _read(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _write(path: Path, data) -> None:
    tmp = path.with_name(path.name + ".tmp")
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, path)
    except OSError:
        tmp.unlink(missing_ok=True)
        raise


def normalize_settings(raw) -> dict:
    data = dict(DEFAULT_SETTINGS)
    if isinstance(raw, dict):
        data.update({key: raw[key] for key in DEFAULT_SETTINGS if key in raw})
    data["enabled"] = bool(data.get("enabled", True))
    data["inject"] = bool(data.get("inject", True))
    data["auto_reply"] = bool(data.get("auto_reply", False))
    try:
        data["probability"] = max(0.0, min(1.0, float(data.get("probability", 0.15))))
    except (TypeError, ValueError):
        data["probability"] = 0.15
    try:
        data["hourly_limit"] = max(0, min(100, int(data.get("hourly_limit", 3))))
    except (TypeError, ValueError):
        data["hourly_limit"] = 3
    try:
        data["max_chars"] = max(20, min(400, int(data.get("max_chars", 90))))
    except (TypeError, ValueError):
        data["max_chars"] = 90
    groups = data.get("groups")
    if not isinstance(groups, list):
        groups = []
    data["groups"] = [str(item).strip() for item in groups if str(item).strip()][:50]
    return data


class VisionGate:
    """图片记录、描述缓存与主动接话配额。"""

    def __init__(self, data_dir: Path, cfg=None) -> None:
        self.data_dir = Path(data_dir)
        self.cfg = cfg or {}
        self.path = self.data_dir / "vision.json"
        self.admin_path = self.data_dir / "vision_admin.json"
        self.deleted_path = self.data_dir / "vision_deleted.json"
        self._items: list[dict] = []
        self._deleted: set[str] = set()
        self._auto_times: dict[str, list[float]] = {}
        self._last_seen: dict[str, dict] = {}
        self._admin_mtime = 0.0
        self._settings = normalize_settings(self._cfg_settings())
        self._sync_admin(force=True)
        self._load()

    def _cfg_settings(self) -> dict:
        return {
            "enabled": self.cfg.get("enable_vision_reply", True),
            "inject": self.cfg.get("vision_inject", True),
            "auto_reply": self.cfg.get("vision_auto_reply", False),
            "probability": self.cfg.get("vision_probability", 0.15),
            "hourly_limit": self.cfg.get("vision_hourly_limit", 3),
            "groups": self.cfg.get("vision_groups", []),
            "max_chars": self.cfg.get("vision_max_chars", 90),
        }

    def _sync_admin(self, force: bool = False) -> None:
        try:
            mtime = self.admin_path.stat().st_mtime
        except OSError:
            return
        if not force and mtime <= self._admin_mtime:
            return
        self._admin_mtime = mtime
        data = _read(self.admin_path, {})
        if isinstance(data, dict):
            self._settings = normalize_settings(data.get("settings"))

    def _load(self) -> None:
        deleted = _read(self.deleted_path, {})
        if isinstance(deleted, dict):
            ids = deleted.get("ids")
            if isinstance(ids, list):
                self._deleted = {str(item) for item in ids}
        data = _read(self.path, {})
        items = data.get("items") if isinstance(data, dict) else None
        if isinstance(items, list):
            self._items = [
                item for item in items
                if isinstance(item, dict) and str(item.get("id") or "") not in self._deleted
            ]

    def settings(self) -> dict:
        self._sync_admin()
        return dict(self._settings)

    def _save(self) -> None:
        self._items = [item for item in self._items if item.get("id") not in self._deleted]
        self._items = self._items[-200:]
        payload = {"version": 1, "updated": time.time(), "items": self._items}
        try:
            _write(self.path, payload)
        except OSError:
            pass

    def disabled(self) -> bool:
        return not self.settings().get("enabled", True)

    def record(self, *, umo: str, group_id: str, sender_id: str,
               sender_name: str, url: str, caption: str = "",
               description: str = "", now: float | None = None) -> dict:
        """写入一条图片记录；同一 URL 10 分钟内不重复记。"""
        now = time.time() if now is None else float(now)
        for item in reversed(self._items):
            if item.get("url") == url and now - float(item.get("ts") or 0) < 600:
                item["ts"] = now
                item["caption"] = caption or item.get("caption") or ""
                if description:
                    item["description"] = description
                self._last_seen[umo] = item
                return item
        item = {
            "id": f"v_{uuid.uuid4().hex[:8]}",
            "umo": umo,
            "group_id": group_id,
            "sender_id": sender_id,
            "sender_name": sender_name,
            "url": url,
            "caption": caption[:120],
            "description": description[:200],
            "ts": now,
            "auto_reply": False,
            "reply_text": "",
        }
        self._items.append(item)
        self._last_seen[umo] = item
        self._save()
        return item

    def attach_description(self, item: dict, description: str) -> None:
        if not item:
            return
        item["description"] = str(description or "")[:200]
        self._save()

    def mark_auto_reply(self, item: dict, text: str, umo: str,
                        now: float | None = None) -> None:
        if not item:
            return
        now = time.time() if now is None else float(now)
        item["auto_reply"] = True
        item["reply_text"] = str(text or "")[:200]
        self._last_seen[umo] = item
        self._auto_times.setdefault(umo, []).append(now)
        self._save()

    def recent(self, umo: str, within: float = 600,
               now: float | None = None) -> dict | None:
        now = time.time() if now is None else float(now)
        item = self._last_seen.get(umo)
        if item and now - float(item.get("ts") or 0) <= within:
            return item
        for item in reversed(self._items):
            if item.get("umo") == umo and now - float(item.get("ts") or 0) <= within:
                return item
        return None

    def block(self, umo: str, now: float | None = None) -> str:
        if self.disabled() or not self.settings().get("inject", True):
            return ""
        item = self.recent(umo, within=600, now=now)
        if not item:
            return ""
        description = str(item.get("description") or "").strip()
        if not description:
            return ""
        name = str(item.get("sender_name") or item.get("sender_id") or "群友")
        limit = int(self.settings().get("max_chars", 90))
        text = description[:limit].rstrip("。．.!！?？ ")
        return (
            f"【刚看到的图】{name}发了一张图：{text}。"
            "如果这条消息和图片有关，可以自然接一句；不要逐字描述图片。"
        )

    def can_auto_reply(self, umo: str, group_id: str,
                       now: float | None = None) -> bool:
        settings = self.settings()
        if not settings.get("auto_reply", False):
            return False
        groups = settings.get("groups") or []
        if groups and str(group_id) not in groups:
            return False
        now = time.time() if now is None else float(now)
        times = [ts for ts in self._auto_times.get(umo, []) if now - ts < 3600]
        self._auto_times[umo] = times
        if len(times) >= int(settings.get("hourly_limit", 3)):
            return False
        return random.random() < float(settings.get("probability", 0.15))

    def offer(self, event) -> list[tuple[str, str]]:
        """从消息链中取出 http 图片 URL 与附言。"""
        items: list[tuple[str, str]] = []
        try:
            chain = event.get_messages()
        except Exception:  # noqa: BLE001
            return items
        from astrbot.core.message.components import Image

        caption = ""
        try:
            caption = str(event.get_message_str() or "").strip()
        except Exception:  # noqa: BLE001
            caption = ""
        for seg in chain:
            if not isinstance(seg, Image):
                continue
            url = str(getattr(seg, "url", "") or "").strip()
            if not url or not IMAGE_RE.match(url):
                continue
            items.append((url, caption))
            if len(items) >= 3:
                break
        return items
