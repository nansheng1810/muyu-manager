"""活人感插件：关系活动上报、未完成话题扫描、私聊回访、群聊雷达与日记触发。

插件只做“感知、上报、注入、发送”，不写管理器数据库，也不写人格/记忆。
所有管理器请求超时 3 秒；任何失败只记日志，不阻塞正常聊天。
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import sys
import time
from pathlib import Path

from astrbot import logger
from astrbot.api.event import AstrMessageEvent, MessageChain, filter
from astrbot.api.star import Context, Star, StarTools
from astrbot.api.web import request

from .core import (
    build_activity_payload,
    build_scan_payload,
    followup_payload,
    is_private_umo,
    parse_context,
    platform_of,
    quiet_now,
    radar_key,
    should_diary,
    should_scan,
)
from .life import LifeLine
from .manager_client import ManagerClient, ManagerError
from .memes import MemeLibrary
from .vision import DESCRIBE_PROMPT, REPLY_PROMPT, VisionGate

NAME = "astrbot_plugin_human_presence"
DEFAULT_MANAGER_URL = "http://127.0.0.1:7311"

ACTIVITY_PATH = "/api/presence/activity"
SCAN_PATH = "/api/presence/scan"
CONTEXT_PATH = "/api/presence/context"
DUE_PATH = "/api/presence/followups/due"
SENT_PATH = "/api/presence/followups/{loop_id}/sent"
RADAR_PATH = "/api/presence/radar"
DIARY_PATH = "/api/presence/diaries/generate"
SETTINGS_PATH = "/api/presence/settings"
INSTANCES_PATH = "/api/instances"

LOOPBACK_HOSTS = {"127.0.0.1", "::1", "localhost", "::ffff:127.0.0.1"}
RADAR_WINDOW = 5.0
RADAR_FLUSH_SECONDS = 5.0
CONTEXT_TTL = 120.0
CONTEXT_FAIL_TTL = 60.0
# 管理器扫描/回访要调用实例模型（单次最长 15 秒），不能用默认 3 秒短超时。
SCAN_TIMEOUT = 28.0
FOLLOWUP_TIMEOUT = 30.0
SETTINGS_TTL = 300.0
INSTANCE_TTL = 300.0
SCAN_RETRY_SECONDS = 300.0
BUFFER_LIMIT = 20
PENDING_RADAR_LIMIT = 200
SENT_MEMORY_SECONDS = 24 * 3600
SEND_TIMEOUT = 20.0
MAX_TEXT_CHARS = 200


def _seconds(value, default: float, minimum: float = 5.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        number = default
    return max(minimum, number)


class HumanPresence(Star):
    def __init__(self, context: Context, config=None):
        super().__init__(context)
        self.config = config or {}
        self.client = ManagerClient(
            self._cfg("manager_url", DEFAULT_MANAGER_URL), timeout=3)
        self.data_dir = Path(StarTools.get_data_dir(NAME))
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.state_path = self.data_dir / "state.json"
        self._activities: dict[tuple, dict] = {}
        self._buffers: dict[str, dict] = {}
        self._radar_pending: dict[str, dict] = {}
        self._radar_queue: list[dict] = []
        self._context_cache: dict[tuple, tuple[str, float]] = {}
        self._context_fail: dict[tuple, float] = {}
        self._sent_loops: dict[str, float] = {}
        self._settings: dict = {}
        self._settings_at = 0.0
        self._instance_id = ""
        self._instance_at = 0.0
        self._platform_id = ""
        self._private_umos: set[str] = set()
        self._last_diary_date = ""
        self._last_activity_flush = 0.0
        self._last_radar_flush = 0.0
        self._last_scan_at = 0.0
        self._last_followup_at = 0.0
        self.task = None
        self.failing = False
        self.life = LifeLine(self.data_dir, self.config)
        self.memes = MemeLibrary(self.data_dir, self.config)
        self.vision = VisionGate(self.data_dir, self.config)
        self._vision_tasks: set[asyncio.Task] = set()
        self._described_urls: dict[str, float] = {}
        self._last_life_tick = 0.0
        self._load_state()

    def _cfg(self, key, default):
        return self.config.get(key, default)

    # ------------------------------------------------------------ 状态持久化

    def _load_state(self) -> None:
        """读取已知私聊、平台前缀与上次日记日期；损坏时静默重建。"""
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        if not isinstance(data, dict):
            return
        raw_umos = data.get("private_umos")
        if isinstance(raw_umos, list):
            self._private_umos = {
                str(item) for item in raw_umos
                if is_private_umo(item)
            }
        self._platform_id = str(data.get("platform_id") or "")
        self._instance_id = str(
            self._cfg("instance_id", "") or data.get("instance_id") or "")
        self._last_diary_date = str(data.get("last_diary_date") or "")

    def _save_state(self) -> None:
        """原子写回插件状态，失败只记日志。"""
        payload = {
            "private_umos": sorted(self._private_umos),
            "platform_id": self._platform_id,
            "instance_id": self._instance_id,
            "last_diary_date": self._last_diary_date,
        }
        tmp = self.state_path.with_name(self.state_path.name + ".tmp")
        try:
            tmp.write_text(
                json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, self.state_path)
        except OSError as exc:
            tmp.unlink(missing_ok=True)
            logger.warning("[活人感] 状态写盘失败：%s", exc)

    # ------------------------------------------------------------------ 生命周期

    async def initialize(self):
        routes = [
            ("send", self.api_send, ["POST"]),
            ("status", self.api_status, ["GET"]),
        ]
        for suffix, handler, methods in routes:
            self.context.register_web_api(
                f"/{NAME}/{suffix}", handler, methods, "牧鱼活人感")
        self.task = asyncio.create_task(self._loop())
        logger.info(
            "[活人感] 插件已加载；已知私聊 %s 个，平台前缀=%s；生活线=%s 群梗=%s 看图=%s",
            len(self._private_umos), self._platform_id or "未学习",
            "开" if self._cfg("enable_life_line", True) else "关",
            "开" if self._cfg("enable_group_memes", True) else "关",
            "开" if self._cfg("enable_vision_reply", True) else "关")

    async def terminate(self):
        if self.task is not None:
            self.task.cancel()
            await asyncio.gather(self.task, return_exceptions=True)
            self.task = None
        for task in list(self._vision_tasks):
            task.cancel()
        if self._vision_tasks:
            await asyncio.gather(*self._vision_tasks, return_exceptions=True)
            self._vision_tasks.clear()
        try:
            self.life.tick()
        except Exception as exc:  # noqa: BLE001
            logger.debug("[活人感] 卸载时保存生活线失败：%s", exc)
        try:
            self.memes.flush()
        except Exception as exc:  # noqa: BLE001
            logger.debug("[活人感] 卸载时保存群梗失败：%s", exc)
        try:
            await self._flush_activities()
            await self._flush_radar(force=True)
        except Exception as exc:  # noqa: BLE001 - 卸载时的兜底
            logger.warning("[活人感] 卸载前补发失败：%s", exc)
        self._save_state()
        logger.info("[活人感] 插件已卸载")

    # ------------------------------------------------------------------ 消息观察

    # 排在收件箱接管（maxsize）之后、群聊读空气/其它事件处理之前：
    # 接管会话不会被观察；未被接管的消息都能进入雷达影子统计。
    @filter.event_message_type(filter.EventMessageType.ALL,
                               priority=sys.maxsize - 1)
    async def observe(self, event: AstrMessageEvent):
        """只观察 QQ 消息：私聊缓冲、群聊雷达和批量活动，绝不 stop。"""
        try:
            if not self._cfg("enabled", True):
                return
            platform_name = str(event.get_platform_name() or "")
            if platform_of(platform_name) != "qq":
                return
            sender_id = str(event.get_sender_id() or "")
            try:
                self_id = str(event.get_self_id() or "")
            except Exception:
                self_id = ""
            if sender_id and self_id and sender_id == self_id:
                return
            umo = str(event.unified_msg_origin or "")
            if not umo:
                return
            platform_id = umo.split(":", 1)[0] if ":" in umo else ""
            self._learn_platform(platform_id)
            try:
                private = bool(event.is_private_chat())
            except Exception:
                private = False
            try:
                sender_name = str(event.get_sender_name() or "")
            except Exception:
                sender_name = ""
            try:
                text = str(event.get_message_str() or "").strip()
            except Exception:
                text = str(getattr(event, "message_str", "") or "").strip()
            now = time.time()
            self._safe_life_tick(now)
            self._record_activity(
                sender_id, sender_name, private, now)
            if private:
                self._remember_private(umo)
                self._buffer_private(
                    umo, platform_id, sender_id, sender_name, text, now)
            else:
                self._record_radar(event, umo, sender_id, text, now)
                group_id = self._group_of(event, umo)
                self.memes.observe(group_id, sender_id, text, now)
                self._spawn_vision(
                    event, umo, group_id, sender_id, sender_name, now)
        except Exception as exc:  # noqa: BLE001 - 观察失败不能影响聊天
            logger.debug("[活人感] 消息观察失败：%s", exc)

    def _learn_platform(self, platform_id: str) -> None:
        """记住 UMO 前缀；变化时重新解析实例并写盘。"""
        platform_id = str(platform_id or "").strip()
        if not platform_id or platform_id == self._platform_id:
            return
        self._platform_id = platform_id
        self._instance_id = str(self._cfg("instance_id", "") or "")
        self._instance_at = 0.0
        self._save_state()

    def _remember_private(self, umo: str) -> None:
        """登记已见过的私聊 UMO，供发送路由与重启后校验。"""
        if umo in self._private_umos:
            return
        self._private_umos.add(umo)
        if len(self._private_umos) > 500:
            self._private_umos = set(sorted(self._private_umos)[-500:])
        self._save_state()

    def _record_activity(self, person_key: str, sender_name: str,
                         private: bool, now: float) -> None:
        """按“平台+人+场景”累计消息，等 flush 时批量上报。"""
        if not person_key:
            return
        key = ("qq", person_key, private)
        entry = self._activities.get(key)
        if entry is None:
            entry = {
                "platform": "qq",
                "person_key": person_key,
                "display_name": sender_name,
                "message_count": 0,
                "is_private": private,
                "occurred_at": now,
            }
            self._activities[key] = entry
        entry["message_count"] += 1
        entry["occurred_at"] = now
        if sender_name:
            entry["display_name"] = sender_name

    def _buffer_private(self, umo: str, platform_id: str, person_key: str,
                        sender_name: str, text: str, now: float) -> None:
        """缓存私聊文本，供未完成话题扫描；指令消息不计入。"""
        if not person_key or text.startswith(("/", "／")):
            return
        buffer = self._buffers.get(umo)
        if buffer is None:
            buffer = {
                "umo": umo,
                "platform_id": platform_id,
                "person_key": person_key,
                "messages": [],
                "texts": [],
                "message_count": 0,
                "last_scan_at": 0.0,
                "retry_after": 0.0,
            }
            self._buffers[umo] = buffer
        buffer["person_key"] = person_key
        buffer["platform_id"] = platform_id or buffer["platform_id"]
        if not text:
            return
        buffer["messages"].append({
            "speaker": sender_name or "用户",
            "text": text[:300],
            "ts": now,
        })
        buffer["messages"] = buffer["messages"][-BUFFER_LIMIT:]
        buffer["texts"].append(text[:300])
        buffer["texts"] = buffer["texts"][-BUFFER_LIMIT:]
        buffer["message_count"] += 1

    def _record_radar(self, event, umo: str, sender_id: str, text: str,
                      now: float) -> None:
        """记录群消息进入时间；是否接话由 5 秒内是否有 LLM 请求决定。"""
        if not text or text.startswith(("/", "／")):
            return
        try:
            group_id = str(event.get_group_id() or "")
        except Exception:
            group_id = ""
        if not group_id:
            parts = umo.split(":")
            group_id = parts[2] if len(parts) >= 3 else ""
        message_id = getattr(
            getattr(event, "message_obj", None), "message_id", "") or ""
        key = radar_key(umo, message_id)
        self._radar_pending[key] = {
            "key": key,
            "umo": umo,
            "group_id": group_id,
            "person_key": sender_id,
            "text": text[:200],
            "ts": now,
        }
        if len(self._radar_pending) > PENDING_RADAR_LIMIT:
            oldest = sorted(
                self._radar_pending, key=lambda k: self._radar_pending[k]["ts"])
            for stale in oldest[:len(self._radar_pending) - PENDING_RADAR_LIMIT]:
                self._radar_pending.pop(stale, None)

    # ---------------------------------------------- 生活线 / 群梗 / 看图接话

    def _group_of(self, event, umo: str) -> str:
        try:
            group_id = str(event.get_group_id() or "")
        except Exception:  # noqa: BLE001
            group_id = ""
        if not group_id:
            parts = umo.split(":")
            group_id = parts[2] if len(parts) >= 3 else ""
        return group_id

    def _safe_life_tick(self, now: float, force: bool = False) -> None:
        """生活线每轮消息与后台各 tick 一次；失败只记日志。"""
        if not force and now - self._last_life_tick < 30:
            return
        self._last_life_tick = now
        try:
            self.life.tick(now)
        except Exception as exc:  # noqa: BLE001
            logger.debug("[活人感] 生活线 tick 失败：%s", exc)

    def _spawn_vision(self, event, umo: str, group_id: str, sender_id: str,
                      sender_name: str, now: float) -> None:
        """有图片时异步描述；不阻塞消息观察。"""
        if self.vision.disabled():
            return
        images = self.vision.offer(event)
        if not images:
            return
        if getattr(event, "is_at_or_wake_command", False):
            # 本条消息本来就会触发回复，交给主流程，避免重复接话。
            return
        for url, caption in images:
            seen = self._described_urls.get(url, 0.0)
            if now - seen < 3600:
                continue
            self._described_urls[url] = now
            task = asyncio.create_task(self._handle_image(
                umo, group_id, sender_id, sender_name, url, caption, now))
            self._vision_tasks.add(task)
            task.add_done_callback(self._vision_tasks.discard)
            if len(self._described_urls) > 200:
                cutoff = now - 3600
                self._described_urls = {
                    key: ts for key, ts in self._described_urls.items()
                    if ts >= cutoff
                }

    async def _handle_image(self, umo: str, group_id: str, sender_id: str,
                            sender_name: str, url: str, caption: str,
                            now: float) -> None:
        """调用视觉模型描述图片，落盘，并按配额决定是否主动接话。"""
        try:
            provider = await self._vision_provider(umo)
            if provider is None:
                return
            resp = await provider.text_chat(
                prompt=DESCRIBE_PROMPT, image_urls=[url])
            description = str(getattr(resp, "completion_text", "") or "").strip()
            if not description:
                return
            description = description[:200]
            item = self.vision.record(
                umo=umo, group_id=group_id, sender_id=sender_id,
                sender_name=sender_name, url=url, caption=caption,
                description=description, now=now)
            if not self.vision.can_auto_reply(umo, group_id, now):
                return
            reply = await provider.text_chat(
                prompt=REPLY_PROMPT.format(desc=description))
            text = " ".join(
                str(getattr(reply, "completion_text", "") or "").split())
            if not text:
                return
            sent = await asyncio.wait_for(
                self.context.send_message(
                    umo, MessageChain().message(text[:180])),
                timeout=SEND_TIMEOUT)
            if sent:
                self.vision.mark_auto_reply(item, text, umo, now)
                logger.info("[活人感] 已看图接话（%s）：%s", group_id, text[:60])
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 - 看图失败不影响聊天
            logger.debug("[活人感] 看图接话失败：%s", exc)

    async def _vision_provider(self, umo: str):
        settings = self.vision.settings()
        provider_id = str(settings.get("provider_id") or "").strip()
        if provider_id:
            provider = self.context.get_provider_by_id(provider_id)
            if provider is not None:
                return provider
        try:
            return await self.context.get_using_provider_async(umo)
        except Exception:  # noqa: BLE001
            return None

    # ------------------------------------------------------------------ 提示注入

    @filter.on_llm_request(priority=sys.maxsize - 2)
    async def inject_context(self, event: AstrMessageEvent, req):
        """回复前注入昵称/阶段/里程碑/昨日摘要（≤250 字）；失败跳过。"""
        try:
            if not self._cfg("enabled", True):
                return
            platform_name = str(event.get_platform_name() or "")
            if platform_of(platform_name) != "qq":
                return
            try:
                private = bool(event.is_private_chat())
            except Exception:
                private = False
            umo = str(event.unified_msg_origin or "")
            now = time.time()
            if not private and umo:
                self._mark_radar_reply(umo, now)
            person_key = str(event.get_sender_id() or "")
            if not person_key:
                return
            base_block = await self._context_block(person_key, umo, now)
            blocks: list[str] = []
            if base_block:
                blocks.append(base_block)
            for name, getter in (
                ("生活线", lambda: self.life.block(now)),
                ("群梗", self.memes.block),
                ("看图", lambda: self.vision.block(umo, now)),
            ):
                try:
                    extra = getter()
                except Exception as exc:  # noqa: BLE001 - 单个块失败不影响其它块
                    logger.debug("[活人感] %s 注入块跳过：%s", name, exc)
                    continue
                if extra:
                    blocks.append(extra)
            if not blocks:
                return
            prompt = getattr(req, "system_prompt", "") or ""
            merged = "\n\n".join(block for block in blocks if block not in prompt)
            if not merged:
                return
            req.system_prompt = prompt + "\n\n" + merged
        except Exception as exc:  # noqa: BLE001 - 注入失败照常聊天
            logger.debug("[活人感] 上下文注入跳过：%s", exc)

    async def _context_block(self, person_key: str, umo: str, now: float) -> str:
        """带会话缓存与失败冷却地拉取管理器上下文。

        ``thread_key`` 必须一并上报：收件箱接管中的会话由管理器返回空上下文，
        插件据此完全跳过注入。
        """
        key = ("qq", person_key, umo)
        failed_at = self._context_fail.get(key, 0.0)
        if now - failed_at < CONTEXT_FAIL_TTL:
            return ""
        cached = self._context_cache.get(key)
        if cached and now - cached[1] < CONTEXT_TTL:
            return cached[0]
        query = {
            "platform": "qq",
            "person_key": person_key,
            "thread_key": umo,
            "platform_id": self._platform_id,
        }
        if self._instance_id:
            query["instance_id"] = self._instance_id
        try:
            body = await self.client.get(CONTEXT_PATH, query=query)
        except ManagerError as exc:
            self._context_fail[key] = now
            self.failing = True
            logger.debug("[活人感] 上下文不可用，本轮跳过：%s", exc)
            return ""
        self.failing = False
        parsed = parse_context(body)
        block = parsed["block"]
        if parsed.get("takeover"):
            # 接管是临时状态：不缓存空块，解除接管后立即恢复注入。
            self._context_cache.pop(key, None)
            return ""
        self._context_cache[key] = (block, now)
        if len(self._context_cache) > 300:
            items = sorted(
                self._context_cache.items(), key=lambda kv: kv[1][1])
            for stale, _ in items[:len(items) - 200]:
                self._context_cache.pop(stale, None)
        return block

    def _mark_radar_reply(self, umo: str, now: float) -> None:
        """群消息 5 秒内触发 LLM 请求时，把最新一条记为“会接话”。"""
        candidates = [
            item for item in self._radar_pending.values()
            if item["umo"] == umo and now - item["ts"] <= RADAR_WINDOW
        ]
        if not candidates:
            return
        item = max(candidates, key=lambda x: x["ts"])
        self._radar_pending.pop(item["key"], None)
        self._queue_radar(
            "radar_reply", item, int((now - item["ts"]) * 1000))

    def _queue_radar(self, kind: str, item: dict, delay_ms: int) -> None:
        self._radar_queue.append({
            "kind": kind,
            "group_id": item.get("group_id") or "",
            "person_key": item.get("person_key") or "",
            "payload": {
                "umo": item.get("umo") or "",
                "text": item.get("text") or "",
                "delay_ms": delay_ms,
            },
        })
        if len(self._radar_queue) > 500:
            del self._radar_queue[:len(self._radar_queue) - 500]

    # ------------------------------------------------------------------ 后台任务

    async def _loop(self):
        """单循环调度：活动/雷达补发、扫描、回访、日记，异常不退出。"""
        next_activity = time.time()
        next_scan = time.time()
        next_followup = time.time()
        next_diary = time.time()
        next_life = time.time()
        while True:
            await asyncio.sleep(1)
            if not self._cfg("enabled", True):
                continue
            now = time.time()
            try:
                if now >= next_life:
                    next_life = now + 60
                    self._safe_life_tick(now, force=True)
                    self.memes.flush(now)
                self._expire_radar(now)
                if now >= next_activity:
                    next_activity = now + _seconds(
                        self._cfg("activity_flush_seconds", 60), 60)
                    await self._flush_activities()
                if now - self._last_radar_flush >= RADAR_FLUSH_SECONDS:
                    await self._flush_radar()
                if now >= next_scan:
                    next_scan = now + _seconds(
                        self._cfg("scan_check_seconds", 30), 30)
                    await self._scan_private(now)
                if now >= next_followup:
                    next_followup = now + _seconds(
                        self._cfg("followup_check_seconds", 60), 60)
                    await self._poll_followups(now)
                if now >= next_diary:
                    next_diary = now + _seconds(
                        self._cfg("diary_check_seconds", 60), 60)
                    await self._check_diary(now)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - 后台循环必须活下去
                logger.warning("[活人感] 后台任务异常：%s", exc)

    def _expire_radar(self, now: float) -> None:
        """5 秒内没有 LLM 请求的群消息记为“保持沉默”。

        超过 60 秒的积压（例如插件刚启用）直接丢弃，避免上报过期影子事件。
        """
        for key, item in list(self._radar_pending.items()):
            age = now - item["ts"]
            if age < RADAR_WINDOW:
                continue
            self._radar_pending.pop(key, None)
            if age > 60:
                continue
            self._queue_radar("radar_silent", item, int(age * 1000))

    async def _flush_activities(self) -> None:
        """批量上报活动；失败保留，下一轮重试。"""
        if not self._activities:
            return
        keys = list(self._activities)[:100]
        payload = build_activity_payload(
            self._instance_id, self._platform_id,
            [self._activities[key] for key in keys])
        if not payload["activities"]:
            return
        try:
            await self.client.post(ACTIVITY_PATH, payload)
        except ManagerError as exc:
            logger.warning("[活人感] 活动上报失败，保留待重试：%s", exc)
            return
        for key in keys:
            self._activities.pop(key, None)
        self._last_activity_flush = time.time()
        logger.debug("[活人感] 已上报 %s 条关系活动", len(payload["activities"]))

    async def _flush_radar(self, force: bool = False) -> None:
        """批量上报群聊雷达事件；失败保留，每 5 秒重试。"""
        now = time.time()
        if not self._radar_queue:
            self._last_radar_flush = now
            return
        if not force and now - self._last_radar_flush < RADAR_FLUSH_SECONDS:
            return
        events = self._radar_queue[:100]
        payload = {
            "instance_id": self._instance_id,
            "platform_id": self._platform_id,
            "events": events,
        }
        try:
            await self.client.post(RADAR_PATH, payload)
        except ManagerError as exc:
            logger.debug("[活人感] 雷达上报失败，保留待重试：%s", exc)
            self._last_radar_flush = now
            return
        del self._radar_queue[:len(events)]
        self._last_radar_flush = now

    async def _scan_private(self, now: float) -> None:
        """按缓冲状态请求管理器提取未完成话题。"""
        for buffer in list(self._buffers.values()):
            state = {
                "private": True,
                "message_count": buffer["message_count"],
                "last_scan_at": buffer["last_scan_at"],
                "retry_after": buffer["retry_after"],
                "texts": buffer["texts"],
            }
            if not should_scan(state, now):
                continue
            payload = build_scan_payload(
                self._instance_id, buffer["platform_id"], "qq",
                buffer["umo"], buffer["person_key"], buffer["messages"])
            if not payload["messages"]:
                continue
            try:
                body = await self.client.post(
                    SCAN_PATH, payload, timeout=SCAN_TIMEOUT)
            except ManagerError as exc:
                buffer["retry_after"] = now + SCAN_RETRY_SECONDS
                logger.warning("[活人感] 话题扫描失败，5 分钟后重试：%s", exc)
                continue
            buffer["last_scan_at"] = now
            buffer["message_count"] = 0
            buffer["texts"] = []
            self._last_scan_at = now
            data = body.get("data") if isinstance(body, dict) else None
            data = data if isinstance(data, dict) else {}
            loops = data.get("loops")
            loops = loops if isinstance(loops, list) else []
            if data.get("error"):
                logger.debug("[活人感] 扫描未产生话题：%s", data["error"])
            elif loops:
                logger.info("[活人感] 扫描到 %s 条未完成话题", len(loops))

    async def _poll_followups(self, now: float) -> None:
        """轮询到期真实回访；只发私聊，成功后回传 sent。"""
        for loop_id in list(self._sent_loops):
            if now - self._sent_loops[loop_id] > SENT_MEMORY_SECONDS:
                self._sent_loops.pop(loop_id, None)
        settings = await self._manager_settings(now)
        if settings and quiet_now(
                settings.get("quiet_start"), settings.get("quiet_end"), now):
            return
        query = {"platform_id": self._platform_id}
        if self._instance_id:
            query["instance_id"] = self._instance_id
        try:
            body = await self.client.get(
                DUE_PATH, query=query, timeout=FOLLOWUP_TIMEOUT)
        except ManagerError as exc:
            logger.debug("[活人感] 到期回访查询失败：%s", exc)
            return
        items = followup_payload(body)
        for item in items:
            loop_id = item["loop_id"]
            if loop_id in self._sent_loops:
                continue
            umo = item["umo"]
            if umo not in self._private_umos:
                logger.warning(
                    "[活人感] 跳过未知私聊 %s 的回访 %s", umo, loop_id)
                continue
            try:
                sent = await asyncio.wait_for(
                    self.context.send_message(
                        umo, MessageChain().message(item["text"])),
                    timeout=SEND_TIMEOUT)
            except Exception as exc:  # noqa: BLE001 - 发送失败不影响聊天
                logger.warning("[活人感] 回访发送失败 %s：%s", loop_id, exc)
                continue
            if not sent:
                logger.warning("[活人感] 回访平台未找到 %s，未标记发送", umo)
                continue
            self._sent_loops[loop_id] = now
            self._last_followup_at = now
            logger.info("[活人感] 已发送回访 %s（私聊）", loop_id)
            payload = {}
            if self._instance_id:
                payload["instance_id"] = self._instance_id
            try:
                await self.client.post(
                    SENT_PATH.format(loop_id=loop_id), payload)
            except ManagerError as exc:
                logger.warning("[活人感] 回访已发送但回传失败：%s", exc)

    async def _check_diary(self, now: float) -> None:
        """到点触发一次当天日记生成；每天最多尝试一次。"""
        instance_id = await self._resolve_instance(now)
        if not instance_id:
            return
        settings = await self._manager_settings(now)
        if not should_diary(
                now, settings.get("diary_time", "23:30"),
                self._last_diary_date,
                settings.get("diary_enabled", True)):
            return
        today = time.strftime("%Y-%m-%d", time.localtime(now))
        self._last_diary_date = today
        self._save_state()
        try:
            body = await self.client.post(
                DIARY_PATH, {"instance_id": instance_id}, timeout=30)
        except ManagerError as exc:
            logger.warning("[活人感] 日记生成失败：%s", exc)
            return
        data = body.get("data") if isinstance(body, dict) else None
        data = data if isinstance(data, dict) else {}
        if data.get("skipped"):
            logger.info(
                "[活人感] 日记跳过：%s", data.get("reason") or "事件不足")
        else:
            logger.info("[活人感] 已生成 %s 的自我日记", today)

    async def _manager_settings(self, now: float) -> dict:
        """缓存管理器 presence 设置，用于安静时段与日记时间。"""
        if self._settings and now - self._settings_at < SETTINGS_TTL:
            return self._settings
        instance_id = await self._resolve_instance(now)
        if not instance_id:
            return {}
        try:
            body = await self.client.get(
                SETTINGS_PATH, query={"instance_id": instance_id})
        except ManagerError as exc:
            logger.debug("[活人感] 读取 presence 设置失败：%s", exc)
            self._settings_at = now
            return self._settings
        data = body.get("data") if isinstance(body, dict) else None
        if isinstance(data, dict):
            self._settings = data
            self._settings_at = now
        return self._settings

    async def _resolve_instance(self, now: float) -> str:
        """把平台前缀解析成管理器实例 ID，结果缓存 5 分钟。"""
        configured = str(self._cfg("instance_id", "") or "").strip()
        if configured:
            self._instance_id = configured
            return configured
        if self._instance_id and now - self._instance_at < INSTANCE_TTL:
            return self._instance_id
        if not self._platform_id:
            return ""
        self._instance_at = now
        try:
            body = await self.client.get(INSTANCES_PATH)
        except ManagerError as exc:
            logger.debug("[活人感] 实例列表不可用：%s", exc)
            return self._instance_id
        data = body.get("data") if isinstance(body, dict) else None
        if not isinstance(data, list):
            return self._instance_id
        prefix = self._platform_id
        for item in data:
            if not isinstance(item, dict):
                continue
            if prefix in {
                str(item.get("id") or ""),
                str(item.get("name") or ""),
                str(item.get("platform_id") or ""),
            }:
                self._instance_id = str(item.get("id") or "")
                logger.info(
                    "[活人感] 已按平台前缀 %s 解析实例 %s",
                    prefix, self._instance_id)
                return self._instance_id
        logger.warning("[活人感] 未找到平台前缀 %s 对应的管理器实例", prefix)
        return self._instance_id

    # ------------------------------------------------------------------ 群梗命令

    @filter.command("梗")
    async def meme_command(self, event: AstrMessageEvent):
        """群梗库：/梗 列表；/梗 收录 短语 | 解释；/梗 删除 短语。"""
        if not self._cfg("enable_group_memes", True):
            return
        text = str(event.get_message_str() or "").strip()
        for prefix in ("/梗", "／梗", "梗"):
            if text.startswith(prefix):
                text = text[len(prefix):].strip()
                break
        parts = text.split(maxsplit=1)
        action = parts[0] if parts else ""
        arg = parts[1].strip() if len(parts) > 1 else ""
        try:
            is_admin = bool(event.is_admin())
        except Exception:  # noqa: BLE001
            is_admin = False
        if action in ("", "列表", "list"):
            items = self.memes.active_items()
            if not items:
                yield event.plain_result(
                    "群梗库还是空的。管理员可以发：/梗 收录 短语 | 解释")
                return
            lines = ["本群梗："]
            for item in items[:15]:
                meaning = item.get("meaning") or "（还没写解释）"
                lines.append(f"- {item['phrase']}：{meaning}")
            lines.append("管理员可用 /梗 收录 短语 | 解释 补充。")
            yield event.plain_result("\n".join(lines))
            return
        if not is_admin:
            yield event.plain_result("只有管理员能改群梗库。")
            return
        if action in ("收录", "新增", "解释", "add"):
            if not arg:
                yield event.plain_result("用法：/梗 收录 短语 | 解释")
                return
            phrase, sep, meaning = arg.replace("｜", "|").partition("|")
            phrase = phrase.strip()
            if not phrase:
                yield event.plain_result("短语不能为空。")
                return
            item = self.memes.add_manual(phrase, meaning.strip())
            if not item:
                yield event.plain_result("收录失败，稍后再试。")
                return
            yield event.plain_result(
                f"已收录：{item['phrase']}"
                + (f" = {item['meaning']}" if item.get("meaning") else ""))
            return
        if action in ("删除", "移除", "delete", "remove"):
            if not arg:
                yield event.plain_result("用法：/梗 删除 短语")
                return
            if self.memes.remove_manual(arg):
                yield event.plain_result(f"已删除：{arg}")
            else:
                yield event.plain_result(f"没有找到：{arg}")
            return
        yield event.plain_result(
            "用法：/梗 列表；/梗 收录 短语 | 解释；/梗 删除 短语")

    # ------------------------------------------------------------------ Web API

    async def api_status(self):
        """管理器查看插件开关、缓冲与最近触发时间。"""
        return {
            "status": "ok",
            "data": {
                "enabled": bool(self._cfg("enabled", True)),
                "platform_id": self._platform_id,
                "instance_id": self._instance_id,
                "private_umos": len(self._private_umos),
                "activity_pending": len(self._activities),
                "private_buffers": len(self._buffers),
                "radar_pending": len(self._radar_pending),
                "radar_queue": len(self._radar_queue),
                "last_activity_flush": self._last_activity_flush,
                "last_scan_at": self._last_scan_at,
                "last_followup_at": self._last_followup_at,
                "last_diary_date": self._last_diary_date,
                "life_phase": str(
                    (self.life.state() or {}).get("phase") or ""),
                "memes_active": len(self.memes.active_items()),
                "vision_records": len(self.vision._items),
            },
        }

    async def api_send(self):
        """管理器专用私聊发送路由：只接受本机回环与已知私聊 UMO。"""
        host = str(getattr(request, "client_host", "") or "")
        username = str(getattr(request, "username", "") or "")
        if host not in LOOPBACK_HOSTS or not username:
            logger.warning(
                "[活人感] 拒绝非管理器发送请求：host=%s user=%s",
                host or "未知", username or "无")
            return {"status": "error", "message": "只允许本机管理器调用发送"}
        if not self._cfg("enabled", True):
            return {"status": "error", "message": "活人感插件已停用"}
        payload = await request.json(default={})
        if not isinstance(payload, dict):
            return {"status": "error", "message": "请求体应为 JSON 对象"}
        umo = str(payload.get("umo") or "").strip()
        text = " ".join(str(payload.get("text") or "").split())
        loop_id = str(payload.get("loop_id") or "").strip()
        if not is_private_umo(umo):
            return {"status": "error", "message": "只允许向私聊发送回访"}
        if umo not in self._private_umos:
            return {"status": "error", "message": "UMO 不是插件已知私聊"}
        if not text:
            return {"status": "error", "message": "发送内容为空"}
        text = text[:MAX_TEXT_CHARS]
        try:
            sent = await asyncio.wait_for(
                self.context.send_message(umo, MessageChain().message(text)),
                timeout=SEND_TIMEOUT)
        except Exception as exc:  # noqa: BLE001 - 返回错误由管理器展示
            logger.warning("[活人感] 管理器调用发送失败：%s", exc)
            return {"status": "error", "message": f"发送失败：{exc}"}
        if not sent:
            return {"status": "error", "message": "平台未找到该会话"}
        self._last_followup_at = time.time()
        logger.info("[活人感] 管理器已发送私聊回访 %s", loop_id or "-")
        return {
            "status": "ok",
            "data": {"sent": True, "umo": umo, "text": text,
                     "loop_id": loop_id},
        }
