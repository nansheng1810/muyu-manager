"""连续生活线：把作息、精力、当前活动与今日事件串成一条可注入的时间线。

插件只写 ``life.json``；管理器的设置与手动事件写在 ``life_admin.json``，
两边不互相覆盖。所有失败只记日志，绝不影响正常聊天。
"""

from __future__ import annotations

import datetime as _dt
import json
import os
import time
from pathlib import Path

WEEKDAY_LABEL = ("周一", "周二", "周三", "周四", "周五", "周六", "周日")

DEFAULT_SETTINGS = {
    "enabled": True,
    "inject": True,
    "inject_chars": 140,
    "sleep_time": "23:30",
    "wake_time": "07:30",
    "work_start": "09:00",
    "work_end": "18:00",
    "lunch_start": "12:00",
    "lunch_end": "13:30",
    "weekend_days": [5, 6],
    "quiet_start": "23:00",
    "quiet_end": "08:00",
}

PHASE_LABEL = {
    "sleeping": "睡觉",
    "quiet": "准备睡觉",
    "working": "上班",
    "lunch": "午休",
    "off_work": "下班休息",
    "weekend": "周末",
}

PHASE_DOING = {
    "sleeping": "在睡觉，迷迷糊糊的",
    "quiet": "准备睡了，说话会少一点",
    "working_morning": "在工位上干活，偶尔摸鱼看群",
    "working_afternoon": "在工位上干活，有点累了",
    "lunch": "刚吃完午饭，在休息",
    "off_work_evening": "刚下班，在回家路上",
    "off_work_night": "在家休息，刷手机",
    "weekend": "周末在家，比较闲",
}

PHASE_ENERGY = {
    "sleeping": 25,
    "quiet": 30,
    "working_morning": 62,
    "working_afternoon": 48,
    "lunch": 70,
    "off_work_evening": 66,
    "off_work_night": 52,
    "weekend": 76,
}

# 一天只记一次的节律事件。
PHASE_EVENT = {
    "wake": "起床",
    "work": "开始上班",
    "lunch": "午休",
    "off_work": "下班",
    "sleep": "准备睡觉",
    "weekend": "周末开始",
}


def _minutes(value) -> int | None:
    text = str(value or "").strip()
    if len(text) != 5 or text[2] != ":":
        return None
    try:
        hour, minute = int(text[:2]), int(text[3:])
    except ValueError:
        return None
    if not (0 <= hour <= 23 and 0 <= minute <= 59):
        return None
    return hour * 60 + minute


def _in_window(minute: int, start: str, end: str) -> bool:
    begin, finish = _minutes(start), _minutes(end)
    if begin is None or finish is None or begin == finish:
        return False
    if begin < finish:
        return begin <= minute < finish
    return minute >= begin or minute < finish


def _safe_int(value, default: int, low: int, high: int) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return default
    return max(low, min(high, number))


def normalize_settings(raw) -> dict:
    """合并默认值并做范围校验，管理器写坏数据也不会让插件崩。"""
    data = dict(DEFAULT_SETTINGS)
    if isinstance(raw, dict):
        for key in DEFAULT_SETTINGS:
            if key in raw:
                data[key] = raw[key]
    data["enabled"] = bool(data.get("enabled", True))
    data["inject"] = bool(data.get("inject", True))
    data["inject_chars"] = _safe_int(data.get("inject_chars"), 140, 60, 600)
    for key in ("sleep_time", "wake_time", "work_start", "work_end",
                "lunch_start", "lunch_end", "quiet_start", "quiet_end"):
        if _minutes(data.get(key)) is None:
            data[key] = DEFAULT_SETTINGS[key]
    days = data.get("weekend_days")
    if not isinstance(days, list):
        days = DEFAULT_SETTINGS["weekend_days"]
    data["weekend_days"] = sorted({
        int(item) for item in days
        if isinstance(item, (int, float)) or str(item).isdigit()
        if 0 <= int(item) <= 6
    })
    return data


def compute_phase(dt: _dt.datetime, settings: dict) -> str:
    minute = dt.hour * 60 + dt.minute
    if _in_window(minute, settings["sleep_time"], settings["wake_time"]):
        return "sleeping"
    if dt.weekday() in settings["weekend_days"]:
        return "weekend"
    if _in_window(minute, settings["quiet_start"], settings["quiet_end"]):
        return "quiet"
    if _in_window(minute, settings["lunch_start"], settings["lunch_end"]):
        return "lunch"
    if _in_window(minute, settings["work_start"], settings["work_end"]):
        return "working"
    return "off_work"


def doing_text(dt: _dt.datetime, phase: str) -> str:
    if phase == "working":
        key = "working_afternoon" if dt.hour >= 13 else "working_morning"
    elif phase == "off_work":
        key = "off_work_night" if dt.hour >= 19 else "off_work_evening"
    else:
        key = phase
    return PHASE_DOING.get(key, "在过自己的日子")


def energy_for(phase: str, dt: _dt.datetime) -> int:
    if phase == "working":
        key = "working_afternoon" if dt.hour >= 13 else "working_morning"
    elif phase == "off_work":
        key = "off_work_night" if dt.hour >= 19 else "off_work_evening"
    else:
        key = phase
    return PHASE_ENERGY.get(key, 55)


def _read(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _write(path: Path, data) -> None:
    tmp = path.with_name(path.name + ".tmp")
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, path)
    except OSError:
        tmp.unlink(missing_ok=True)
        raise


class LifeLine:
    """插件侧生活线。``life.json`` 只由插件写，``life_admin.json`` 只由管理器写。"""

    def __init__(self, data_dir: Path, cfg=None) -> None:
        self.data_dir = Path(data_dir)
        self.cfg = cfg or {}
        self.path = self.data_dir / "life.json"
        self.admin_path = self.data_dir / "life_admin.json"
        self._state: dict = {}
        self._events: list[dict] = []
        self._admin_mtime = 0.0
        self._settings = normalize_settings(self._cfg_settings())
        self._manual_ids: set[str] = set()
        self._load()

    def _cfg_settings(self) -> dict:
        raw = {
            "enabled": self.cfg.get("enable_life_line", True),
            "inject": self.cfg.get("life_inject", True),
            "inject_chars": self.cfg.get("life_inject_chars", 140),
            "sleep_time": self.cfg.get("life_sleep_time", "23:30"),
            "wake_time": self.cfg.get("life_wake_time", "07:30"),
            "work_start": self.cfg.get("life_work_start", "09:00"),
            "work_end": self.cfg.get("life_work_end", "18:00"),
            "lunch_start": self.cfg.get("life_lunch_start", "12:00"),
            "lunch_end": self.cfg.get("life_lunch_end", "13:30"),
            "weekend_days": self.cfg.get("life_weekend_days", [5, 6]),
            "quiet_start": self.cfg.get("life_quiet_start", "23:00"),
            "quiet_end": self.cfg.get("life_quiet_end", "08:00"),
        }
        return raw

    def _load(self) -> None:
        data = _read(self.path, {})
        if isinstance(data, dict):
            self._state = data.get("state") if isinstance(data.get("state"), dict) else {}
            events = data.get("events")
            self._events = [event for event in events if isinstance(event, dict)] if isinstance(events, list) else []
        self._sync_admin(force=True)

    def _sync_admin(self, force: bool = False) -> None:
        """管理器改了设置或手动事件时重新读取；按 mtime 节流。"""
        try:
            mtime = self.admin_path.stat().st_mtime
        except OSError:
            return
        if not force and mtime <= self._admin_mtime:
            return
        self._admin_mtime = mtime
        data = _read(self.admin_path, {})
        if not isinstance(data, dict):
            return
        self._settings = normalize_settings(data.get("settings"))
        events = data.get("events")
        if isinstance(events, list):
            for event in events:
                if not isinstance(event, dict):
                    continue
                event_id = str(event.get("id") or "")
                if not event_id or event_id in self._manual_ids:
                    continue
                self._manual_ids.add(event_id)
                self._events.append({
                    "ts": float(event.get("ts") or 0) or time.time(),
                    "kind": str(event.get("kind") or "manual"),
                    "text": str(event.get("text") or "")[:120],
                    "source": "manual",
                })
            self._trim()
            self._save()

    def _save(self) -> None:
        payload = {
            "version": 1,
            "updated": time.time(),
            "state": self._state,
            "events": self._events,
        }
        try:
            _write(self.path, payload)
        except OSError:
            pass

    def _trim(self) -> None:
        cutoff = time.time() - 14 * 86400
        self._events = [event for event in self._events if float(event.get("ts") or 0) >= cutoff]
        self._events = self._events[-400:]

    def settings(self) -> dict:
        return dict(self._settings)

    def tick(self, now: float | None = None) -> dict:
        """每分钟调用：阶段变化写事件，状态始终新鲜。"""
        now = time.time() if now is None else float(now)
        self._sync_admin()
        if not self._settings.get("enabled", True):
            return self._state
        dt = _dt.datetime.fromtimestamp(now)
        date = dt.strftime("%Y-%m-%d")
        phase = compute_phase(dt, self._settings)
        doing = doing_text(dt, phase)
        energy = energy_for(phase, dt)
        state = self._state if isinstance(self._state, dict) else {}
        changed = (
            state.get("date") != date
            or state.get("phase") != phase
            or state.get("doing") != doing
        )
        state.update({
            "date": date,
            "phase": phase,
            "phase_label": PHASE_LABEL.get(phase, phase),
            "doing": doing,
            "energy": energy,
            "weekday": WEEKDAY_LABEL[dt.weekday()],
            "clock": dt.strftime("%H:%M"),
        })
        if changed:
            state["since"] = now
            self._state = state
            self._append_rhythm_events(dt, phase, now)
            self._save()
        return state

    def _append_rhythm_events(self, dt: _dt.datetime, phase: str, now: float) -> None:
        date = dt.strftime("%Y-%m-%d")
        today = [event for event in self._events if event.get("date") == date]
        kinds = {str(event.get("kind") or "") for event in today}

        def add(kind: str) -> None:
            if kind in kinds:
                return
            kinds.add(kind)
            self._events.append({
                "ts": now,
                "date": date,
                "kind": kind,
                "text": PHASE_EVENT[kind],
                "source": "auto",
            })

        minute = dt.hour * 60 + dt.minute
        wake = _minutes(self._settings["wake_time"]) or 450
        work_start = _minutes(self._settings["work_start"]) or 540
        lunch_start = _minutes(self._settings["lunch_start"]) or 720
        if phase == "sleeping":
            add("sleep")
        elif phase == "weekend":
            add("weekend")
            if minute >= wake:
                add("wake")
        elif phase == "lunch":
            add("wake")
            add("work")
            add("lunch")
        elif phase == "working":
            add("wake")
            add("work")
            if minute >= lunch_start:
                add("lunch")
        elif phase == "off_work" and minute >= work_start:
            add("wake")
            add("work")
            add("lunch")
            add("off_work")
        elif phase == "quiet":
            add("wake")
            add("work")
            add("lunch")
            add("off_work")
            add("sleep")
        self._trim()

    def add_event(self, text: str, kind: str = "manual") -> dict:
        text = " ".join(str(text or "").split())[:120]
        if not text:
            return {}
        now = time.time()
        event = {
            "ts": now,
            "date": _dt.datetime.fromtimestamp(now).strftime("%Y-%m-%d"),
            "kind": kind,
            "text": text,
            "source": "manual",
        }
        self._events.append(event)
        self._trim()
        self._save()
        return event

    def events(self, days: int = 7) -> list[dict]:
        cutoff = time.time() - max(1, int(days)) * 86400
        return [
            event for event in self._events
            if float(event.get("ts") or 0) >= cutoff
        ]

    def state(self, now: float | None = None) -> dict:
        return self.tick(now)

    def block(self, now: float | None = None) -> str:
        """生成注入块；禁用或没有事件时返回空串。"""
        if not self._settings.get("inject", True):
            return ""
        state = self.tick(now)
        if not state:
            return ""
        date = str(state.get("date") or "")
        items = [
            f"{_dt.datetime.fromtimestamp(float(event['ts'])).strftime('%H:%M')} {event['text']}"
            for event in self._events
            if event.get("date") == date and event.get("text")
        ]
        head = (
            f"现在是{state.get('weekday')} {state.get('clock')}，"
            f"你在{state.get('phase_label')}，{state.get('doing')}，"
            f"精力 {state.get('energy')}/100。"
        )
        lines = [f"【你的生活线】{head}"]
        if items:
            lines.append("今天已经：" + "；".join(items[-5:]) + "。")
        lines.append("说话时可以自然带一点当下状态，但别每句都提作息，也别编造没发生的事。")
        block = "\n".join(lines)
        limit = _safe_int(self._settings.get("inject_chars"), 140, 60, 600)
        return block[:limit].rstrip()
