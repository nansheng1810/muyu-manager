import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from manager_client import ManagerClient, resolve_manager_url


class ResolveManagerUrlTest(unittest.TestCase):
    def test_runtime_file_overrides_default_port(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "AstrBot舰队管理器" / "data"
            data.mkdir(parents=True)
            (data / "manager_runtime.json").write_text(
                '{"url": "http://127.0.0.1:7312"}', encoding="utf-8")
            with patch.dict(os.environ, {"LOCALAPPDATA": tmp}):
                self.assertEqual(
                    resolve_manager_url("http://127.0.0.1:7311"),
                    "http://127.0.0.1:7312",
                )
                self.assertEqual(
                    ManagerClient("http://127.0.0.1:7311").base_url,
                    "http://127.0.0.1:7312",
                )

    def test_explicit_url_is_kept(self):
        self.assertEqual(
            resolve_manager_url("http://10.0.0.2:7311"),
            "http://10.0.0.2:7311",
        )


if __name__ == "__main__":
    unittest.main()
