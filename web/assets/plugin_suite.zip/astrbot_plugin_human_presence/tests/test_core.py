import datetime
import time
import unittest

from core import (
    MAX_CONTEXT_CHARS,
    build_activity_payload,
    build_scan_payload,
    followup_payload,
    is_private_umo,
    parse_context,
    platform_of,
    quiet_now,
    radar_key,
    should_diary,
    should_scan,
)


def ok(data):
    return {"status": "ok", "message": "", "data": data}


def ts(year, month, day, hour, minute):
    return datetime.datetime(year, month, day, hour, minute).timestamp()


class PlatformOfTest(unittest.TestCase):
    def test_qq_platforms_map_to_qq(self):
        self.assertEqual(platform_of(""), "qq")
        self.assertEqual(platform_of("aiocqhttp"), "qq")
        self.assertEqual(platform_of("qq"), "qq")
        self.assertEqual(platform_of("qq_official"), "qq")

    def test_non_qq_platforms(self):
        self.assertEqual(platform_of("bilibili"), "bilibili")
        self.assertEqual(platform_of("douyin"), "douyin")
        self.assertEqual(platform_of("telegram"), "")


class PrivateUmoTest(unittest.TestCase):
    def test_friend_message_is_private(self):
        self.assertTrue(is_private_umo("aiocqhttp:FriendMessage:10001"))
        self.assertTrue(is_private_umo("default:FriendMessage:10001"))

    def test_group_and_empty_are_not_private(self):
        self.assertFalse(is_private_umo("aiocqhttp:GroupMessage:123456"))
        self.assertFalse(is_private_umo("aiocqhttp:TempMessage:10001"))
        self.assertFalse(is_private_umo(""))
        self.assertFalse(is_private_umo(None))


class ActivityPayloadTest(unittest.TestCase):
    def test_batch_payload_normalizes_items(self):
        payload = build_activity_payload("inst-1", "dafeiyu", [
            {
                "platform": "qq",
                "person_key": "10001",
                "display_name": "阿明",
                "message_count": 3,
                "is_private": True,
                "occurred_at": 1000.0,
            },
            {
                "platform": "qq",
                "person_key": "10002",
                "message_count": "5",
                "is_private": 0,
            },
        ])
        self.assertEqual(payload["instance_id"], "inst-1")
        self.assertEqual(payload["platform_id"], "dafeiyu")
        self.assertEqual(len(payload["activities"]), 2)
        first, second = payload["activities"]
        self.assertEqual(first["person_key"], "10001")
        self.assertEqual(first["display_name"], "阿明")
        self.assertEqual(first["message_count"], 3)
        self.assertIs(first["is_private"], True)
        self.assertEqual(first["occurred_at"], 1000.0)
        self.assertEqual(second["message_count"], 5)
        self.assertIs(second["is_private"], False)

    def test_empty_person_key_is_dropped(self):
        payload = build_activity_payload("inst-1", "", [
            {"platform": "qq", "person_key": "", "message_count": 9},
            {"platform": "qq", "person_key": "10001", "message_count": 0},
        ])
        self.assertEqual(len(payload["activities"]), 1)
        self.assertEqual(payload["activities"][0]["message_count"], 1)

    def test_empty_batch(self):
        payload = build_activity_payload("inst-1", "dafeiyu", [])
        self.assertEqual(payload["activities"], [])


class ScanPayloadTest(unittest.TestCase):
    def test_payload_keeps_recent_text_and_marks_private(self):
        messages = [
            {"speaker": "用户", "text": "  明天再聊那个事  "},
            {"speaker": "", "text": "x" * 500},
            "not-a-dict",
            {"speaker": "用户", "text": "   "},
        ]
        payload = build_scan_payload(
            "inst-1", "dafeiyu", "qq",
            "aiocqhttp:FriendMessage:10001", "10001", messages,
        )
        self.assertEqual(payload["instance_id"], "inst-1")
        self.assertEqual(payload["platform_id"], "dafeiyu")
        self.assertEqual(payload["platform"], "qq")
        self.assertEqual(payload["thread_key"], "aiocqhttp:FriendMessage:10001")
        self.assertEqual(payload["person_key"], "10001")
        self.assertIs(payload["is_private"], True)
        self.assertEqual(len(payload["messages"]), 2)
        self.assertEqual(payload["messages"][0]["text"], "明天再聊那个事")
        self.assertEqual(payload["messages"][1]["speaker"], "用户")
        self.assertEqual(len(payload["messages"][1]["text"]), 300)

    def test_payload_limits_to_twenty_messages(self):
        messages = [{"speaker": "用户", "text": f"m{i}"} for i in range(30)]
        payload = build_scan_payload(
            "inst-1", "", "qq", "aiocqhttp:FriendMessage:1", "1", messages)
        self.assertEqual(len(payload["messages"]), 20)
        self.assertEqual(payload["messages"][0]["text"], "m10")

    def test_empty_payload(self):
        payload = build_scan_payload(
            "inst-1", "", "qq", "aiocqhttp:FriendMessage:1", "1", [])
        self.assertEqual(payload["messages"], [])
        self.assertIs(payload["is_private"], True)


class ParseContextTest(unittest.TestCase):
    def test_full_context_builds_short_block(self):
        body = ok({
            "relation": {"id": "r1"},
            "nickname": "阿明",
            "stage": "familiar",
            "allow_memory": True,
            "milestones": [
                {"title": "第一次私聊"},
                {"title": "累计聊到 10 条消息"},
                {"title": "第三条不该出现"},
            ],
            "diary_summary": "昨天有点低落，但后来被哄好了。",
        })
        parsed = parse_context(body)
        self.assertEqual(parsed["nickname"], "阿明")
        self.assertEqual(parsed["stage"], "familiar")
        self.assertEqual(parsed["stage_label"], "熟悉")
        self.assertTrue(parsed["allow_memory"])
        self.assertEqual(len(parsed["milestones"]), 2)
        self.assertIn("阿明", parsed["block"])
        self.assertIn("熟悉", parsed["block"])
        self.assertIn("第一次私聊", parsed["block"])
        self.assertIn("昨天有点低落", parsed["block"])
        self.assertIn("别主动提日记", parsed["block"])
        self.assertLessEqual(len(parsed["block"]), 250)

    def test_allow_memory_false_hides_nickname_and_milestones(self):
        body = ok({
            "relation": {"id": "r1"},
            "nickname": "阿明",
            "stage": "close",
            "allow_memory": False,
            "milestones": [{"title": "第一次私聊"}],
            "diary_summary": "今天还行。",
        })
        parsed = parse_context(body)
        self.assertFalse(parsed["allow_memory"])
        self.assertNotIn("阿明", parsed["block"])
        self.assertNotIn("第一次私聊", parsed["block"])
        self.assertIn("今天还行", parsed["block"])

    def test_missing_relation_only_injects_diary(self):
        body = ok({
            "relation": None,
            "nickname": "",
            "stage": "",
            "allow_memory": False,
            "milestones": [],
            "diary_summary": "昨天睡得很晚。",
        })
        parsed = parse_context(body)
        self.assertEqual(parsed["nickname"], "")
        self.assertIn("昨天睡得很晚", parsed["block"])
        self.assertLessEqual(len(parsed["block"]), 250)

    def test_empty_or_invalid_body_returns_empty_block(self):
        for body in (None, {}, {"status": "error"}, ok({})):
            parsed = parse_context(body)
            self.assertEqual(parsed["block"], "")
            self.assertFalse(parsed["allow_memory"])
            self.assertEqual(parsed["milestones"], [])

    def test_unwrapped_data_is_supported(self):
        parsed = parse_context({
            "nickname": "阿明",
            "stage": "stranger",
            "allow_memory": True,
            "milestones": [],
            "diary_summary": "",
        })
        self.assertIn("阿明", parsed["block"])
        self.assertEqual(parsed["stage_label"], "陌生")

    def test_takeover_thread_never_injects(self):
        body = ok({
            "relation": {"id": "r1"},
            "takeover": True,
            "nickname": "阿明",
            "stage": "close",
            "allow_memory": True,
            "milestones": [{"title": "第一次私聊"}],
            "diary_summary": "昨天有点低落。",
        })
        parsed = parse_context(body)
        self.assertTrue(parsed["takeover"])
        self.assertEqual(parsed["block"], "")
        self.assertEqual(parsed["nickname"], "")
        self.assertEqual(parsed["milestones"], [])
        self.assertEqual(parsed["diary_summary"], "")

    def test_normal_context_marks_takeover_false(self):
        parsed = parse_context(ok({"nickname": "阿明", "allow_memory": True}))
        self.assertFalse(parsed["takeover"])
        self.assertIn("阿明", parsed["block"])

    def test_block_is_truncated_to_limit(self):
        body = ok({
            "relation": {"id": "r1"},
            "nickname": "昵称" * 50,
            "stage": "close",
            "allow_memory": True,
            "milestones": [{"title": "事件" * 100}, {"title": "事件" * 100}],
            "diary_summary": "摘要" * 200,
        })
        parsed = parse_context(body)
        self.assertLessEqual(len(parsed["block"]), MAX_CONTEXT_CHARS)
        self.assertFalse(parsed["block"].endswith("\n"))


class ShouldScanTest(unittest.TestCase):
    def setUp(self):
        self.base = {
            "private": True,
            "message_count": 0,
            "last_scan_at": 1000.0,
            "texts": [],
        }

    def test_no_new_message_never_scans(self):
        self.assertFalse(should_scan(
            {**self.base, "last_scan_at": 1000.0}, now=1000.0 + 48 * 3600))

    def test_min_messages_triggers(self):
        self.assertFalse(should_scan({**self.base, "message_count": 5}, now=1001))
        self.assertTrue(should_scan({**self.base, "message_count": 6}, now=1001))

    def test_clue_word_triggers_with_single_message(self):
        state = {**self.base, "message_count": 1, "texts": ["那明天再聊"]}
        self.assertTrue(should_scan(state, now=1001))

    def test_elapsed_hours_triggers_with_new_message(self):
        state = {**self.base, "message_count": 1}
        self.assertFalse(should_scan(state, now=1000.0 + 6 * 3600 - 1))
        self.assertTrue(should_scan(state, now=1000.0 + 6 * 3600))

    def test_first_scan_needs_message_or_clue(self):
        state = {**self.base, "last_scan_at": 0.0, "message_count": 0}
        self.assertFalse(should_scan(state, now=10**9))

    def test_group_never_scans(self):
        state = {**self.base, "private": False, "message_count": 20,
                 "texts": ["明天聊"]}
        self.assertFalse(should_scan(state, now=1001))

    def test_retry_after_blocks_until_due(self):
        state = {**self.base, "message_count": 8, "retry_after": 2000.0}
        self.assertFalse(should_scan(state, now=1500.0))
        self.assertTrue(should_scan(state, now=2000.0))


class RadarKeyTest(unittest.TestCase):
    def test_key_uses_origin_and_message_id(self):
        self.assertEqual(radar_key("aiocqhttp:GroupMessage:1", 42),
                         "aiocqhttp:GroupMessage:1:42")
        self.assertEqual(radar_key("aiocqhttp:GroupMessage:1", ""),
                         "aiocqhttp:GroupMessage:1:0")
        self.assertEqual(radar_key("aiocqhttp:GroupMessage:1"),
                         "aiocqhttp:GroupMessage:1:0")


class QuietNowTest(unittest.TestCase):
    def test_cross_midnight_window(self):
        self.assertTrue(quiet_now("23:00", "08:00", ts(2026, 11, 5, 23, 30)))
        self.assertTrue(quiet_now("23:00", "08:00", ts(2026, 11, 6, 7, 59)))
        self.assertFalse(quiet_now("23:00", "08:00", ts(2026, 11, 6, 8, 0)))
        self.assertFalse(quiet_now("23:00", "08:00", ts(2026, 11, 5, 12, 0)))

    def test_same_day_window(self):
        self.assertTrue(quiet_now("09:00", "18:00", ts(2026, 11, 5, 10, 0)))
        self.assertFalse(quiet_now("09:00", "18:00", ts(2026, 11, 5, 18, 0)))

    def test_invalid_or_empty_window_is_not_quiet(self):
        self.assertFalse(quiet_now("", "", ts(2026, 11, 5, 23, 0)))
        self.assertFalse(quiet_now("25:00", "08:00", ts(2026, 11, 5, 23, 0)))
        self.assertFalse(quiet_now("08:00", "08:00", ts(2026, 11, 5, 8, 0)))


class FollowupPayloadTest(unittest.TestCase):
    def test_real_due_loop_is_returned(self):
        body = ok({
            "loops": [{
                "id": "lp_1",
                "thread_key": "aiocqhttp:FriendMessage:10001",
                "follow_up_text": "上次说的那个事后来怎么样了？",
                "person_key": "10001",
                "platform": "qq",
            }],
            "shadow": False,
            "blocked_reason": "",
        })
        items = followup_payload(body)
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["loop_id"], "lp_1")
        self.assertEqual(items[0]["umo"], "aiocqhttp:FriendMessage:10001")
        self.assertEqual(items[0]["text"], "上次说的那个事后来怎么样了？")
        self.assertEqual(items[0]["person_key"], "10001")

    def test_shadow_returns_nothing(self):
        body = ok({
            "loops": [{
                "id": "lp_1",
                "thread_key": "aiocqhttp:FriendMessage:10001",
                "follow_up_text": "在吗",
            }],
            "shadow": True,
            "blocked_reason": "",
        })
        self.assertEqual(followup_payload(body), [])

    def test_blocked_or_error_returns_nothing(self):
        loop = {
            "id": "lp_1",
            "thread_key": "aiocqhttp:FriendMessage:10001",
            "follow_up_text": "在吗",
        }
        self.assertEqual(followup_payload(ok({
            "loops": [loop], "shadow": False,
            "blocked_reason": "proactive_chat_conflict"})), [])
        self.assertEqual(followup_payload({"status": "error"}), [])
        self.assertEqual(followup_payload(None), [])

    def test_group_umo_and_incomplete_loops_are_dropped(self):
        body = ok({
            "loops": [
                {"id": "lp_1", "thread_key": "aiocqhttp:GroupMessage:1",
                 "follow_up_text": "在吗"},
                {"id": "lp_2", "thread_key": "aiocqhttp:FriendMessage:1",
                 "follow_up_text": ""},
                {"id": "", "thread_key": "aiocqhttp:FriendMessage:1",
                 "follow_up_text": "在吗"},
                {"id": "lp_3", "thread_key": "aiocqhttp:FriendMessage:2",
                 "follow_up_text": "第一行\n第二行"},
            ],
            "shadow": False,
        })
        items = followup_payload(body)
        self.assertEqual([item["loop_id"] for item in items], ["lp_3"])
        self.assertEqual(items[0]["text"], "第一行 第二行")

    def test_unwrapped_data_is_supported(self):
        items = followup_payload({
            "loops": [{"id": "lp_1", "thread_key": "aiocqhttp:FriendMessage:1",
                       "follow_up_text": "在吗"}],
            "shadow": False,
        })
        self.assertEqual(len(items), 1)


class ShouldDiaryTest(unittest.TestCase):
    def test_triggers_after_diary_time_once_per_day(self):
        now = ts(2026, 11, 5, 23, 35)
        today = time.strftime("%Y-%m-%d", time.localtime(now))
        self.assertTrue(should_diary(now, "23:30", "", True))
        self.assertFalse(should_diary(now, "23:30", today, True))
        self.assertFalse(should_diary(now, "23:30", "", False))

    def test_before_time_does_not_trigger(self):
        now = ts(2026, 11, 5, 23, 0)
        self.assertFalse(should_diary(now, "23:30", "", True))

    def test_invalid_time_does_not_trigger(self):
        now = ts(2026, 11, 5, 23, 35)
        self.assertFalse(should_diary(now, "", "", True))
        self.assertFalse(should_diary(now, "abc", "", True))


if __name__ == "__main__":
    unittest.main()
