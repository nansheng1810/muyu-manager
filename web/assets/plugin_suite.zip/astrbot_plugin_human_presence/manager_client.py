"""牧鱼管理器 HTTP 客户端：本地回环短超时，失败统一抛 ManagerError。

插件所有上报、扫描、回访与日记请求都走这里；调用方必须捕获
ManagerError 并只记日志，绝不能让管理器不可达影响正常聊天。
"""

from __future__ import annotations

import asyncio
import json
import os
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

DEFAULT_MANAGER_URL = "http://127.0.0.1:7311"
DEFAULT_TIMEOUT = 3.0
MAX_TIMEOUT = 30.0


def resolve_manager_url(configured="", default=DEFAULT_MANAGER_URL) -> str:
    """解析管理器地址：显式非默认配置优先，否则读管理器写出的运行时端口。"""
    value = str(configured or "").strip().rstrip("/")
    default_text = str(default or DEFAULT_MANAGER_URL).rstrip("/")
    if value and value != default_text:
        return value
    try:
        base = Path(os.environ.get("LOCALAPPDATA") or str(Path.home()))
        path = base / "AstrBot舰队管理器" / "data" / "manager_runtime.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        url = str(data.get("url") or "").strip().rstrip("/")
        if url.startswith(("http://127.0.0.1:", "http://localhost:")):
            return url
    except (OSError, ValueError, TypeError):
        pass
    return value or default_text


class ManagerError(RuntimeError):
    """管理器请求失败（网络、超时、非 JSON 或业务错误）。"""


class ManagerClient:
    """极简异步 JSON 客户端，内部用线程执行阻塞 urllib 请求。"""

    def __init__(self, base_url=DEFAULT_MANAGER_URL, timeout=DEFAULT_TIMEOUT):
        """初始化客户端。

        Args:
            base_url: 管理器根地址，默认本机 7311。
            timeout: 单次请求超时秒数，夹取到 0.5–30 秒。
        """
        self.base_url = resolve_manager_url(base_url)
        self._configured = str(base_url or DEFAULT_MANAGER_URL)
        try:
            value = float(timeout)
        except (TypeError, ValueError):
            value = DEFAULT_TIMEOUT
        self.timeout = max(0.5, min(MAX_TIMEOUT, value))

    async def get(self, path: str, query=None, timeout=None) -> dict:
        """发送 GET 请求。

        Args:
            path: 以 ``/`` 开头的接口路径。
            query: 查询参数字典；``None`` 或空串的键会省略。
            timeout: 覆盖默认超时秒数。

        Returns:
            管理器返回的 JSON 字典。
        """
        return await self._request("GET", path, query=query, timeout=timeout)

    async def post(self, path: str, payload=None, timeout=None) -> dict:
        """发送 POST JSON 请求。

        Args:
            path: 以 ``/`` 开头的接口路径。
            payload: 请求体字典。
            timeout: 覆盖默认超时秒数。

        Returns:
            管理器返回的 JSON 字典。
        """
        return await self._request(
            "POST", path, payload=payload, timeout=timeout)

    async def _request(self, method: str, path: str, payload=None,
                       query=None, timeout=None) -> dict:
        """执行一次 JSON 请求。

        Args:
            method: ``GET`` 或 ``POST``。
            path: 接口路径。
            payload: POST 请求体。
            query: 查询参数。
            timeout: 覆盖默认超时。

        Returns:
            解析后的 JSON 对象。

        Raises:
            ManagerError: 网络错误、超时、响应不是对象或 ``status=error``。
        """
        try:
            seconds = float(timeout) if timeout is not None else self.timeout
        except (TypeError, ValueError):
            seconds = self.timeout
        seconds = max(0.5, min(MAX_TIMEOUT, seconds))
        # 管理器端口可能因 7311 被占而顺延；每次请求前重新发现一次。
        self.base_url = resolve_manager_url(self._configured)
        url = self.base_url + "/" + str(path or "").lstrip("/")
        params = {
            str(key): str(value) for key, value in (query or {}).items()
            if value is not None and str(value) != ""
        }
        if params:
            url += "?" + urllib.parse.urlencode(params)
        body = None
        headers = {"Accept": "application/json"}
        if payload is not None:
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json"

        def call():
            req = urllib.request.Request(
                url, data=body, headers=headers, method=method)
            with urllib.request.urlopen(req, timeout=seconds) as response:
                raw = response.read()
            try:
                data = json.loads(raw.decode("utf-8", "replace"))
            except ValueError:
                raise ManagerError("管理器响应不是 JSON") from None
            if not isinstance(data, dict):
                raise ManagerError("管理器响应不是对象")
            if data.get("status") == "error":
                raise ManagerError(str(data.get("message") or "管理器返回错误"))
            return data

        try:
            return await asyncio.wait_for(
                asyncio.to_thread(call), timeout=seconds + 0.5)
        except ManagerError:
            raise
        except urllib.error.HTTPError as exc:
            message = ""
            try:
                data = json.loads(exc.read().decode("utf-8", "replace"))
                if isinstance(data, dict):
                    message = str(data.get("message") or "")
            except Exception:  # noqa: BLE001 - 错误体不是 JSON 时用状态码
                message = ""
            raise ManagerError(
                message or f"{method} {path} HTTP {exc.code}") from None
        except Exception as exc:  # noqa: BLE001 - 统一转成可吞掉的错误
            raise ManagerError(f"{method} {path} 失败：{exc}") from None
