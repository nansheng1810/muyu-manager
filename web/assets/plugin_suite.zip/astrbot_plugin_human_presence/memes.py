"""群梗库：自动捕捉群里的高频短句，维护正式梗表，并在回复前注入。

数据分两个文件，避免插件和管理器互相覆盖：

* ``memes.json``：正式梗表（管理器与 /梗 命令写，插件只读并用于注入）
* ``meme_candidates.json``：自动候选与统计（插件写，管理器确认后转正）
"""

from __future__ import annotations

import json
import os
import re
import time
import uuid
from pathlib import Path

PHRASE_RE = re.compile(r"[一-龥A-Za-z0-9]{2,8}")

# 自动候选必须排除的日常词，避免把普通口语当成群梗。
STOP_PHRASES = {
    "什么", "这个", "那个", "就是", "不是", "真的", "哈哈", "你们", "我们",
    "他们", "一个", "没有", "可以", "这样", "然后", "现在", "时候", "知道",
    "觉得", "应该", "因为", "所以", "但是", "如果", "还是", "已经", "怎么",
    "为什么", "今天", "明天", "昨天", "群里", "消息", "图片", "表情", "一下",
    "有点", "是不是", "有没有", "能不能", "好不好", "对不", "对啊", "好的",
    "收到", "谢谢", "没事", "问题", "东西", "事情", "感觉", "其实", "不过",
    "而且", "或者", "还有", "这里", "那里", "自己", "别人", "大家", "老师",
    "主人", "老板", "机器人", "大肥鱼", "草", "笑死", "离谱", "确实", "行吧",
}

DEFAULT_SETTINGS = {
    "enabled": True,
    "inject": True,
    "max_inject": 8,
    "auto_capture": True,
    "min_count": 4,
    "min_speakers": 2,
    "window_hours": 72,
    "max_candidates": 80,
}


def _read(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _write(path: Path, data) -> None:
    tmp = path.with_name(path.name + ".tmp")
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, path)
    except OSError:
        tmp.unlink(missing_ok=True)
        raise


def normalize_settings(raw) -> dict:
    data = dict(DEFAULT_SETTINGS)
    if isinstance(raw, dict):
        data.update({key: raw[key] for key in DEFAULT_SETTINGS if key in raw})
    data["enabled"] = bool(data.get("enabled", True))
    data["inject"] = bool(data.get("inject", True))
    data["auto_capture"] = bool(data.get("auto_capture", True))

    def clamp(key, low, high):
        try:
            data[key] = max(low, min(high, int(data.get(key, DEFAULT_SETTINGS[key]))))
        except (TypeError, ValueError):
            data[key] = DEFAULT_SETTINGS[key]

    clamp("max_inject", 0, 20)
    clamp("min_count", 2, 50)
    clamp("min_speakers", 1, 20)
    clamp("window_hours", 1, 24 * 30)
    clamp("max_candidates", 10, 500)
    return data


def candidates_from_text(text: str) -> list[str]:
    """从一条群消息提取可能的梗短语（2-8 字连续片段）。"""
    found: list[str] = []
    for chunk in PHRASE_RE.findall(str(text or "")):
        phrase = chunk.strip()
        if not (2 <= len(phrase) <= 8):
            continue
        if phrase in STOP_PHRASES:
            continue
        # 纯数字、纯英文单字、包含太多重复字符的片段不算梗。
        if phrase.isdigit():
            continue
        if len(set(phrase)) <= 1:
            continue
        found.append(phrase)
    return found


class MemeLibrary:
    """插件侧群梗库：统计候选 + 注入正式梗。"""

    def __init__(self, data_dir: Path, cfg=None) -> None:
        self.data_dir = Path(data_dir)
        self.cfg = cfg or {}
        self.path = self.data_dir / "memes.json"
        self.candidate_path = self.data_dir / "meme_candidates.json"
        self._dirty = False
        self._last_flush = 0.0
        self._load()

    def _cfg_settings(self) -> dict:
        return {
            "enabled": self.cfg.get("enable_group_memes", True),
            "inject": self.cfg.get("meme_inject", True),
            "max_inject": self.cfg.get("meme_max_inject", 8),
            "auto_capture": self.cfg.get("meme_auto_capture", True),
            "min_count": self.cfg.get("meme_min_count", 4),
            "min_speakers": self.cfg.get("meme_min_speakers", 2),
            "window_hours": self.cfg.get("meme_window_hours", 72),
            "max_candidates": self.cfg.get("meme_max_candidates", 80),
        }

    def _load(self) -> None:
        data = _read(self.candidate_path, {})
        if not isinstance(data, dict):
            data = {}
        main = _read(self.path, {})
        admin = main.get("settings") if isinstance(main, dict) else None
        settings = normalize_settings(
            admin if isinstance(admin, dict) else (data.get("settings") or self._cfg_settings()))
        self._settings = settings
        self._groups: dict[str, dict] = {}
        groups = data.get("groups")
        if isinstance(groups, dict):
            for group_id, stats in groups.items():
                if not isinstance(stats, dict):
                    continue
                cleaned = {}
                for phrase, item in stats.items():
                    if not isinstance(item, dict):
                        continue
                    try:
                        count = int(item.get("count") or 0)
                    except (TypeError, ValueError):
                        count = 0
                    if count <= 0:
                        continue
                    cleaned[str(phrase)] = {
                        "count": count,
                        "speakers": [str(x) for x in item.get("speakers") or []][:12],
                        "first": float(item.get("first") or 0),
                        "last": float(item.get("last") or 0),
                        "sample": str(item.get("sample") or "")[:60],
                    }
                if cleaned:
                    self._groups[str(group_id)] = cleaned
        self._items = self._load_items()
        self._manual_ids = {str(item.get("id") or "") for item in self._items}
        self._items_mtime = 0.0

    def _load_items(self) -> list[dict]:
        data = _read(self.path, {})
        items = data.get("items") if isinstance(data, dict) else None
        if not isinstance(items, list):
            return []
        result = []
        for item in items:
            if not isinstance(item, dict):
                continue
            phrase = str(item.get("phrase") or "").strip()[:20]
            if not phrase:
                continue
            result.append({
                "id": str(item.get("id") or f"m_{uuid.uuid4().hex[:8]}"),
                "phrase": phrase,
                "meaning": str(item.get("meaning") or "")[:120],
                "example": str(item.get("example") or "")[:120],
                "status": str(item.get("status") or "active"),
                "count": int(item.get("count") or 0),
                "source": str(item.get("source") or "manual"),
            })
        return result

    def settings(self) -> dict:
        return dict(self._settings)

    def observe(self, group_id: str, sender_id: str, text: str,
                now: float | None = None) -> None:
        """统计群消息中的高频短句；命令、链接和表情不参与。"""
        if not self._settings.get("auto_capture", True):
            return
        group_id = str(group_id or "").strip()
        text = " ".join(str(text or "").split())
        if not group_id or not text or len(text) > 300:
            return
        if text.startswith(("/", "／", "http://", "https://")):
            return
        if text.startswith("[") and text.endswith("]"):
            return
        now = time.time() if now is None else float(now)
        stats = self._groups.setdefault(group_id, {})
        for phrase in candidates_from_text(text):
            item = stats.get(phrase)
            if item is None:
                item = {"count": 0, "speakers": [], "first": now,
                        "last": now, "sample": text[:60]}
                stats[phrase] = item
            item["count"] += 1
            item["last"] = now
            speaker = str(sender_id or "")
            if speaker and speaker not in item["speakers"] and len(item["speakers"]) < 12:
                item["speakers"].append(speaker)
            if not item.get("sample") or len(item["sample"]) < 12:
                item["sample"] = text[:60]
            self._dirty = True
        if len(stats) > 400:
            keep = sorted(stats.items(), key=lambda kv: kv[1].get("count", 0), reverse=True)[:200]
            self._groups[group_id] = dict(keep)
        if self._dirty and now - self._last_flush >= 60:
            self.flush(now)

    def flush(self, now: float | None = None) -> None:
        """把达到阈值的统计写入候选文件；保留最近窗口内的数据。"""
        now = time.time() if now is None else float(now)
        self._last_flush = now
        if not self._dirty:
            return
        self._dirty = False
        cutoff = now - int(self._settings.get("window_hours", 72)) * 3600
        min_count = int(self._settings.get("min_count", 4))
        min_speakers = int(self._settings.get("min_speakers", 2))
        groups = {}
        for group_id, stats in self._groups.items():
            cleaned = {}
            for phrase, item in stats.items():
                if float(item.get("last") or 0) < cutoff:
                    continue
                if int(item.get("count") or 0) < min_count:
                    continue
                if len(item.get("speakers") or []) < min_speakers:
                    continue
                cleaned[phrase] = item
            if cleaned:
                groups[group_id] = cleaned
        self._groups = groups
        known = {str(item.get("phrase") or "") for item in self._load_items()}
        payload = {
            "version": 1,
            "updated": now,
            "settings": self._settings,
            "groups": {
                group_id: {
                    phrase: item
                    for phrase, item in stats.items()
                    if phrase not in known
                }
                for group_id, stats in groups.items()
            },
        }
        try:
            _write(self.candidate_path, payload)
        except OSError:
            pass

    def active_items(self) -> list[dict]:
        try:
            mtime = self.path.stat().st_mtime
        except OSError:
            mtime = 0.0
        if mtime > self._items_mtime:
            self._items_mtime = mtime
            self._items = self._load_items()
        return [item for item in self._items if item.get("status") == "active"]

    def block(self) -> str:
        """正式梗注入块；没有启用或没有梗时返回空串。"""
        if not self._settings.get("enabled", True) or not self._settings.get("inject", True):
            return ""
        items = self.active_items()
        if not items:
            return ""
        limit = int(self._settings.get("max_inject", 8))
        lines = ["【本群梗】这些是群里常用的梗，理解意思即可，合适时自然用，不要解释，也不要硬塞："]
        for item in items[:limit]:
            phrase = item.get("phrase") or ""
            meaning = item.get("meaning") or ""
            if meaning:
                lines.append(f"- “{phrase}” = {meaning}")
            else:
                lines.append(f"- “{phrase}”（群里的口头梗，别当真）")
        return "\n".join(lines)

    def add_manual(self, phrase: str, meaning: str = "", example: str = "") -> dict:
        phrase = " ".join(str(phrase or "").split())[:20]
        if not phrase:
            return {}
        now = time.time()
        data = _read(self.path, {})
        if not isinstance(data, dict) or not isinstance(data.get("items"), list):
            data = {"version": 1, "items": []}
        for item in data["items"]:
            if isinstance(item, dict) and str(item.get("phrase") or "") == phrase:
                if meaning:
                    item["meaning"] = str(meaning)[:120]
                if example:
                    item["example"] = str(example)[:120]
                item["status"] = "active"
                item["updated"] = now
                _write(self.path, data)
                self._items = self._load_items()
                return item
        item = {
            "id": f"m_{uuid.uuid4().hex[:8]}",
            "phrase": phrase,
            "meaning": str(meaning or "")[:120],
            "example": str(example or "")[:120],
            "status": "active",
            "count": 0,
            "source": "manual",
            "first_seen": now,
            "last_seen": now,
            "updated": now,
        }
        data["items"].append(item)
        _write(self.path, data)
        self._items = self._load_items()
        return item

    def remove_manual(self, phrase: str) -> bool:
        phrase = str(phrase or "").strip()
        data = _read(self.path, {})
        if not isinstance(data, dict) or not isinstance(data.get("items"), list):
            return False
        before = len(data["items"])
        data["items"] = [
            item for item in data["items"]
            if not (isinstance(item, dict) and str(item.get("phrase") or "") == phrase)
        ]
        if len(data["items"]) == before:
            return False
        _write(self.path, data)
        return True
