"""活人感插件的纯函数：平台判断、上报 payload、上下文解析与时间判定。

本模块不依赖 AstrBot，方便单元测试；所有网络与事件处理在 main.py。
"""

from __future__ import annotations

import datetime as _dt
import time

QQ_PLATFORMS = ("", "aiocqhttp", "qq", "qq_official")
# 出现这些词时认为对方提到了未来指向，值得立刻请求一次未完成话题扫描。
SCAN_CLUES = (
    "下次", "明天", "回头", "再聊", "记得", "到时候", "改天", "晚点",
    "有空", "以后", "之后", "再说", "等你", "提醒我",
)
STAGE_LABELS = {
    "stranger": "陌生",
    "familiar": "熟悉",
    "close": "亲近",
}
MAX_CONTEXT_CHARS = 320
MAX_DIARY_CHARS = 120
MAX_SCAN_MESSAGES = 20
MAX_ACTIVITIES = 100


def platform_of(name) -> str:
    """把 AstrBot 平台名映射为管理器使用的平台标识。

    Args:
        name: AstrBot 平台名，例如 ``aiocqhttp``、``bilibili``。

    Returns:
        空串/``aiocqhttp``/``qq``/``qq_official`` 返回 ``qq``；
        名称含 ``bili`` 返回 ``bilibili``，含 ``douyin`` 返回 ``douyin``；
        其它平台返回空串，由调用方跳过，避免误报成 QQ。
    """
    text = str(name or "").strip().lower()
    if text in QQ_PLATFORMS:
        return "qq"
    if "bili" in text:
        return "bilibili"
    if "douyin" in text:
        return "douyin"
    return ""


def is_private_umo(umo) -> bool:
    """判断统一消息来源是否是 QQ 私聊（好友单聊）。

    Args:
        umo: ``platform:message_type:session_id`` 格式的来源串。

    Returns:
        仅当消息类型段为 ``FriendMessage`` 时返回 True；群聊、临时会话、
        空值都返回 False，避免把回访发到群里。
    """
    parts = str(umo or "").split(":")
    return len(parts) >= 3 and parts[1] == "FriendMessage"


def _text(value, limit: int = 0) -> str:
    text = str(value or "").strip()
    return text[:limit] if limit and limit > 0 else text


def _int(value, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _float(value, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def build_activity_payload(instance_id, platform_id, activities) -> dict:
    """把一批关系活动整理成管理器 ``/api/presence/activity`` 的请求体。

    Args:
        instance_id: 管理器实例 ID；留空时管理器按 platform_id 解析。
        platform_id: AstrBot 平台适配器 ID，通常是 UMO 前缀。
        activities: 活动字典列表，每项至少包含 ``person_key``；
            ``message_count`` 缺省或非法时按 1 条计，空 ``person_key`` 丢弃。

    Returns:
        ``{"instance_id", "platform_id", "activities"}``，活动数最多 100 条。
    """
    items = []
    for raw in list(activities or [])[:MAX_ACTIVITIES]:
        if not isinstance(raw, dict):
            continue
        person_key = _text(raw.get("person_key"), 200)
        if not person_key:
            continue
        count = _int(raw.get("message_count"), 1)
        private = raw.get("is_private")
        items.append({
            "platform": _text(raw.get("platform") or "qq", 40) or "qq",
            "person_key": person_key,
            "display_name": _text(raw.get("display_name"), 80),
            "message_count": max(1, count),
            "is_private": bool(private) if not isinstance(private, str)
            else private.strip().lower() in {"1", "true", "yes", "private"},
            "occurred_at": _float(raw.get("occurred_at"), time.time()),
        })
    return {
        "instance_id": _text(instance_id, 200),
        "platform_id": _text(platform_id, 200),
        "activities": items,
    }


def build_scan_payload(instance_id, platform_id, platform, umo, person_key,
                       messages) -> dict:
    """把最近私聊整理成管理器 ``/api/presence/scan`` 的请求体。

    Args:
        instance_id: 管理器实例 ID。
        platform_id: AstrBot 平台适配器 ID。
        platform: 管理器平台标识，通常为 ``qq``。
        umo: 统一消息来源，作为回访的 thread_key。
        person_key: 私聊对象标识。
        messages: 消息字典列表，按时间顺序；只保留最后 20 条非空文本。

    Returns:
        固定 ``is_private=True`` 的扫描请求体；群聊不会走这里。
    """
    transcript = []
    for raw in list(messages or [])[-MAX_SCAN_MESSAGES:]:
        if not isinstance(raw, dict):
            continue
        text = _text(raw.get("text"), 300)
        if not text:
            continue
        transcript.append({
            "speaker": _text(raw.get("speaker") or raw.get("sender_name"), 20)
            or "用户",
            "text": text,
        })
    return {
        "instance_id": _text(instance_id, 200),
        "platform_id": _text(platform_id, 200),
        "platform": _text(platform or "qq", 40) or "qq",
        "thread_key": _text(umo, 200),
        "person_key": _text(person_key, 200),
        "is_private": True,
        "messages": transcript,
    }


def parse_context(body, max_chars: int = MAX_CONTEXT_CHARS) -> dict:
    """解析管理器 ``/api/presence/context`` 响应并生成注入块。

    只有 ``allow_memory=True`` 时才注入昵称、关系阶段与里程碑；昨日摘要
    与关系开关无关。整块最多 ``max_chars`` 字，避免挤占人格与心情提示词。

    Args:
        body: 管理器响应，允许带 ``data`` 包装或直接是数据对象。
        max_chars: 注入块最大字符数，默认 250。

    Returns:
        含 ``nickname/stage/stage_label/allow_memory/milestones/
        diary_summary/block`` 的字典；无效响应返回空块。
    """
    data = body if isinstance(body, dict) else {}
    if isinstance(data.get("data"), dict):
        data = data["data"]
    # 收件箱接管中的会话一律不注入：管理器已把上下文清空，这里再兜底。
    takeover = data.get("takeover") is True
    if takeover:
        return {
            "nickname": "",
            "stage": "",
            "stage_label": "",
            "allow_memory": False,
            "milestones": [],
            "diary_summary": "",
            "block": "",
            "takeover": True,
        }
    allow_memory = data.get("allow_memory") is True
    nickname = _text(data.get("nickname"), 40) if allow_memory else ""
    stage = _text(data.get("stage"), 20) if allow_memory else ""
    stage_label = STAGE_LABELS.get(stage, stage) if stage else ""
    aliases = []
    traits = []
    tags = []
    likes = dislikes = boundaries = recent = ""
    if allow_memory:
        aliases = [
            _text(item, 20) for item in (data.get("aliases") or [])
            if _text(item, 20)
        ][:3]
        traits = [
            _text(item, 20) for item in (data.get("traits") or [])
            if _text(item, 20)
        ][:4]
        tags = [
            _text(item, 20) for item in (data.get("tags") or [])
            if _text(item, 20)
        ][:4]
        likes = _text(data.get("likes"), 80)
        dislikes = _text(data.get("dislikes"), 80)
        boundaries = _text(data.get("boundaries"), 80)
        recent = _text(data.get("recent_summary"), 100)
    milestones = []
    if allow_memory:
        for raw in data.get("milestones") or []:
            if isinstance(raw, dict):
                title = _text(raw.get("title"), 40)
                if title:
                    milestones.append(title)
            if len(milestones) >= 2:
                break
    summary = _text(data.get("diary_summary"), MAX_DIARY_CHARS)
    lines = []
    head = ""
    if nickname:
        head = f"你叫对方“{nickname}”"
        if aliases:
            head += f"（也叫{'、'.join(aliases)}）"
    if head and stage_label:
        lines.append(f"【对当前对话者】{head}；关系阶段：{stage_label}。")
    elif head:
        lines.append(f"【对当前对话者】{head}。")
    elif stage_label:
        lines.append(f"【对当前对话者】关系阶段：{stage_label}。")
    profile = []
    labels = traits or tags
    if labels:
        profile.append(f"性格：{'、'.join(labels)}")
    if likes:
        profile.append(f"喜欢：{likes}")
    if dislikes:
        profile.append(f"不喜欢：{dislikes}")
    if boundaries:
        profile.append(f"雷区：{boundaries}")
    if profile:
        lines.append(f"【对方的档案】{'；'.join(profile)}。自然参考，别当面复述。")
    if recent:
        lines.append(f"【最近印象】{recent}。")
    if milestones:
        lines.append(f"【共同记忆】{'；'.join(milestones)}。自然使用，不要机械复述。")
    if summary:
        lines.append(f"【昨日心情】{summary}（今天语气自然一点，别主动提日记。）")
    block = "\n".join(lines).strip()
    limit = max(0, int(max_chars or MAX_CONTEXT_CHARS))
    if limit and len(block) > limit:
        block = block[:limit].rstrip()
    return {
        "nickname": nickname,
        "stage": stage,
        "stage_label": stage_label,
        "allow_memory": allow_memory,
        "milestones": milestones,
        "diary_summary": summary,
        "aliases": aliases,
        "traits": traits,
        "tags": tags,
        "likes": likes,
        "dislikes": dislikes,
        "boundaries": boundaries,
        "recent_summary": recent,
        "block": block,
        "takeover": False,
    }


def _clue_hit(texts) -> bool:
    joined = " ".join(str(x or "") for x in (texts or []))
    return any(word in joined for word in SCAN_CLUES)


def should_scan(state, now=None, min_messages: int = 6,
                min_hours: float = 6) -> bool:
    """判断某个私聊缓冲是否应该请求管理器扫描未完成话题。

    触发条件（满足其一）：出现线索词、新增消息达到最少条数、距上次扫描
    超过最少小时数且期间有新消息。失败重试由 ``retry_after`` 控制。

    Args:
        state: 缓冲状态，含 ``private``、``message_count``、``last_scan_at``、
            ``retry_after``、``texts``。
        now: 当前时间戳，省略取 ``time.time()``。
        min_messages: 触发扫描的最少新增消息数。
        min_hours: 距上次扫描的最少小时数。

    Returns:
        需要扫描时返回 True。
    """
    if not isinstance(state, dict) or state.get("private") is False:
        return False
    now = time.time() if now is None else float(now)
    if now < _float(state.get("retry_after")):
        return False
    count = max(0, _int(state.get("message_count")))
    if count <= 0:
        return False
    if _clue_hit(state.get("texts")):
        return True
    if count >= max(1, int(min_messages or 6)):
        return True
    last_scan = _float(state.get("last_scan_at"))
    if last_scan > 0 and now - last_scan >= max(0.0, float(min_hours or 6)) * 3600:
        return True
    return False


def radar_key(umo, message_id="") -> str:
    """生成群消息雷达的缓存键。

    Args:
        umo: 统一消息来源。
        message_id: 平台消息 ID；缺失时用 0 占位。

    Returns:
        ``umo:message_id`` 字符串。
    """
    return f"{str(umo or '')}:{str(message_id if message_id not in (None, '') else 0)}"


def _minutes(value):
    text = str(value or "").strip()
    if len(text) != 5 or text[2] != ":":
        return None
    hour, minute = text[:2], text[3:]
    if not (hour.isdigit() and minute.isdigit()):
        return None
    hour, minute = int(hour), int(minute)
    if hour > 23 or minute > 59:
        return None
    return hour * 60 + minute


def quiet_now(quiet_start, quiet_end, now=None) -> bool:
    """判断当前是否处于安静时段（支持跨午夜）。

    Args:
        quiet_start: ``HH:MM`` 开始时间。
        quiet_end: ``HH:MM`` 结束时间。
        now: 当前时间戳，省略取 ``time.time()``。

    Returns:
        在安静时段内返回 True；时间非法或起止相同返回 False。
    """
    start = _minutes(quiet_start)
    end = _minutes(quiet_end)
    if start is None or end is None or start == end:
        return False
    local = _dt.datetime.fromtimestamp(
        time.time() if now is None else float(now))
    minute = local.hour * 60 + local.minute
    if start < end:
        return start <= minute < end
    return minute >= start or minute < end


def followup_payload(body) -> list[dict]:
    """解析到期回访响应，只返回可安全私聊发送的条目。

    影子模式、被拦截、错误响应一律返回空列表；群聊 UMO、缺少文案或
    话题 ID 的条目直接丢弃，确保插件绝不在群里发回访。

    Args:
        body: 管理器 ``/api/presence/followups/due`` 响应。

    Returns:
        每条含 ``loop_id/umo/text/person_key/platform`` 的列表。
    """
    data = body if isinstance(body, dict) else {}
    if isinstance(data.get("data"), dict):
        data = data["data"]
    if data.get("shadow") is True or data.get("blocked_reason"):
        return []
    loops = data.get("loops")
    if not isinstance(loops, list):
        return []
    items = []
    for loop in loops:
        if not isinstance(loop, dict):
            continue
        loop_id = _text(loop.get("id"), 100)
        umo = _text(loop.get("thread_key"), 200)
        text = " ".join(_text(loop.get("follow_up_text")).split())
        if not loop_id or not text or not is_private_umo(umo):
            continue
        items.append({
            "loop_id": loop_id,
            "umo": umo,
            "text": text[:200],
            "person_key": _text(loop.get("person_key"), 200),
            "platform": _text(loop.get("platform") or "qq", 40) or "qq",
        })
    return items


def should_diary(now=None, diary_time="23:30", last_date="",
                 enabled=True) -> bool:
    """判断是否应触发当日日记生成。

    Args:
        now: 当前时间戳，省略取 ``time.time()``。
        diary_time: ``HH:MM`` 触发时间。
        last_date: 上次触发日期 ``YYYY-MM-DD``。
        enabled: 管理器日记开关。

    Returns:
        已到触发时间且今天还没触发过时返回 True。
    """
    if not enabled:
        return False
    target = _minutes(diary_time)
    if target is None:
        return False
    now = time.time() if now is None else float(now)
    local = _dt.datetime.fromtimestamp(now)
    today = local.strftime("%Y-%m-%d")
    if str(last_date or "") == today:
        return False
    return local.hour * 60 + local.minute >= target
